#include "globals.h"
#include "Recognizer.h"
#include "kgconverter.h"
#include "ctype.h"
#include "string.h"
#include "lexical.h"



struct lexicalobject *newlexicalobject(){
	struct lexicalobject *templo;

	templo=new lexicalobject;

	if(templo) {
		templo->bytecount=0;
		templo->bytes=0;
		templo->idiomcount=0;
		templo->idioms=0;
		templo->moleculecount=0;
		templo->molecules=0;
		templo->nextlexicalobject=NULL;
		}

	return(templo);


	}


//-------------------------------------------------------------
// LXGetRef returns the position of the lexical input string
// in the sorted array sourcestrings
//-------------------------------------------------------------

int LXGetRef(char *string,struct lexicalobject *sourcestrings[],int start, int end) {
	int midpoint;
	int c;

	if(end<0) return(0);

	while(end>=start) {
		midpoint=(start+end)>>1;
		c=strcmp(string,sourcestrings[midpoint]->bytes);
		if(!c) {
			return(midpoint);
		}
		else if(c<0) {
			end=midpoint-1;
		}
		else {
			start=midpoint+1;
		}
		}
	
	return(-start);//not found

	}



//-------------------------------------------------------------
// GetLexicalType returns the type of lexcial item by analyzing the
// input string. 0=word 1=idiom
//-------------------------------------------------------------

int LXGetType(char *string) {
	int c;

	if(strchr( string, ' ' )) return(1);
	else return(0);

// pdest = strrchr( string, ' ' );

	}

//-------------------------------------------------------------
// LXBubbleSort sorts the lexical object by their string values
//
// no longer used
//-------------------------------------------------------------


void LXBubbleSort(struct lexicalobject *sourcestrings[], int n)
{
  int i,j;
  struct lexicalobject *tmp;

  for ( i=0;i< n-1; i++)
   for (j=n-1;j>i; j--)
    //if ( a[j-1] > a[j] ) swap( &a[j-1], &a[j]);
	if(strcmp(sourcestrings[j-1]->bytes,sourcestrings[j]->bytes)>0) {
		tmp=sourcestrings[j-1];
		sourcestrings[j-1]=sourcestrings[j];
		sourcestrings[j]=tmp;
		}
}


//-------------------------------------------------------------
// LXDeleteObjects write the lexical objects array to disk
//-------------------------------------------------------------

int LXDeleteObjects(struct lexicalobject *sourcestrings[], int n)
{
  int i;

  for ( i=0;i< n; i++) {
	  if(sourcestrings[i]) {
		if(sourcestrings[i]->bytecount) {
			delete sourcestrings[i]->bytes;
			}
		if(sourcestrings[i]->idiomcount) {
			delete sourcestrings[i]->idioms;
			}
		if(sourcestrings[i]->moleculecount) {
			delete sourcestrings[i]->molecules;
			}

		delete sourcestrings[i];
		sourcestrings[i]=NULL;
		}
	}
  
  return(1);
 }


int LXAddNewLexicalWord(char *lexstring,struct lexicalobject *sourcestrings[],int *totlex){

		int totlexicons=*totlex;
		int lpos=LXGetRef(lexstring,sourcestrings,0,totlexicons-1);
		char string[80];

		if(lpos<=0||!totlexicons) {

		//	sprintf(string,"Adding %s to pos=%d total=%d\n",lexstring,-lpos,totlexicons);
		//	OutputDebugString(string);

					unsigned char bcount=strlen(lexstring)+1;

					lexicalobject *lobj=newlexicalobject();

					if(lobj) {
						lobj->bytes=new char[bcount];
						lobj->bytecount=bcount;
						lobj->idiomcount=0;
						lobj->moleculecount=0;

						if(lobj->bytes) {
							strncpy(lobj->bytes,lexstring,bcount); // no quotes
							LXInsertObject(sourcestrings,lobj,-lpos,totlex);
							}
						}
			return(1);
			
		}


	return(0);
	}

int LXInsertObject(struct lexicalobject *sourcestrings[],struct lexicalobject *lobj,int lpos,int *TotalLexObjects){


	int totallexs=*TotalLexObjects;

	if(totallexs) {
		for(int a=totallexs;a>lpos;a--) {
			sourcestrings[a]=sourcestrings[a-1];
			}
		}

	sourcestrings[lpos]=lobj;
	totallexs++;

	*TotalLexObjects=totallexs;

	return(1);
	}




