#include "globals.h"
#include "Recognizer.h"
#include "kgconverter.h"
#include "ctype.h"
#include "string.h"
#include "molecule.h"



struct moleculeobject *newlmoleculeobject(){
	struct moleculeobject *tempmo;

	tempmo=new moleculeobject;

	if(tempmo) {
		tempmo->R=0;
		tempmo->Y=0;
		tempmo->C=0;
		tempmo->Q=0;
		tempmo->W=0;
		tempmo->QAttr=0;
		tempmo->RF=0;
		tempmo->Flag=0;
		tempmo->LexID=0;
		tempmo->nextmoleculeobject=NULL;
		}

	return(tempmo);


	}
