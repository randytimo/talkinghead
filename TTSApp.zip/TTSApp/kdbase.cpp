

//using ODBC
#include<windows.h>
#include<iostream>
#include<string>
#include<sql.h>
#include<sqlext.h>
#include "Worldfacts.h"
#include "odbcss.h"

using namespace std;
 
char Months[][16]={
		"january",
		"february",
		"march",
		"april",
		"may",
		"june",
		"july",
		"august",
		"september",
		"october",
		"november",
		"december"};

#define MAXBUFLEN 128
//#define MAXNAME 128


void ProcessLogMessages(SQLSMALLINT plm_handle_type,
                  SQLHANDLE plm_handle,
                  char *logstring, int ConnInd)
{
   RETCODE      plm_retcode = SQL_SUCCESS;
   UCHAR      plm_szSqlState[MAXBUFLEN] = "",
            plm_szErrorMsg[MAXBUFLEN] = "";
   SDWORD      plm_pfNativeError = 0L;
   SWORD      plm_pcbErrorMsg = 0;
   SQLSMALLINT   plm_cRecNmbr = 1;
   SDWORD      plm_SS_MsgState = 0, plm_SS_Severity = 0;
   SQLINTEGER   plm_Rownumber = 0;
   USHORT      plm_SS_Line;
   SQLSMALLINT   plm_cbSS_Procname, plm_cbSS_Srvname;
   SQLCHAR      plm_SS_Procname[MAXNAME], plm_SS_Srvname[MAXNAME];

   printf(logstring);

   while (plm_retcode != SQL_NO_DATA_FOUND) {
      plm_retcode = SQLGetDiagRec(plm_handle_type, plm_handle,
         plm_cRecNmbr, plm_szSqlState, &plm_pfNativeError,
         plm_szErrorMsg, MAXBUFLEN - 1, &plm_pcbErrorMsg);

      // Note that if the application has not yet made a
      // successful connection, the SQLGetDiagField
      // information has not yet been cached by ODBC
      // Driver Manager and these calls to SQLGetDiagField
      // will fail.
      if (plm_retcode != SQL_NO_DATA_FOUND) {
         if (ConnInd) {
            plm_retcode = SQLGetDiagField(
               plm_handle_type, plm_handle, plm_cRecNmbr,
               SQL_DIAG_ROW_NUMBER, &plm_Rownumber,
               SQL_IS_INTEGER,
               NULL);
            plm_retcode = SQLGetDiagField(
               plm_handle_type, plm_handle, plm_cRecNmbr,
               SQL_DIAG_SS_LINE, &plm_SS_Line,
               SQL_IS_INTEGER,
               NULL);
            plm_retcode = SQLGetDiagField(
               plm_handle_type, plm_handle, plm_cRecNmbr,
               SQL_DIAG_SS_MSGSTATE, &plm_SS_MsgState,
               SQL_IS_INTEGER,
               NULL);
            plm_retcode = SQLGetDiagField(
               plm_handle_type, plm_handle, plm_cRecNmbr,
               SQL_DIAG_SS_SEVERITY, &plm_SS_Severity,
               SQL_IS_INTEGER,
               NULL);
            plm_retcode = SQLGetDiagField(
               plm_handle_type, plm_handle, plm_cRecNmbr,
               SQL_DIAG_SS_PROCNAME, &plm_SS_Procname,
               sizeof(plm_SS_Procname),
               &plm_cbSS_Procname);
            plm_retcode = SQLGetDiagField(
               plm_handle_type, plm_handle, plm_cRecNmbr,
               SQL_DIAG_SS_SRVNAME, &plm_SS_Srvname,
               sizeof(plm_SS_Srvname),
               &plm_cbSS_Srvname);
         }
         printf("szSqlState = %s\n",plm_szSqlState);
         printf("pfNativeError = %d\n",plm_pfNativeError);
         printf("szErrorMsg = %s\n",plm_szErrorMsg);
         printf("pcbErrorMsg = %d\n\n",plm_pcbErrorMsg);
         if (ConnInd) {
            printf("ODBCRowNumber = %d\n", plm_Rownumber);
            printf("SSrvrLine = %d\n", plm_Rownumber);
            printf("SSrvrMsgState = %d\n",plm_SS_MsgState);
            printf("SSrvrSeverity = %d\n",plm_SS_Severity);
            printf("SSrvrProcname = %s\n",plm_SS_Procname);
            printf("SSrvrSrvname = %s\n\n",plm_SS_Srvname);
         }
      }
      plm_cRecNmbr++; //Increment to next diagnostic record.
   } // End while.
}



//dsn samples:
    //"driver={Microsoft Access Driver (*.mdb)};dbq=[f:\\db1.mdb];"
    //"driver={SQL Server};pwd={password there};Server={server name};Database={dbname there}"
    //driver names for different databases:
    //{SQL Server}
    //{Microsoft ODBC for Oracle}
    //{Oracle in oracle9}
    //{Microsoft Access Driver (*.mdb)}
    //{MySQL ODBC 3.51 Driver}

int  setdbentry(char *accessdbname, char *tablename, char *setcolumn,char *setvalue, char *matchcolumn, char *matchstring)
{
    HENV hEnv;
    HDBC hDbc;
    RETCODE rc;
    int iOut;
    char strOut[256];
    char szDSN[256] = "driver={Microsoft Access Driver (*.mdb)};dbq=[c:\\Almanac2.mdb];";

	char szSql[256];
	int found=0;

  //  char* szSql = "select MonthName from Stone where Month = '07'";

	wsprintf(szDSN,"driver={Microsoft Access Driver (*.mdb)};dbq=[%s];",accessdbname);
	wsprintf(szSql,"update %s set %s = '%s' where %s = '%s'",tablename,setcolumn,setvalue,matchcolumn,matchstring);


    rc = SQLAllocEnv(&hEnv);
    rc = SQLAllocConnect(hEnv, &hDbc);

    rc = SQLDriverConnect(hDbc, NULL, (unsigned char*)szDSN, 
        SQL_NTS, (unsigned char*)strOut, 
        255, (SQLSMALLINT*)&iOut, SQL_DRIVER_NOPROMPT);
    {
        int ival;
        char chval[1024];
        int ret1;
        int ret2;
        HSTMT hStmt;
        rc = SQLAllocStmt(hDbc,&hStmt);
        rc = SQLPrepare(hStmt,(unsigned char*)szSql, SQL_NTS);//1
 
        rc = SQLExecute(hStmt); //2
	//	rc=SQLExecDirectA(hStmt,(unsigned char*)szSql,SQL_NTS);

		if(rc==-1) {
	       //ProcessLogMessages(SQL_HANDLE_STMT, hStmt,           "SQLExecute() Failed\n\n", TRUE);
 
			//SQLGetDiagRec 
			}



        rc = SQLBindCol(hStmt, 1, SQL_C_CHAR, chval, 1024, (SQLINTEGER*)&ret2);
		rc = SQLFetch (hStmt);
        rc=SQLFreeStmt(hStmt, SQL_DROP);
    }
    rc = SQLDisconnect(hDbc);
    rc = SQLFreeEnv(hEnv);
    return(found);
}


int  quack(char *accessdbname, char *tablename, char *selectcolumn, char *matchcolumn, char *matchstring,char *retstring)
{
    HENV hEnv;
    HDBC hDbc;
    RETCODE rc;
    int iOut;
    char strOut[256];
    char szDSN[256] = "driver={Microsoft Access Driver (*.mdb)};dbq=[c:\\Almanac2.mdb];";

	char szSql[256];
	int found=0;

  //  char* szSql = "select MonthName from Stone where Month = '07'";

	wsprintf(szDSN,"driver={Microsoft Access Driver (*.mdb)};dbq=[%s];",accessdbname);
	wsprintf(szSql,"select %s from %s where %s = '%s'",selectcolumn,tablename,matchcolumn,matchstring);


    rc = SQLAllocEnv(&hEnv);
    rc = SQLAllocConnect(hEnv, &hDbc);

    rc = SQLDriverConnect(hDbc, NULL, (unsigned char*)szDSN, 
        SQL_NTS, (unsigned char*)strOut, 
        255, (SQLSMALLINT*)&iOut, SQL_DRIVER_NOPROMPT);
    {
        int ival;
        char chval[1024];
        int ret1;
        int ret2;
        HSTMT hStmt;
        rc = SQLAllocStmt(hDbc,&hStmt);
        rc = SQLPrepare(hStmt,(unsigned char*)szSql, SQL_NTS);//1
        //rc = SQLBindCol(hStmt, tab_column, tr_type, tr_value, tr_len, len_or_ind);
     //   rc = SQLBindCol(hStmt, 1, SQL_C_ULONG, &ival, 4, (SQLINTEGER*)& ret1);
        rc = SQLBindCol(hStmt, 1, SQL_C_CHAR, chval, 1024, (SQLINTEGER*)&ret2);
        rc = SQLExecute(hStmt); //2
        //if you have queries like drop/create/many update... 
        //instead of //1 //2 and //3 you could use
        //rc=SQLExecDirectA(hStmt,(unsigned char*)szSql,SQL_NTS);
    //    cout<< ">table:"<< endl;
  //      while(1) //3
    //    {
            rc = SQLFetch(hStmt);
			if(rc == SQL_SUCCESS || rc == SQL_SUCCESS_WITH_INFO){
				strcpy(retstring,chval);
				found=1;
				}


         //   if(rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO) break;
       //     cout<< "{"<< ival<<"}{"<< chval<< "}"<< endl;
     //   }
        rc=SQLFreeStmt(hStmt, SQL_DROP);
    }
    rc = SQLDisconnect(hDbc);
    rc = SQLFreeEnv(hEnv);
    return(found);
}
int  quack2(char *accessdbname, char *tablename, char *selectcolumn, char *matchcolumn, char *matchstring, char *matchcolumn2, char *matchstring2,char *retstring)
{
    HENV hEnv;
    HDBC hDbc;
    RETCODE rc;
    int iOut;
    char strOut[256];
    char szDSN[256] = "driver={Microsoft Access Driver (*.mdb)};dbq=[c:\\Almanac2.mdb];";

	char szSql[256];
	int found=0;

  //  char* szSql = "select MonthName from Stone where Month = '07'";

	wsprintf(szDSN,"driver={Microsoft Access Driver (*.mdb)};dbq=[%s];",accessdbname);
	wsprintf(szSql,"select %s from %s where (%s = '%s' AND %s = '%s')",selectcolumn,tablename,matchcolumn,matchstring,matchcolumn2,matchstring2);
//	wsprintf(szSql,"select %s from %s where %s = '%s'",selectcolumn,tablename,matchcolumn,matchstring,matchcolumn2,matchstring2);


    rc = SQLAllocEnv(&hEnv);
    rc = SQLAllocConnect(hEnv, &hDbc);

    rc = SQLDriverConnect(hDbc, NULL, (unsigned char*)szDSN, 
        SQL_NTS, (unsigned char*)strOut, 
        255, (SQLSMALLINT*)&iOut, SQL_DRIVER_NOPROMPT);
    {
        int ival;
        char chval[512];
        int ret1;
        int ret2;
        HSTMT hStmt;
        rc = SQLAllocStmt(hDbc,&hStmt);
        rc = SQLPrepare(hStmt,(unsigned char*)szSql, SQL_NTS);//1
        //rc = SQLBindCol(hStmt, tab_column, tr_type, tr_value, tr_len, len_or_ind);
     //   rc = SQLBindCol(hStmt, 1, SQL_C_ULONG, &ival, 4, (SQLINTEGER*)& ret1);
        rc = SQLBindCol(hStmt, 1, SQL_C_CHAR, chval, 512, (SQLINTEGER*)&ret2);
        rc = SQLExecute(hStmt); //2
        //if you have queries like drop/create/many update... 
        //instead of //1 //2 and //3 you could use
        //rc=SQLExecDirectA(hStmt,(unsigned char*)szSql,SQL_NTS);
    //    cout<< ">table:"<< endl;
  //      while(1) //3
    //    {
            rc = SQLFetch(hStmt);
			if(rc == SQL_SUCCESS || rc == SQL_SUCCESS_WITH_INFO){
				strcpy(retstring,chval);
				found=1;
				}


         //   if(rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO) break;
       //     cout<< "{"<< ival<<"}{"<< chval<< "}"<< endl;
     //   }
        rc=SQLFreeStmt(hStmt, SQL_DROP);
    }
    rc = SQLDisconnect(hDbc);
    rc = SQLFreeEnv(hEnv);
    return(found);
}

int  quack3(char *accessdbname, char *tablename, char *selectcolumn, char *matchcolumn, char *matchstring,char *retstring)
{
    HENV hEnv;
    HDBC hDbc;
    RETCODE rc;
    int iOut;
    char strOut[256];
    char szDSN[256] = "driver={Microsoft Access Driver (*.mdb)};dbq=[c:\\Almanac2.mdb];";

	char szSql[256];
	int found=0;

  //  char* szSql = "select MonthName from Stone where Month = '07'";

	wsprintf(szDSN,"driver={Microsoft Access Driver (*.mdb)};dbq=[%s];",accessdbname);
	wsprintf(szSql,"select %s from %s where %s like '%%%s%%'",selectcolumn,tablename,matchcolumn,matchstring);


    rc = SQLAllocEnv(&hEnv);
    rc = SQLAllocConnect(hEnv, &hDbc);

    rc = SQLDriverConnect(hDbc, NULL, (unsigned char*)szDSN, 
        SQL_NTS, (unsigned char*)strOut, 
        255, (SQLSMALLINT*)&iOut, SQL_DRIVER_NOPROMPT);
    {
        int ival;
        char chval[1024];
        int ret1;
        int ret2;
        HSTMT hStmt;
        rc = SQLAllocStmt(hDbc,&hStmt);
        rc = SQLPrepare(hStmt,(unsigned char*)szSql, SQL_NTS);//1
        //rc = SQLBindCol(hStmt, tab_column, tr_type, tr_value, tr_len, len_or_ind);
     //   rc = SQLBindCol(hStmt, 1, SQL_C_ULONG, &ival, 4, (SQLINTEGER*)& ret1);
        rc = SQLBindCol(hStmt, 1, SQL_C_CHAR, chval, 1024, (SQLINTEGER*)&ret2);
        rc = SQLExecute(hStmt); //2
        //if you have queries like drop/create/many update... 
        //instead of //1 //2 and //3 you could use
        //rc=SQLExecDirectA(hStmt,(unsigned char*)szSql,SQL_NTS);
    //    cout<< ">table:"<< endl;
  //      while(1) //3
    //    {


		int count=0;
		while(count<5) {
            rc = SQLFetch(hStmt);
			if(rc == SQL_SUCCESS || rc == SQL_SUCCESS_WITH_INFO){
				if(!found) {
					strcpy(retstring,chval);
					}
				else {
					strcat(retstring,".\r\n\r\nNext verse. ");
					strcat(retstring,chval);
					}
				found=1;
				}
			else {
				break;
				}
			count++;
		}


         //   if(rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO) break;
       //     cout<< "{"<< ival<<"}{"<< chval<< "}"<< endl;
     //   }
        rc=SQLFreeStmt(hStmt, SQL_DROP);
    }
    rc = SQLDisconnect(hDbc);
    rc = SQLFreeEnv(hEnv);
    return(found);
}


int checkforbirthstone(char *sentence,char *retstring) {

	char string[256];
	for(int a=0;a<12;a++) {
		if(containsstring(sentence,Months[a])) {
			if(quack("c:\\Almanac2.mdb","Stone","Stone","MonthName",Months[a],string)) {
					strcpy(retstring,string);
					return(1);
				}
			else {
				return(0);
				}
			}
		}

		return(0);
}

int checkforsongs(char *sentence,char *retstring) {

	char string[256];

	int l=strlen(sentence);

	for(int a=0;a<l-4;a++) {
		if(isdigit(sentence[a])&&isdigit(sentence[a+1])&&isdigit(sentence[a+2])&&isdigit(sentence[a+3])) {
			//year=atoi(&sentence[a]);
			sentence[a+4]=0;
			if(quack("c:\\Almanac2.mdb","Songs","SONG1","YEAR",&sentence[a],string)) {
					strcpy(retstring,string);

			if(quack("c:\\Almanac2.mdb","Songs","SONG2","YEAR",&sentence[a],string)) {
				strcat(retstring," ");
				strcat(retstring,string);
				}
			if(quack("c:\\Almanac2.mdb","Songs","SONG3","YEAR",&sentence[a],string)) {
				strcat(retstring," ");
				strcat(retstring,string);
				}
			if(quack("c:\\Almanac2.mdb","Songs","SONG4","YEAR",&sentence[a],string)) {
				strcat(retstring," ");
				strcat(retstring,string);
				}
			if(quack("c:\\Almanac2.mdb","Songs","SONG5","YEAR",&sentence[a],string)) {
				strcat(retstring," ");
				strcat(retstring,string);
				}



					return(1);
				}
			else {
				return(0);
				}
		}
	}



		return(0);
}

int checkforsports(char *sentence,char *retstring) {

	char string[1024];

	int l=strlen(sentence);

	for(int a=0;a<l-4;a++) {
		if(isdigit(sentence[a])&&isdigit(sentence[a+1])&&isdigit(sentence[a+2])&&isdigit(sentence[a+3])) {
			//year=atoi(&sentence[a]);
			sentence[a+4]=0;
			if(quack("c:\\Almanac2.mdb","Sports","SPORTS","YEAR",&sentence[a],string)) {
					strcpy(retstring,string);
					return(1);
				}
			else {
				return(0);
				}
		}
	}



		return(0);
}

int checkforbirthday(char *sentence,char *retstring) {

	char string[512];
	char nstring[3];
	char mstring[3];

	int l=strlen(sentence);


	for(int a=0;a<12;a++) {
		if(int p=containsstring(sentence,Months[a])) {
			int d=atoi(&sentence[p]);
			int m=a+1;

			if(d>=1&&d<=31) {
				if(d<10) {
					wsprintf(nstring,"0%d",d);
					}
				else {
					wsprintf(nstring,"%d",d);
					}
			if(m<10) {
					wsprintf(mstring,"0%d",m);
					}
				else {
					wsprintf(mstring,"%d",m);
					}
				



		if(quack2("c:\\Almanac2.mdb","Birthdays","Person1","Month",mstring,"Day",nstring,string)) {
					strcpy(retstring,string);
					if(quack2("c:\\Almanac2.mdb","Birthdays","Person2","Month",mstring,"Day",nstring,string)) {
						strcat(retstring,". ");
						strcat(retstring,string);
						}
#if 1

				if(quack2("c:\\Almanac2.mdb","Birthdays","Person3","Month",mstring,"Day",nstring,string)) {
						strcat(retstring,". ");
						strcat(retstring,string);
						}
				if(quack2("c:\\Almanac2.mdb","Birthdays","Person4","Month",mstring,"Day",nstring,string)) {
						strcat(retstring,". ");
						strcat(retstring,string);
						}
				if(quack2("c:\\Almanac2.mdb","Birthdays","Person5","Month",mstring,"Day",nstring,string)) {
						strcat(retstring,". ");
						strcat(retstring,string);
						}
#endif









					return(1);

			}
		else {
			return(0);
			}

			
			}
		}
	}


		return(0);
}

int checkforbibleverse(char *sentence,char *retstring) {

	char string[1024];

	if(quack3("c:\\kjvnew.mdb","BibleTable","TextData","TextData",sentence,string)) {
		strcpy(retstring,string);
		return(1);
		}

		return(0);
}



int checkfortvlisting(char *sentence,char *retstring) {
	char string[512];
	char mstring[32];
	char nstring[32];
	char tstring[32];
	

	if(int p=containsstring(sentence,"channel")) {
		sscanf(&sentence[p],"%s",nstring);
		if(int p=containsstring(sentence," at ")) {

			sscanf(&sentence[p],"%s",mstring);

			for(int a=0;a<4;a++) {
				if(mstring[a]==':') mstring[a]='_';
				}

			int t=atoi(&sentence[p]);

		wsprintf(tstring,"TIME%s",mstring);
	
		//			if(quack("c:\\tvguide.mdb","TVTable",nstring,"Channel",mstring,string)) {
	//		if(quack("c:\\tvguide.mdb","TVTable","TIME6_00","Channel","six",string)) {
		if(quack("c:\\tvguide.mdb","TVTable",tstring,"Channel",nstring,string)) {
					strcpy(retstring,string);
					return(1);
					}	
				else {
					return(0);
					}
		}
	}


		return(0);
}