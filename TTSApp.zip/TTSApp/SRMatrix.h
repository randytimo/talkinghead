struct SRMobject {
	int NxName;
	int NxRef;
	int NxType;
	int Parent;
	int Status;
	int BaseAddr;
	int VectorMag;
	int VectorDir;
	int CreatedTime;
	int LastUpdated;
	void *nextSRMobject;

	};

struct SRMobject *newSRMobject();

struct SMMx {
	int numSRMobjects;
	struct SRMobject *srm;
	};
