#include "globals.h"

#include "Recognizer.h"
#include "kgconverter.h"
#include "ctype.h"
#include "string.h"
#include "molecule.h"
#include "lexical.h"
#include "morphology.h"
#include "stmmanager.h"
#include "AttrMatrix.h"
#include "classifier.h"



struct STMobject *newstmobject(){

	struct STMobject *tempstm;

	tempstm=new STMobject;
	if(tempstm) {
		tempstm->STMWordList=NULL;
		tempstm->numwordobjects=0;

		tempstm->STMMoleculeList=NULL;
		tempstm->nummoleculeobjects=0;

		tempstm->SRMobjectList=NULL;
		tempstm->numsmmxobjects=0;

		tempstm->ATMxList=NULL;
		tempstm->numatmobjects=0;
		}

	return(tempstm);

	}




struct moleculeobject *STMFindMoleculeObject(struct STMobject *STM,struct moleculeobject *mobject){

	struct moleculeobject *tempmo=STM->STMMoleculeList;

	for(int a=0;a<STM->nummoleculeobjects;a++) { //Advance to where new object will go
//		if(mobject->lexref==tempmo->lexref) return(tempwo);

//		tempmo=(struct moleculeobject *)tempmo->nextnoleculeobject;
		}

	return(NULL);
	}

int STMAddWordToSRM(struct STMobject *STM,struct wordobject *wobject){

	struct wordobject *tempwo=STM->STMWordList;

	for(int a=0;a<STM->numwordobjects-1;a++) { //Advance to where new object will go
		tempwo=(struct wordobject *)tempwo->nextwordobject;
		}

	tempwo->nextwordobject=wobject;
	STM->numwordobjects++;

	return(1);
	}

int STMAddMolecule(struct STMobject *STM,struct moleculeobject *molobject){

	struct moleculeobject *tempmo=STM->STMMoleculeList;

	for(int a=0;a<STM->nummoleculeobjects-1;a++) { //Advance to where new object will go
		tempmo=(struct moleculeobject *)tempmo->nextmoleculeobject;
		}

	tempmo->nextmoleculeobject=molobject;
	STM->nummoleculeobjects++;

	return(1);
	}


int STMFindMolecule(struct STMobject *STM,struct moleculeobject *molobject){

	struct moleculeobject *tempmo=STM->STMMoleculeList;

	for(int a=0;a<STM->nummoleculeobjects;a++) { //Advance to where new object will go
		if(tempmo==molobject) return(1); //Found
		tempmo=(struct moleculeobject *)tempmo->nextmoleculeobject;
		}

	return(0);
	}

int STMAddMoleculeAttributes(struct STMobject *STM,struct moleculeobject *molobject){

	struct ATMobject *tempao=STM->ATMxList;
	
	struct ATMobject *newao=newATMobject();
	int attrcount=0;

	if(newao) {
		for(int a=0;a<STM->nummoleculeobjects-1;a++) { //Advance to where new object will go
			tempao=(struct ATMobject *)tempao->nextATMobject;
			attrcount++;
			}

		tempao->nextATMobject=newao;
		newao->AttName=molobject->LexID;
		newao->AttRef=attrcount;
		STM->numatmobjects++;
		}

	return(1);
	}

#if 0
int STMAddIdiom(struct STMobject *STM,struct lexicalobject *lexobject){

	struct lexicalobject *tempmo=STM->STMMoleculeList;

	for(int a=0;a<STM->nummoleculeobjects-1;a++) { //Advance to where new object will go
		tempmo=(struct moleculeobject *)tempmo->nextmoleculeobject;
		}

	tempmo->nextlexicalobject=lexobject;
	STM->nummoleculeobjects++;

	return(1);
	}

#endif


int STMAddSentenceToWordList(struct STMobject *STM, char *sentence) {
	int wordcount=0;
	int words[256];
	int idiomcount=0;
	int idioms[256];
	int moleculecount=0;
	int molecules[2560];



	if(RZRecognizeWords(sentence,words,&wordcount,idioms,&idiomcount,molecules,&moleculecount)) {
		if(wordcount) {
			CLClassifyWords(STM,words,wordcount,idioms,idiomcount,molecules,moleculecount);
			}
		}

	return(1);
	}


int STMAddParagraphToWordList(struct STMobject *STM, char *string) {
	struct recognizerobject robject;
	char string2[256];

	RZSetParagraph(&robject,string);

	while(RZGetNextSentence(&robject,string2,256)){
		STMAddSentenceToWordList(STM, string2);
		};


	return(1);
	}

int STMAddSentenceToSentenceMxList(struct STMobject *STM,char *sentence) {

	return(1);
	}


int STMAssociateWordAndMolecules(struct STMobject *STM) {

	return(1);
	}

int STMExtractAttributes() {

	return(1);
	}














