#include "globals.h"
#include "Recognizer.h"
#include "ctype.h"
#include "string.h"
#include "wakeup.h"
#include "morphology.h"
#include "lexical.h"
#include "kgfileio.h"
#include "kgconverter.h"

int isawake=0;

int WUIsAwake(){
	return(isawake);

	}

int WUInitialize(){

	if(!MOLoadPrefixes(MOLECULEFILENAME)) return(0);


	if(!LoadAllLexicalObjects(MOLECULEFILENAME)) return(0);

	if(!LoadAllMoleculeObjects(MOLECULEFILENAME)) return(0);




	isawake=1;

	
	return(1);



	}