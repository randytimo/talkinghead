int MOLoadPrefixes(char *filename);


int MOFindBaseWord(char *string,char *retstring);

