#include "globals.h"
#include "stdio.h"
#include "string.h"
#include <ODBCINST.H>




char factsbase[32]="c:\\opengl\\factbook\\print\\";

char fcountries[][80]={
 "af.html","Afghanistan",
  "al.html","Albania",
  "ag.html","Algeria",
  "aq.html","American Samoa",
  "an.html","Andorra",
  "ao.html","Angola",
  "av.html","Anguilla",
  "ay.html","Antarctica",
  "ac.html","Antigua and Barbuda", 
  "xq.html","Arctic Ocean",
  "ar.html","Argentina",
  "am.html","Armenia",
  "aa.html","Aruba",
  "at.html","Ashmore and Cartier Islands", 
  "zh.html","Atlantic Ocean",
  "as.html","Australia",
  "au.html","Austria",
  "aj.html","Azerbaijan", 
  "bf.html","Bahamas, The", 
  "ba.html","Bahrain", 
  "fq.html","Baker Island" ,
  "bg.html","Bangladesh" ,
  "bb.html","Barbados" ,
  "bs.html","Bassas da India" ,
  "bo.html","Belarus" ,
  "be.html","Belgium" ,
  "bh.html","Belize" ,
  "bn.html","Benin" ,
  "bd.html","Bermuda" ,
  "bt.html","Bhutan" ,
  "bl.html","Bolivia" ,
  "bk.html","Bosnia and Herzegovina" ,
  "bc.html","Botswana" ,
  "bv.html","Bouvet Island" ,
  "br.html","Brazil" ,
  "io.html","British Indian Ocean Territory" ,
  "vi.html","British Virgin Islands" ,
  "bx.html","Brunei" ,
  "bu.html","Bulgaria" ,
  "uv.html","Burkina Faso" ,
  "bm.html","Burma" ,
  "by.html","Burundi" ,
  "cb.html","Cambodia" ,
  "cm.html","Cameroon" ,
  "ca.html","Canada" ,
  "cv.html","Cape Verde" ,
  "cj.html","Cayman Islands" ,
  "ct.html","Central African Republic" ,
  "cd.html","Chad" ,
  "ci.html","Chile" ,
  "ch.html","China" ,
  "kt.html","Christmas Island" ,
  "ip.html","Clipperton Island" ,
  "ck.html","Cocos (Keeling) Islands" ,
  "co.html","Colombia" ,
  "cn.html","Comoros" ,
  "cg.html","Congo, Democratic Republic of the" ,
  "cf.html","Congo, Republic of the" ,
  "cw.html","Cook Islands" ,
  "cr.html","Coral Sea Islands" ,
  "cs.html","Costa Rica" ,
  "iv.html","Cote d'Ivoire" ,
  "hr.html","Croatia" ,
  "cu.html","Cuba" ,
  "cy.html","Cyprus" ,
  "ez.html","Czech Republic" ,
  "da.html","Denmark" ,
  "dj.html","Djibouti" ,
  "do.html","Dominica" ,
  "dr.html","Dominican Republic" ,
  "tt.html","East Timor" ,
  "ec.html","Ecuador" ,
  "eg.html","Egypt" ,
  "es.html","El Salvador" ,
  "ek.html","Equatorial Guinea" ,
  "er.html","Eritrea" ,
  "en.html","Estonia" ,
  "et.html","Ethiopia" ,
  "eu.html","Europa Island" ,
  "fk.html","Falkland Islands (Islas Malvinas)" ,
  "fo.html","Faroe Islands" ,
  "fj.html","Fiji" ,
  "fi.html","Finland" ,
  "fr.html","France" ,
  "fg.html","French Guiana" ,
  "fp.html","French Polynesia" ,
  "fs.html","French Southern and Antarctic Lands" ,
  "gb.html","Gabon" ,
  "ga.html","Gambia, The" ,
  "gz.html","Gaza Strip" ,
  "gg.html","Georgia" ,
  "gm.html","Germany" ,
  "gh.html","Ghana" ,
  "gi.html","Gibraltar" ,
  "go.html","Glorioso Islands" ,
  "gr.html","Greece" ,
  "gl.html","Greenland" ,
  "gj.html","Grenada" ,
  "gp.html","Guadeloupe" ,
  "gq.html","Guam" ,
  "gt.html","Guatemala" ,
  "gk.html","Guernsey" ,
  "gv.html","Guinea" ,
  "pu.html","Guinea-Bissau" ,
  "gy.html","Guyana" ,
  "ha.html","Haiti" ,
  "hm.html","Heard Island and McDonald Islands" ,
  "vt.html","Holy See (Vatican City)" ,
  "ho.html","Honduras" ,
  "hk.html","Hong Kong" ,
  "hq.html","Howland Island" ,
  "hu.html","Hungary" ,
  "ic.html","Iceland" ,
  "in.html","India" ,
  "xo.html","Indian Ocean" ,
  "id.html","Indonesia" ,
  "ir.html","Iran" ,
  "iz.html","Iraq" ,
  "ei.html","Ireland" ,
  "is.html","Israel" ,
  "it.html","Italy" ,
  "jm.html","Jamaica" ,
  "jn.html","Jan Mayen" ,
  "ja.html","Japan" ,
  "dq.html","Jarvis Island" ,
  "je.html","Jersey" ,
  "jq.html","Johnston Atoll" ,
  "jo.html","Jordan" ,
  "ju.html","Juan de Nova Island" ,
  "kz.html","Kazakhstan" ,
  "ke.html","Kenya" ,
  "kq.html","Kingman Reef" ,
  "kr.html","Kiribati" ,
  "kn.html","Korea, North" ,
  "ks.html","Korea, South" ,
  "ku.html","Kuwait" ,
  "kg.html","Kyrgyzstan" ,
  "la.html","Laos" ,
  "lg.html","Latvia" ,
  "le.html","Lebanon" ,
  "lt.html","Lesotho" ,
  "li.html","Liberia" ,
  "ly.html","Libya" ,
  "ls.html","Liechtenstein" ,
  "lh.html","Lithuania" ,
  "lu.html","Luxembourg" ,
  "mc.html","Macau" ,
  "mk.html","Macedonia" ,
  "ma.html","Madagascar" ,
  "mi.html","Malawi" ,
  "my.html","Malaysia" ,
  "mv.html","Maldives" ,
  "ml.html","Mali" ,
  "mt.html","Malta" ,
  "im.html","Man, Isle of" ,
  "rm.html","Marshall Islands" ,
  "mb.html","Martinique" ,
  "mr.html","Mauritania" ,
  "mp.html","Mauritius" ,
  "mf.html","Mayotte" ,
  "mx.html","Mexico" ,
  "fm.html","Micronesia, Federated States of" ,
  "mq.html","Midway Islands" ,
  "md.html","Moldova" ,
  "mn.html","Monaco" ,
  "mg.html","Mongolia" ,
  "mh.html","Montserrat" ,
  "mo.html","Morocco" ,
  "mz.html","Mozambique" ,
  "wa.html","Namibia" ,
  "nr.html","Nauru" ,
  "bq.html","Navassa Island" ,
  "np.html","Nepal" ,
  "nl.html","Netherlands" ,
  "nt.html","Netherlands Antilles" ,
  "nc.html","New Caledonia" ,
  "nz.html","New Zealand" ,
  "nu.html","Nicaragua" ,
  "ng.html","Niger" ,
  "ni.html","Nigeria" ,
  "ne.html","Niue" ,
  "nf.html","Norfolk Island" ,
  "cq.html","Northern Mariana Islands" ,
  "no.html","Norway" ,
  "zn.html","Pacific Ocean" ,
  "pk.html","Pakistan" ,
  "ps.html","Palau" ,
  "lq.html","Palmyra Atoll" ,
  "pm.html","Panama" ,
  "pp.html","Papua New Guinea" ,
  "pf.html","Paracel Islands" ,
  "pa.html","Paraguay" ,
  "pe.html","Peru" ,
  "rp.html","Philippines" ,
  "pc.html","Pitcairn Islands" ,
  "pl.html","Poland" ,
  "po.html","Portugal" ,
  "rq.html","Puerto Rico" ,
  "re.html","Reunion" ,
  "ro.html","Romania" ,
  "rs.html","Russia" ,
  "rw.html","Rwanda" ,
  "sh.html","Saint Helena" ,
  "sc.html","Saint Kitts and Nevis" ,
  "st.html","Saint Lucia" ,
  "sb.html","Saint Pierre and Miquelon" ,
  "vc.html","Saint Vincent and the Grenadines" ,
  "ws.html","Samoa" ,
  "sm.html","San Marino" ,
  "tp.html","Sao Tome and Principe" ,
  "sa.html","Saudi Arabia" ,
  "sg.html","Senegal" ,
  "yi.html","Serbia and Montenegro" ,
  "se.html","Seychelles" ,
  "sl.html","Sierra Leone" ,
  "sn.html","Singapore" ,
  "lo.html","Slovakia" ,
  "si.html","Slovenia" ,
  "bp.html","Solomon Islands" ,
  "so.html","Somalia" ,
  "sf.html","South Africa" ,
  "sx.html","South Georgia and the South Sandwich Islands" ,
  "oo.html","Southern Ocean" ,
  "sp.html","Spain" ,
  "pg.html","Spratly Islands" ,
  "ce.html","Sri Lanka" ,
  "su.html","Sudan" ,
  "ns.html","Suriname" ,
  "sv.html","Svalbard" ,
  "wz.html","Swaziland" ,
  "sw.html","Sweden" ,
  "sz.html","Switzerland" ,
  "sy.html","Syria" ,
  "ti.html","Tajikistan" ,
  "tz.html","Tanzania" ,
  "th.html","Thailand" ,
  "to.html","Togo" ,
  "tl.html","Tokelau" ,
  "tn.html","Tonga" ,
  "td.html","Trinidad and Tobago" ,
  "te.html","Tromelin Island" ,
  "ts.html","Tunisia" ,
  "tu.html","Turkey" ,
  "tx.html","Turkmenistan" ,
  "tk.html","Turks and Caicos Islands" ,
  "tv.html","Tuvalu" ,
  "ug.html","Uganda" ,
  "up.html","Ukraine" ,
  "tc.html","United Arab Emirates" ,
  "uk.html","United Kingdom" ,
  "us.html","United States" ,
  "uy.html","Uruguay" ,
  "uz.html","Uzbekistan" ,
  "nh.html","Vanuatu" ,
  "ve.html","Venezuela" ,
  "vm.html","Vietnam" ,
  "vq.html","Virgin Islands" ,
  "wq.html","Wake Island" ,
  "wf.html","Wallis and Futuna" ,
  "we.html","West Bank" ,
  "wi.html","Western Sahara" ,
  "xx.html","World",
"end","end"
 };

 char finfos[][80]={
	 "Population:", "POPULATION",
	 "Median age:","MEDIAN AGE",
	 "Median age:","AVERAGE AGE",
	 "Background:","TELL ME ABOUT",
	 "Background:","HISTORY",
	 "Location:","LOCATION",
	 "Location:","LOCATED",
	 "Location:","WHERE IS",
	 "Climate:","CLIMATE",
	 "Climate:","WEATHER",
	 "Terrain:","TERRAIN",
	 "Terrain:","COUNTRYSIDE",
	 "Life expectancy at birth:","LIFE EXPECTANCY",
	 "Languages:","LANGUAGE",
	 "Literacy:","LITERACY",
	 "Executive branch:","LEADER",
	 "Executive branch:","PRESIDENT",
	 "Executive branch:","RULER",
	 "Executive branch:","KING",
	 "Legislative branch:","SENATOR",
	 "Legislative branch:","CONGRESS",
	 "Judicial branch:","COURT",
	 "Judicial branch:","LEGAL SYSTEM",
	 "Political parties and leaders:","PARTIES",
	 "Political parties and leaders:","POLITICAL",
	 "Diplomatic representation in the US:","AMBASSADOR OF",
	 "Diplomatic representation from the US:","AMBASSADOR TO",
	 "Flag description:","FLAG",
	 "Economy - overview:","ECONOMY",
	 "Economy - overview:","BUSINESS",
	 "GDP:","GDP ",
	 "Unemployment rate:","UNEMPLOYMENT",
	 "Industries:","INDUSTRY",
	 "Industries:","INDUSTRIES",
	 "Agriculture - products:","AGRICULTURE",
	 "Exports - commodities:","EXPORT",
	 "Imports - commodities:","IMPORT",
	 "Currency:","MONEY SYSTEM",
	 "Currency:","CURRENCY",
	 "Illicit drugs:","DRUGS",
	 "Airports:","AIRPORTS",
	 "Capital:","CAPITAL",
	 "Area:","AREA",
	 "Area:","HOW BIG",
	 "Geographic coordinates:","COORDINATES",
	 "Elevation extremes:","ELEVATION",
	 "Natural resources:","RESOURCES",
	 "Religions:","RELIGION",
	 "Religions:","WORSHIP",
	 "Area:","FAITH",



	 "end","end",
	 "",
	 "",
	 "",
	 "",
	};


 int findcountrymatch(char *sentence) {

	 int a=0;
	 int done=0;
	 int match=-1;

	 while(!done){
		int l=strlen(fcountries[a+1]);

		int lasttocheck=strlen(sentence)-l;

		for(int b=0;b<=lasttocheck;b++) {
			if(!strncmp(&sentence[b],strupr(fcountries[a+1]),l)){
				match=a;
				done=1;
				break;
				}
			}

		a+=2;
		if(!strcmp(fcountries[a+1],"end")) done=1;
		}

	 return(match);
 }
 
 int findinfomatch(char *sentence) {

	 int a=0;
	 int done=0;
	 int match=-1;

	 while(!done){
		int l=strlen(finfos[a+1]);

		int lasttocheck=strlen(sentence)-l;

		for(int b=0;b<=lasttocheck;b++) {
			if(!strncmp(&sentence[b],strupr(finfos[a+1]),l)){
				match=a;
				done=1;
				break;
				}
			}

		a+=2;
		if(!strcmp(finfos[a+1],"end")) done=1;
		}

	 return(match);
 }

char outstring[1024];

int scrapefileto(FILE *fp,char *string,char *dest,int maxdest) {
	int l=strlen(string);
	int m=0;
	int done=0;
	int bracketcount=0;
	int destcount=0;
	//int skippingspaces=1;

	while(!feof(fp)&&!done) {
		int c=fgetc(fp);
		if(c==string[m]) {
			m++;
			if(m==l) {
				done=1;
				dest[destcount]=0;
				}
			}
		else {
			m=0;
			}

		if(c=='<') bracketcount++;
		else if(c=='>') bracketcount--;
		else if(bracketcount==0) {
			if(destcount<maxdest) {
				if(isprint(c)) {
					dest[destcount++]=c;
				}
			}
		}



		}
	return(destcount);
	}


 //<td
int advancefileto(FILE *fp,char *string) {
	int l=strlen(string);
	int m=0;
	int done=0;

	while(!feof(fp)&&!done) {
		int c=fgetc(fp);
		if(c==string[m]) {
			m++;
			if(m==l) {
				done=1;
				}
			}
		else {
			m=0;
			}
		}
	return(done);
	}

 int extracttabledata(FILE *fp,char *dest,int maxdest){

	if(advancefileto(fp,"<td")) {
		if(advancefileto(fp,">")) {
			if(scrapefileto(fp,"</td>",dest,maxdest)) {


				}

			}

		}

	 return(1);
	}



 int searchfilefor(char *filename,char *string) {
	FILE *fp;

	int l=strlen(string);
	int m=0;
	int done=0;

	if((fp=fopen(filename,"rb"))==NULL) {
		return(0);
	}

	if(advancefileto(fp,string)) {
		extracttabledata(fp,outstring,1023);
		}

	fclose(fp);
	return(1);

	}

 int parsemath(char *sentence) {
	 int l=strlen(sentence);
	 int innumber=0;
	 int nums=0;
	 char numstring[32];
	 int stringpos=0;
	 int total=0;
	int mathop=0; //0==plus 1=minus 2=times 3=divided
	int c;
	int foundop=0;


	 for(int a=0;a<l;a++) {
		 c=sentence[a];
		 if(isdigit(c)) {
			 if(innumber) {
				 numstring[stringpos++]=c;
				}
			 else {
				 stringpos=0; innumber=1;
				 numstring[stringpos++]=c;
				}
			}
		 else {
			 if(innumber) {
				 if(c!=',') {
				numstring[stringpos]=0;
					int result=atoi(numstring);
					nums++;
					if(mathop==0) {
						total+=result;
						}
					else if(mathop==1) {
						total-=result;
						}
					else if(mathop==2) {
						total*=result;
						}
					else if(mathop==3) {
						if(result!=0) total/=result;
						}

				innumber=0;
				 }
				}
			 else {
				 if(a<l-4) {
					if(!strncmp(&sentence[a],"PLUS",4)) {
						foundop=1;
						mathop=0;
						}
					 }
				 if(a<l-5) {
					if(!strncmp(&sentence[a],"MINUS",4)) {
						mathop=1;
						foundop=1;
						}
					 }
				 if(a<l-5) {
					if(!strncmp(&sentence[a],"TIMES",4)) {
						foundop=1;
					mathop=2;
					}
					}
				if(a<l-7) {
					if(!strncmp(&sentence[a],"DIVIDED",4)) {
						foundop=1;
					mathop=3;
					}
					}
				 }
			}
		}

			 if(innumber) {
				numstring[stringpos]=0;
					int result=atoi(numstring);
					nums++;
					if(mathop==0) {
						total+=result;
						}
					else if(mathop==1) {
						total-=result;
						}
					else if(mathop==2) {
						total*=result;
						}
					else if(mathop==3) {
						if(result!=0) total/=result;
						}

				innumber=0;
				}




	 if(nums>=2&&foundop) return(total);
	 else return(-997);
	}


char * parse_sentence(char *sentence) {
int countrynum=-1;
int infonum=-1;
char string[256];
int total=0;

	if((countrynum=findcountrymatch(sentence))>-1) {
		if((infonum=findinfomatch(sentence))>-1) {
			wsprintf(string,"%s of %s",fcountries[countrynum],finfos[infonum]);
		//	MessageBox(0,string,"info",MB_OK);
			strcpy(string,factsbase); strcat(string,fcountries[countrynum]);

			if(searchfilefor(string,finfos[infonum])) return(outstring);

			}
		}

	 total=parsemath(sentence);
	 if(total!=-997) {
		 wsprintf(outstring,"%d",total);
		 return(outstring);
		}

	
	return(NULL);

};



int containsstring(char *sentence,char *string) {
	 int l=strlen(sentence);
	int foundop=0;
	int l2=strlen(string);


	 for(int a=0;a<l;a++) {
		if(a<=l-l2) {
			if(!strncmp(&sentence[a],string,l2)) {
				foundop=a+l2;
				}
			}
		}

	return(foundop);
	}

int containsword(char *sentence,char *string) {
	int sentlen=strlen(sentence);
	int foundop=0;
	int wordlen=strlen(string);
	int oktocheck=1;

	 for(int a=0;a<sentlen;a++) {
		if(a<=sentlen-wordlen) {
			if(a==0) oktocheck=1;
			else if(sentence[a-1]==' ') oktocheck=1;
			else oktocheck=0;

			if(oktocheck) {
				if(sentence[a+wordlen]==0||sentence[a+wordlen]==' ') {
					if(!strncmp(&sentence[a],string,wordlen)) {
						foundop=a+wordlen;
						break;
						}
					}
					}
			}
		}

	return(foundop);
	}
