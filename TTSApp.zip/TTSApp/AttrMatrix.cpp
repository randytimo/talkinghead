#include "stdio.h"
#include "string.h"
#include "attrmatrix.h"


struct ATMobject *newATMobject(){
	struct ATMobject *tempao;

	tempao=new ATMobject;

	if(tempao) {

		tempao->AttName=0;
		tempao->AttRef=0;
		tempao->AttType=0;
		tempao->ParentNx=0;
		tempao->Status=0;
		tempao->VectorMag=0;
		tempao->VectorDir=0;
		tempao->CreatedTime=0;
		tempao->LastUpdated=0;
		tempao->nextATMobject=NULL;

		}

	return(tempao);


	}

