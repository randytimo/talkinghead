#include <winsock2.h>
#include <stdio.h>
#include "Worldfacts.h"
#include "getwebfile.h"

#define MESSAGE_SIZE 256
#define MESSAGE_BUFFER 65536

int startupClient(unsigned short port, const char* serverName);
void shutdownClient(int clientSocket);

char loadedwebpage[MESSAGE_BUFFER];
int loadedwebpagesize=0;

char parsedwebpage[MESSAGE_BUFFER];
int parsedwebpagesize=0;

char parsestrings[][16]={
	"<body",//0
	"</body",//1
	"<html",//2
	"</html",//3
	"<table",//4
	"</table",//5
	"<a",//6
	"</a",//7
	"<b",//8
	"</b",//9
	"<tr",//10
	"</tr",//11
	"<td",//12
	"</td",//13
	"<h1",//14
	"</h1",//15
	"<h2",//16
	"</h2",//17
	"<h3",//18
	"</h3",//19
	"<h4",//20
	"</h4",//21
	"<br",//22
	"<img",//23
	"<font",//24
	"</font",//25
	"<head",//26
	"</head",//27
	"<p",//28
	"</p",//29
	"<title",//30
	"</title",//31
	"<th",//32
	"</th",//33
	"<form",//34
	"<link",//35
	"<!doctype",//36
	"<span",//37
	"</span",//38
	"<input",//39
	};

int numparsestrings=40;
int lengthparsestrings[50];
int matchparsepos[50];
int iamin[50];
int inatag;
int parsematches;
int iaminthetarget;

char *getwebpagefullpath(char *string) {
	char hostname[80];
	char request[80];

	int l=0;
	int l2=strlen(string);
	
	int done=0;
	int c=0;
	int p0=0;
	int p1=0;


	while(!done&&l<l2) {
		if(string[l]=='/') {
			c++;
			switch(c) {
				case 2:
					p0=l;
					break;
				case 3:
					p1=l;
					done=1;
					break;
				}
			}
		l++;
		}

	if(p0&&p1) {
		strncpy(hostname,&string[p0+1],p1-p0);
		hostname[p1-p0-1]=0;
		strncpy(request,&string[p1],l2-p1);
		request[l2-p1]=0;


		}



	
	
//return(NULL);
	
	return(getwebfile(hostname,request));

	}


char *parseloadedwebpage(int *parseconditions) {
	
	int skip=0;
	int lcount=0;

	for(int a=0;a<numparsestrings;a++) {
		lengthparsestrings[a]=strlen(parsestrings[a]);
		matchparsepos[a]=0;
		}

	char c;
	
	parsedwebpagesize=0;

	while(skip<loadedwebpagesize-4) {
		if(!strncmp(&loadedwebpage[skip],"\r\n\r\n",4)) break;
		skip++;
	};
	


	for(int a=skip;a<loadedwebpagesize;a++) {

		inatag=0;
		for(int b=0;b<numparsestrings;b++) {
			if(loadedwebpage[a]=='&') {
				while(a<loadedwebpagesize&&loadedwebpage[a]!=';') a++;
				inatag=1;
				}
			else if(!strncmp(strlwr(&loadedwebpage[a]),strlwr(parsestrings[b]),lengthparsestrings[b])){
				while(a<loadedwebpagesize&&loadedwebpage[a]!='>') a++;
				inatag=1;
				break;
				}
		}

		if(!inatag) {
			if(isprint(loadedwebpage[a])) {
				parsedwebpage[parsedwebpagesize++]=loadedwebpage[a];
				if(!isspace(loadedwebpage[a])) lcount=0;
			}
			else if(loadedwebpage[a]==0xd) {
				if(lcount<2) parsedwebpage[parsedwebpagesize++]=loadedwebpage[a]; 
				}
			else if(loadedwebpage[a]==0xa) {
				lcount++;
				if(lcount<2) parsedwebpage[parsedwebpagesize++]=loadedwebpage[a]; 
				}
		}


	}


	parsedwebpage[parsedwebpagesize]=0;
	return(parsedwebpage);

	}





char * getwebfile(char *hostname,char *request) {
	int mySocket;

	mySocket = startupClient(80, hostname);

	if (mySocket == -1) {
		shutdownClient(mySocket);
		return(NULL);
	}

	int nBytes;

	// And the actual buffers
	char inMessage[MESSAGE_SIZE];
	char outMessage[256];
	char inChar;

	
//	wsprintf(outMessage,"POST /cgi-bin/findweather/getForecast HTTP/1.0\r\nquery=anoka,mn\r\n\r\n");

//	wsprintf(outMessage,"POST http://mobile.wunderground.com/cgi-bin/findweather/getForecast HTTP/1.0\r\n\r\n");
//	?query=anoka%2Cmn

	wsprintf(outMessage,"GET %s HTTP/1.0\r\n\r\n",request);
	nBytes = send(mySocket, outMessage, strlen(outMessage), 0);

	if (nBytes == SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
	} 

#if 1
	loadedwebpagesize=0;

	// receive the reply from the server
	while(((nBytes = recv(mySocket, inMessage, sizeof(inMessage), 0))>0)&&loadedwebpagesize<(MESSAGE_BUFFER-MESSAGE_SIZE)) {
		memcpy(&loadedwebpage[loadedwebpagesize],inMessage,nBytes);
		loadedwebpagesize+=nBytes;
		}
#else
	loadedwebpagesize=0;

	int bracketcount=0;
	int justdidaspace=0;

	// receive the reply from the server
	while(((nBytes = recv(mySocket, &inChar, 1, 0))>0)&&loadedwebpagesize<(MESSAGE_BUFFER)) {
		if(inChar=='<') {
			bracketcount=1;
			}
		else if(inChar=='>') {
			bracketcount=0;
			}
		else if(bracketcount==0) {
			if(isspace(inChar)) {
				if(!justdidaspace) {
				loadedwebpage[loadedwebpagesize++]=inChar;
				justdidaspace=1;


					}

				}
			else {
				loadedwebpage[loadedwebpagesize++]=inChar;
				justdidaspace=0;

				}
			}
		}
#endif

	shutdownClient(mySocket);
	loadedwebpage[loadedwebpagesize]=0;


#if 0
FILE *fp;
if((fp=fopen("c:\\debug.html","wb"))==NULL) {
		return(0);
	}

fwrite(loadedwebpage,loadedwebpagesize,1,fp);


fclose(fp);





#endif





	return(loadedwebpage);
}

#if 0

//http://www.crh.noaa.gov/forecasts/zipcity.php

//POST /forecasts/zipcity.php HTTP/1.0
//Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-excel, application/msword, application/vnd.ms-powerpoint, */*
//Accept-Language: en-us
//Accept-Encoding: gzip, deflate
//User-Agent: Mozilla/4.0
//Content-Length: 21
//Host: WWW.CRH.NOAA.GOV
//Content-Type: application/x-www-form-urlencoded

//inputstring=anoka, mn


HTTP/1.1 302 Found
Date: Sun, 25 Jan 2004 18:29:00 GMT
Server: Apache/1.3.27 (Unix)  (Red-Hat/Linux) PHP/4.1.2 mod_perl/1.26
X-Powered-By: PHP/4.1.2
Location: http://www.crh.noaa.gov/forecasts/MNZ061.php?warncounty=MNC003&city=Anoka
Connection: close
Content-Type: text/html


#endif




char * getweather(char *request) {// Anoka,MN
	int mySocket;
	
	char *hostname="www.crh.noaa.gov";
	char newrequest[126];
	int p;

	strcpy(newrequest,"inputstring=");
	strcat(newrequest,request);

	mySocket = startupClient(80, hostname);

	if (mySocket == -1) {
		shutdownClient(mySocket);
		return(NULL);
	}

	int nBytes;

	// And the actual buffers
	char inMessage[MESSAGE_SIZE];
	char outMessage[256];
	char inChar;

	
	wsprintf(outMessage,"POST /forecasts/zipcity.php HTTP/1.0\r\n"); 
	int n=strlen(outMessage);
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};

	wsprintf(outMessage,"Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-excel, application/msword, application/vnd.ms-powerpoint, */*\r\n");
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};

	wsprintf(outMessage,"Accept-Language: en-us\r\n");
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};

	wsprintf(outMessage,"Accept-Encoding: gzip, deflate\r\n");
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};

	wsprintf(outMessage,"User-Agent: Mozilla/4.0\r\n");
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};

	wsprintf(outMessage,"Content-Length: %d\r\n",strlen(newrequest));
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};
#if 0
	wsprintf(outMessage,"Host: WWW.CRH.NOAA.GOV\r\n");
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};
#endif

	wsprintf(outMessage,"Content-Type: application/x-www-form-urlencoded\r\n\r\n");
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};

	wsprintf(outMessage,"%s\r\n",newrequest);
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};



	//inputstring=anoka, mn




	loadedwebpagesize=0;

	// receive the reply from the server
	while(((nBytes = recv(mySocket, inMessage, sizeof(inMessage), 0))>0)&&loadedwebpagesize<(MESSAGE_BUFFER-MESSAGE_SIZE)) {
		memcpy(&loadedwebpage[loadedwebpagesize],inMessage,nBytes);
		loadedwebpagesize+=nBytes;
		}

	shutdownClient(mySocket);
	loadedwebpage[loadedwebpagesize]=0;


	if(p=containsstring(loadedwebpage,"Location: ")) {
		char *c=&loadedwebpage[p];
		while(*c&&*c!=0xd) c++;
		*c=0;

		getwebpagefullpath(&loadedwebpage[p]);

		int mytestints[26]={-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};

		c=parseloadedwebpage(mytestints);
#if 1

#if 0
		int sentencelength=0;
		int spacecount=0;
		int periodcount=0;

		p=0;
		int p2=0;
		int linestart=p;

		while(p<parsedwebpagesize) {
			if(isprint(parsedwebpage[p])) {
				if(parsedwebpage[p]==' ') spacecount++;
				else if(parsedwebpage[p]=='.') periodcount++;

				sentencelength++;

				}
			else {
				if(sentencelength>12) {
					if(periodcount>0) {
					strncpy(&loadedwebpage[p2],&parsedwebpage[linestart],sentencelength);
					p2+=sentencelength;
					loadedwebpage[p2++]=0xd;
					loadedwebpage[p2++]=0xa;
					}


					}
				linestart=p+1;
				sentencelength=0;
				spacecount=0;
				periodcount=0;
				}


			p++;
			}

		
		loadedwebpage[p2]=0;


return(loadedwebpage);

#endif






		return(parsedwebpage);
#else
		if(p=containsstring(parsedwebpage,"Today")) {
			return(&parsedwebpage[p]);

			}
		else {
			return(NULL);
			}
#endif

		}


			return(NULL);
//	return(loadedwebpage);
}

char * getdrug(char *request) {// Anoka,MN
	int mySocket;
	
	char *hostname="www.accessdata.fda.gov";
	char newrequest[126];
	int p;

	strcpy(newrequest,"Trade_Name=");
	strcat(newrequest,request);
	strcat(newrequest,"\r\n");
	strcat(newrequest,"&Table1=Rx\r\n");

	mySocket = startupClient(80, hostname);

	if (mySocket == -1) {
		shutdownClient(mySocket);
		return(NULL);
	}

	int nBytes;

	// And the actual buffers
	char inMessage[MESSAGE_SIZE];
	char outMessage[256];
	char inChar;
	char string[80];


	
//	wsprintf(outMessage,"POST http://www.accessdata.fda.gov/scripts/cder/ob/docs/temptn.cfm?Trade_Name=diovan HTTP/1.0\r\n"); 
	wsprintf(outMessage,"POST /scripts/cder/ob/docs/temptn.cfm?Trade_Name=%s HTTP/1.0\r\n",request); 
	wsprintf(string,"Host: www.accessdata.fda.gov\r\n");
	strcat(outMessage,string);
	wsprintf(string,"Content-Type: application/x-www-form-urlencoded\r\n");
	strcat(outMessage,string);
	wsprintf(string,"Accept: */*\r\n");
	strcat(outMessage,string);
	wsprintf(string,"Content-Length: %d\r\n\r\n",strlen(newrequest));
	strcat(outMessage,string);
	wsprintf(string,"%s",newrequest);
	strcat(outMessage,string);


	int n=strlen(outMessage);
	if (nBytes = send(mySocket, outMessage, strlen(outMessage), 0)==SOCKET_ERROR) {
		shutdownClient(mySocket);
		return(NULL);
		};


	//inputstring=anoka, mn


	loadedwebpagesize=0;

	// receive the reply from the server
	while(((nBytes = recv(mySocket, inMessage, sizeof(inMessage), 0))>0)&&loadedwebpagesize<(MESSAGE_BUFFER-MESSAGE_SIZE)) {
		memcpy(&loadedwebpage[loadedwebpagesize],inMessage,nBytes);
		loadedwebpagesize+=nBytes;
		}

	shutdownClient(mySocket);
	loadedwebpage[loadedwebpagesize]=0;


			int mytestints[26]={-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};

		return(parseloadedwebpage(mytestints));




//			return(NULL);
//	return(loadedwebpage);
}

// -----------------------------------------------------------------------------------
// startupClient() - a function to startup winsock and connect to a server

int startupClient(unsigned short port, const char* serverName) {
	// an error code we will use to get more information about our errors
	int error;

	WSAData wsaData;

	if ((error = WSAStartup(MAKEWORD(2, 2), &wsaData)) == SOCKET_ERROR) {
		return -1;
	}

	int mySocket = socket(AF_INET, SOCK_STREAM, 0);

	if (mySocket == SOCKET_ERROR) {
		return -1;
	}

	struct hostent *host_entry;

	if ((host_entry = gethostbyname(serverName)) == NULL) {
	}

	struct sockaddr_in server;

	// fill in the server socket info
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = *(unsigned long*) host_entry->h_addr;

	// connect to the server
	if (connect(mySocket, (sockaddr*)&server, sizeof(server)) == SOCKET_ERROR) {
		return -1;
	}

	return mySocket;
}

// -----------------------------------------------------------------------------------
// shutdownClient() - a function to shutdown a socket and clean up winsock

void shutdownClient(int clientSocket) {
	closesocket(clientSocket);
	WSACleanup();
}