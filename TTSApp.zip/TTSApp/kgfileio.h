int make_ext(char *string1,char *ext);
int readfiledelimited(FILE *fp,char *string, int maxstring,int delimiter);
int readfiledelimitedbyline(FILE *fp,char *string, int maxstring,int delimiter);
int readfilemolecule(FILE *fp,struct moleculeloadstruct *molecule);
BOOL openisylknowledge( HWND hWnd, char *szFileName, char *szFilter);
int SaveLexicals(char *filename,struct lexicalobject *sourcestrings[], int n);
int SaveAllLexicalObjects(char *szAFileName) ;
int SaveLexicalObjects(char *filename,struct lexicalobject *sourcestrings[], int n);
int SaveMoleculeObjects(char *filename,struct moleculeobject *sourcestrings[], int n);
int LoadLexicalObjects(char *filename,struct lexicalobject *sourcestrings[],int maxlexicons);

int LoadAllLexicalObjects(char *szAFileName);
int LoadAllMoleculeObjects(char *szAFileName);








