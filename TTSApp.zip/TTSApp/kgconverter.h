#define BYTE_ALIGN __declspec(align(1))


// Define the maximum number of lexical objects to store in memory
#define MAXLEXOBJECTS 500000

// Define the maximum number of lexical objects to store in memory
#define MAXMOLECULEOBJECTS 1000000


// Define the maximum number of lexical types we wlil distinguish

#define MAXLEXTYPES 5


#define BASELEXPOS 0
#define IDIOMLEXPOS 1
#define PRONLEXPOS 2
#define SYNLEXPOS 3
#define TEMPLEXPOS 4



extern struct lexicalobject *LexicalObjects[];
extern struct moleculeobject *MoleculeObjects[];



extern int lextypestarts[];
extern int lextypetotals[];

extern int LexRefDerivative;


struct moleculeloadstruct {
	char X[64];
	char R[64];
	char Y[64];
	char C[64];
	char Q[64];
	int W;
	char QAttr[64];
	int RF;
	int Flag;
	int LexID;
	};



extern int TotalLexObjects;
extern int TotalMolObjects;

LRESULT CALLBACK KGDialogProc( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam );

int OpenAndLoadKnowledgeFiles(HWND hDlg);
struct lexicalobject *GetLexicalObject(char *string);
struct lexicalobject *GetLexicalObjectAt(int LexRef);
struct moleculeobject *GetMoleculeObjectAt(int MolRef);
int AddMoleculeObject(struct moleculeloadstruct *curmolecule);
int AddTempLexicalObject(char *lexstring);
int GetLexicalReference(char *string);

int IsKnowledgeLoaded();



