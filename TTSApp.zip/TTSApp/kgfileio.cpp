#include "globals.h"
#include "ttsapp.h"
#include "stdio.h"
#include "string.h"
#include "molecule.h"
#include "kgconverter.h"
#include "lexical.h"


//-------------------------------------------------------------
// make_ext
//-------------------------------------------------------------

int make_ext(char *string1,char *ext) {
	int l=strlen(string1)-1;
	while(l>0&&string1[l]!='.') l--;

	if(l) {
		strcpy(&string1[l+1],ext);
		return(1);
	}
	else {
		return(0);
	}
}


//-------------------------------------------------------------
//-------------------------------------------------------------

int readfiledelimited(FILE *fp,char *string, int maxstring,int delimiter) {
	int a,c,done;

	a=0;
	done=0;
	do {
		c=fgetc(fp);
		if(c==160) c=32;// turn 160 into spaces
		if(c==delimiter) {
			string[a]=0;
			done=1;
			}
		else if(c==0xd) {
			string[a++]=' '; // add space
			fgetc(fp);// drop 0xa
			}
		else {
			if(isprint(c)&&c!=34) string[a++]=c; // No quotes
			}
		}
		while(!feof(fp)&&!done&&a<maxstring);

	//	if(c==0xd) fgetc(fp);

		if(done) return(1);
		else return(0);

	}

int readfiledelimitedbyline(FILE *fp,char *string, int maxstring,int delimiter) {
	int a,c,done;

	a=0;
	done=0;
	do {
		c=fgetc(fp);
		if(c==160) c=32;// turn 160 into spaces
		if(c==delimiter) {
			string[a]=0;
			done=1;
			}
		else if(c==0xd) {
			string[a]=0;
			done=1;

//			string[a++]=' '; // add space
//			fgetc(fp);// drop 0xa
			}
		else {
			if(isprint(c)&&c!=34) string[a++]=c; // No quotes
			}
		}
		while(!feof(fp)&&!done&&a<maxstring);

	//	if(c==0xd) fgetc(fp);

		if(done) return(1);
		else return(0);

	}

//-------------------------------------------------------------
//-------------------------------------------------------------

int readfilemolecule(FILE *fp,struct moleculeloadstruct *molecule) {
	char tmpstring[64];

	if(!readfiledelimited(fp,molecule->X, 64,222)) return(0);
	if(!readfiledelimited(fp,molecule->R, 64,222)) return(0);
	if(!readfiledelimited(fp,molecule->Y, 64,222)) return(0);
	if(!readfiledelimited(fp,molecule->C, 64,222)) return(0);
	if(!readfiledelimited(fp,molecule->Q, 64,222)) return(0);


	if(!readfiledelimited(fp,tmpstring, 64,222)) return(0); molecule->W=atoi(tmpstring);

	if(!readfiledelimited(fp,molecule->QAttr, 64,222)) return(0);

	if(!readfiledelimited(fp,tmpstring, 64,222)) return(0); molecule->RF=atoi(tmpstring);
	if(!readfiledelimited(fp,tmpstring, 64,222)) return(0); molecule->Flag=atoi(tmpstring);
	if(!readfiledelimited(fp,tmpstring, 64,0xd)) return(0); molecule->LexID=atoi(tmpstring);

	return(1);
	}

//-------------------------------------------------------------
// openisylknowledge enables selection of a knowledge file
//-------------------------------------------------------------


BOOL openisylknowledge( HWND hWnd, char *szFileName, char *szFilter) {
   OPENFILENAME    ofn;
    BOOL            bRetVal     = TRUE;
    TCHAR           szPath[256]       = _T("");
    DWORD           size = 256;

 
	size_t ofnsize = (BYTE*)&ofn.lpTemplateName + sizeof(ofn.lpTemplateName) - (BYTE*)&ofn;
    ZeroMemory( &ofn, ofnsize);


    ofn.lStructSize       = ofnsize;
    ofn.hwndOwner         = hWnd;    
    ofn.lpstrFilter       = szFilter;
    ofn.lpstrCustomFilter = NULL;    
    ofn.nFilterIndex      = 1;    
    ofn.lpstrInitialDir   = szPath;
    ofn.lpstrFile         = szFileName;  
    ofn.nMaxFile          = 256;
    ofn.lpstrTitle        = NULL;
    ofn.lpstrFileTitle    = NULL;    
    ofn.lpstrDefExt       = NULL;
    ofn.Flags             = OFN_FILEMUSTEXIST | OFN_READONLY | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;

    // Pop the dialog
    bRetVal = GetOpenFileName( &ofn );

	return(bRetVal);
	}

//-------------------------------------------------------------
// SaveMoleculeObjects writes the moleculr object array to disk
//-------------------------------------------------------------

int SaveMoleculeObjects(char *filename,struct moleculeobject *sourcestrings[], int n)
{
  int i;
  FILE *fp;

  if((fp=fopen(filename,"wb"))==NULL) {
	  return(0);
	}

  for ( i=0;i< n; i++) {
	fwrite(&sourcestrings[i]->R,sizeof(int),1,fp);
	fwrite(&sourcestrings[i]->Y,sizeof(int),1,fp);
	fwrite(&sourcestrings[i]->C,sizeof(int),1,fp);
	fwrite(&sourcestrings[i]->Q,sizeof(int),1,fp);
	fwrite(&sourcestrings[i]->W,sizeof(char),1,fp);
	fwrite(&sourcestrings[i]->QAttr,sizeof(int),1,fp);
	fwrite(&sourcestrings[i]->RF,sizeof(char),1,fp);
	fwrite(&sourcestrings[i]->Flag,sizeof(char),1,fp);
	fwrite(&sourcestrings[i]->LexID,sizeof(short),1,fp);
	}
  
  fclose(fp);
  return(1);
 }

//-------------------------------------------------------------
// SaveLexicalObjects write the lexical objects array to disk
//-------------------------------------------------------------

int SaveLexicalObjects(char *filename,struct lexicalobject *sourcestrings[], int n)
{
  int i;
  FILE *fp;

  if((fp=fopen(filename,"wb"))==NULL) {
	  return(0);
	}

  for ( i=0;i< n; i++) {
	fwrite(&sourcestrings[i]->bytecount,sizeof(char),1,fp);
	fwrite(&sourcestrings[i]->idiomcount,sizeof(char),1,fp);
	fwrite(&sourcestrings[i]->moleculecount,sizeof(short),1,fp);
	fwrite(sourcestrings[i]->bytes,sizeof(char),sourcestrings[i]->bytecount,fp);
	if(sourcestrings[i]->idiomcount) fwrite(sourcestrings[i]->idioms,sizeof(int),sourcestrings[i]->idiomcount,fp);
	if(sourcestrings[i]->moleculecount) fwrite(sourcestrings[i]->molecules,sizeof(int),sourcestrings[i]->moleculecount,fp);

	//fprintf(fp,sourcestrings[i]->bytes);
//	fputc(0xd,fp);
//	fputc(0xa,fp);
	}
  
  fclose(fp);
  return(1);
 }

int SaveAllLexicalObjects(char *szAFileName)  {

	char szOutFileName[128];
	char szExt[16];

	strcpy(szOutFileName,szAFileName);
	for(int a=0;a<MAXLEXTYPES;a++) {
		wsprintf(szExt,"lx%d",a);
		make_ext(szOutFileName,szExt);
		lextypetotals[a]=SaveLexicalObjects(szOutFileName,&LexicalObjects[lextypestarts[a]],lextypetotals[a]);
		}

	return(1);
	}

//-------------------------------------------------------------
// SaveLexicals writes the string values of the sorted lexical
// array to disk.
//-------------------------------------------------------------

int SaveLexicals(char *filename,struct lexicalobject *sourcestrings[], int n)
{
  int i;
  FILE *fp;

  if((fp=fopen(filename,"wb"))==NULL) {
	  return(0);
	}

  for ( i=0;i< n; i++) {
    fprintf(fp,"%d: %s",i,sourcestrings[i]->bytes);
//	fprintf(fp,sourcestrings[i]->bytes);
	fputc(0xd,fp);
	fputc(0xa,fp);
	}
  
  fclose(fp);
  return(1);
 }

//-------------------------------------------------------------
// LoadLexicalObjects reads lexical objects from disk previously
// saved using SaveLexicalObjects
//-------------------------------------------------------------

int LoadLexicalObjects(char *filename,struct lexicalobject *sourcestrings[],int maxlexicons)
{
//  int l;
  FILE *fp;
  int n;
//  char string[128];

  if((fp=fopen(filename,"rb"))==NULL) {
	  return(0);
	}

  n=0;
  while(!feof(fp)&&(n<maxlexicons)) {

	sourcestrings[n]=newlexicalobject();

	if(fread(&(sourcestrings[n]->bytecount),sizeof(char),1,fp)) {
		fread(&sourcestrings[n]->idiomcount,sizeof(char),1,fp);
		fread(&sourcestrings[n]->moleculecount,sizeof(short),1,fp);

		sourcestrings[n]->bytes=new char[sourcestrings[n]->bytecount];
		if(sourcestrings[n]->idiomcount) sourcestrings[n]->idioms=new int[sourcestrings[n]->idiomcount];
		if(sourcestrings[n]->moleculecount) sourcestrings[n]->molecules=new int[sourcestrings[n]->moleculecount];

		fread(sourcestrings[n]->bytes,sizeof(char),sourcestrings[n]->bytecount,fp);
		if(sourcestrings[n]->idiomcount) fread(sourcestrings[n]->idioms,sizeof(int),sourcestrings[n]->idiomcount,fp);
		if(sourcestrings[n]->moleculecount) fread(sourcestrings[n]->molecules,sizeof(int),sourcestrings[n]->moleculecount,fp);
		n++;
		}

	
	}
	 
	

  fclose(fp);

return(n);
 }




int LoadAllLexicalObjects(char *szAFileName)  {

	char szOutFileName[128];
	char szExt[16];

	strcpy(szOutFileName,szAFileName);
	for(int a=0;a<MAXLEXTYPES;a++) {
		wsprintf(szExt,"lx%d",a);
		make_ext(szOutFileName,szExt);
		lextypetotals[a]=LoadLexicalObjects(szOutFileName,&LexicalObjects[lextypestarts[a]],lextypestarts[a+1]-lextypestarts[a]);
		}

	return(1);
	}

//-------------------------------------------------------------
// LoadMoleculeObjects reads the molecule object array from disk
//-------------------------------------------------------------

int LoadMoleculeObjects(char *filename,struct moleculeobject *sourcestrings[], int maxmolecules)
{
  int n,nr,tp;
  FILE *fp;
  char tmpbuffer[2600];

  if((fp=fopen(filename,"rb"))==NULL) {
	  return(0);
	}

  n=0;
  while(!feof(fp)&&(n<maxmolecules)) {


	
#if 1
	if(nr=fread(tmpbuffer,1,2500,fp)) {

		tp=0;
		while(tp<nr) {

		sourcestrings[n]=new struct moleculeobject;


		memset(sourcestrings[n],0,sizeof(moleculeobject));
		
		memcpy(&sourcestrings[n]->R,&tmpbuffer[tp+0],sizeof(int));
		memcpy(&sourcestrings[n]->Y,&tmpbuffer[tp+4],sizeof(int));
		memcpy(&sourcestrings[n]->C,&tmpbuffer[tp+8],sizeof(int));
		memcpy(&sourcestrings[n]->Q,&tmpbuffer[tp+12],sizeof(int));
		memcpy(&sourcestrings[n]->W,&tmpbuffer[tp+16],sizeof(char));
		memcpy(&sourcestrings[n]->QAttr,&tmpbuffer[tp+17],sizeof(int));
		memcpy(&sourcestrings[n]->RF,&tmpbuffer[tp+21],sizeof(char));
		memcpy(&sourcestrings[n]->Flag,&tmpbuffer[tp+22],sizeof(char));
		memcpy(&sourcestrings[n]->LexID,&tmpbuffer[tp+23],sizeof(short));



		n++;
		tp+=25;
		}

		}
#else

	if(fread(&sourcestrings[n]->R,sizeof(int),1,fp)) {
		fread(&sourcestrings[n]->Y,sizeof(int),1,fp);
		fread(&sourcestrings[n]->C,sizeof(int),1,fp);
		fread(&sourcestrings[n]->Q,sizeof(int),1,fp);
		fread(&sourcestrings[n]->W,sizeof(char),1,fp);
		fread(&sourcestrings[n]->QAttr,sizeof(int),1,fp);
		fread(&sourcestrings[n]->RF,sizeof(char),1,fp);
		fread(&sourcestrings[n]->Flag,sizeof(char),1,fp);
		fread(&sourcestrings[n]->LexID,sizeof(short),1,fp);
		n++;
		}
#endif

	}
  
  fclose(fp);
  return(n);
 }

int LoadAllMoleculeObjects(char *szAFileName)  {
	char szOutFileName[128];

	strcpy(szOutFileName,szAFileName);


    make_ext(szOutFileName,"mol");

	TotalMolObjects=LoadMoleculeObjects(szOutFileName,MoleculeObjects,MAXMOLECULEOBJECTS);

	if(TotalMolObjects) return(1);
	else return(0);
	}

