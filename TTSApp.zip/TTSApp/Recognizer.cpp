#include "globals.h"
#include "Recognizer.h"
#include "kgconverter.h"
#include "ctype.h"
#include "string.h"
#include "morphology.h"
#include "molecule.h"
#include "lexical.h"

#define MAXWORDS 512

//struct RZWordStruct RZWordQueue[MAXRZWORDS];

#define MAXSENTENCEWORDS 1024

//int wordqueue[MAXWORDS];
//int numwordqueue;

struct sentenceobject sentences[MAXSENTENCEWORDS];


int RZRecognizeWords(char *sentence,int *wordqueue,int *wordsadded,int *idiomqueue,int *idiomsadded,int *moleculequeue,int *moleculesadded) {
	char string[256];
	char seps[]   = " \t\n";
	char *token;
	int lref;
	int n=0;
	int n2=0;
	int n3=0;
	int wordexists;
	char *matchpos;

	strcpy(string,sentence);

	token = strlwr(strtok( string, seps ));
	while( token != NULL ){
		if((lref=GetLexicalReference(token))!=-1) {

			wordexists=0;
			for(int a=0;a<n;a++) { // See if word already exists in queue
				if(wordqueue[a]==lref) {
					wordexists=1;
					break;
					}
				}

			wordqueue[n++]=lref;

			if(!wordexists) {

				struct lexicalobject *lobj=GetLexicalObjectAt(lref);

				if(lobj) {

					for(int a=0;a<lobj->moleculecount;a++) {
						
						moleculequeue[n2++]=lobj->molecules[a];

						moleculeobject *tmpmo=GetMoleculeObjectAt(lobj->molecules[a]);

						if(tmpmo->R==LexRefDerivative) { // Watch for root and add to word list
							wordqueue[n++]=tmpmo->Y;
							}
						}

					}

				}

			}
		else {

#if 0
			char *retstring=NULL;
			if(MOFindBaseWord(token,retstring)) {
				if((lref=GetLexicalReference(retstring))!=-1) {
					wordqueue[n++]=lref;
					}
				//wordqueue[n++]=lref;
				}
#endif

			}

		/* Get next token: */
		token = strtok( NULL, seps );

		}

// Now qualify Idioms

	char *lwrsentence=strlwr(sentence);
	
	for(int a=0;a<n;a++) {
		struct lexicalobject *lobj=GetLexicalObjectAt(wordqueue[a]);
		for(int b=0;b<lobj->idiomcount;b++) {
				int c=lobj->idioms[b];
				struct lexicalobject *lobj2=GetLexicalObjectAt(c);
				char *istring=lobj2->bytes;
				int numiwordsfound=0;
				int numiwordsnotfound=0;
				char *sentencepos=lwrsentence; // for moving through sentence matching tokens

				strcpy(string,istring);
				token = strtok( string, seps );
				while( token != NULL ){

				if(matchpos=strstr(sentencepos,token)) {
					numiwordsfound++;
					sentencepos=matchpos;
					}
				else {
					numiwordsnotfound++;
					}
						/* Get next token: */
						token = strtok( NULL, seps );
					}


				if(numiwordsnotfound==0) {
						idiomqueue[n3++]=lobj->idioms[b];

					}
				else if(numiwordsfound/numiwordsnotfound>=2) {
						idiomqueue[n3++]=lobj->idioms[b];
					}
				}
		}

	*wordsadded=n;
	*moleculesadded=n2;
	*idiomsadded=n3;

return(n);
}


int RZSetParagraph(recognizerobject *robject,char *paragraph) {
	robject->paragraph=paragraph;
	robject->paragraph_pos=0;
	return(1);
	}	

int RZGetNextSentence(recognizerobject *robject,char *dest_sentence,int maxlen) {
	int startpos=robject->paragraph_pos;
	int endpos=startpos;
	char *pstring=&robject->paragraph[startpos];
	char *p=pstring;
	int l;


	int done=0;

	while(!done) {
		if(*p==0) {//End of paragraph
			done=1;
			}
		else if(*p=='.') {
			if(*(p+1)==' '||*(p+1)==0xd||*(p+1)==0x0||isupper(*(p+1))) {
				done=1;
				}
			}
		else if(*p=='?') {
				done=1;
			}

		p++;
		endpos++;
		}
	
	l=endpos-startpos;
	if(l<2) return(0);
	robject->paragraph_pos+=l;

	if(l>(maxlen-1)) l=maxlen-1;

	strncpy(dest_sentence,pstring,l);
	dest_sentence[l]=0;


	return(1);
	}	