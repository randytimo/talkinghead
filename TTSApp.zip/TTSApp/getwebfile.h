char *getwebfile(char *hostname,char *request);
char *parseloadedwebpage(int *parseconditions);
char * getweather(char *request);
char * getdrug(char *request);
