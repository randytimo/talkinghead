struct sentenceobject {
	int numberofwords;
	struct wordobject* wordqueue;
	struct wordobject* idiomqueue;
	struct wordobject* moleculequeue;
	};
