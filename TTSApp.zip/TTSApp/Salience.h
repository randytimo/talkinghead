char * salience_search(char *filename);
char * filetomemory(char *filename);
