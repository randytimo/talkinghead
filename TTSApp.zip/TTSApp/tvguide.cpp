2  KTCAThis Old House Hour (CC)Alone in the Wilderness
                        3  AMC<<ThunderballThe Terminator>>
                        4  WCCONews (CC)Wheel of Fortune (CC)Star Search (CC)
                        5  KSTPNews (CC)FriendsWonderful World of Disney: The 
                        Parent Trap>>
                        6  METRO6<< Metro 6>>
                        7  DISNEYThat's So RavenLizzie McGuire (CC)Full-Court 
                        Miracle (CC)>
                        8  KPXMGaither Homecoming (CC)Just Cause (CC)
                        9  KMSPNHL Hockey
                        10  WFTCSpace Rage
                        11  KARENews (CC)Minnesota BoundTracy Morgan (CC)Whoopi 
                        (Repeat) (CC)
                        12  TBSSomething to Talk About
                        13  WGNFresh Prince of Bel-Air (CC)Fresh Prince of 
                        Bel-Air (CC)Stellar Gospel Music Awards>
                        14  COMTV<<Paid Programming>>
                        15  PUBACC<<Public Access Programming>>
                        16  GOVACC<<Government Access Programming>>
                        17  KTCILawrence WelkEd Sullivan
                        6:00PM 6:30PM 7:00PM 7:30PM 

                        18  QVC<Joan Rivers Classics CollectionGourmet Holiday>
                              Free CD-Burner upgrade with any new Dell Home PC. 
                              Details Click for offer details.

                        19  KSTCKing of Queens (CC)Married...With Children 
                        (CC)Walker, Texas Ranger (CC)
                        23  KMWBn ContrastEbert & RoeperMutant X
                        27  ABCFAM<Housesitter (CC)Beverly Hills Cop II>
                        28  TWC<<PM EditionStorm StoriesStorm Stories

                        29  APLRoad to the National ChampionshipDog Show (CC)>>

                        30  UNILa Hora DerbezS�bado Gigante>>
                        31  FX<Dragnet (CC)Dude, Where's My Car? (CC)>
                        33  HGTVRoom by Room (CC)Country StyleSensible 
                        ChicDecorating Cents (CC)
                        34  E!Fashion PoliceCelebrities Uncensored
                        35  CSPANAmerica and the CourtsAmerican Perspectives>>
                        36  BET<106th & Park: Top 10BET.COM Countdown 
                        (Repeat)Maad Sports: Super Bowl Special (Repeat)
                        37  BRAVOGolden Globe Arrivals (CC)Golden Globe Awards 
                        (CC)>>
                        38  EWTNDaily MassTwo Suitcases: St. Giuseppina Bakhita
                        38  INSPOff air
                        6:00PM 6:30PM 7:00PM 7:30PM 

                        39  CSPAN2Encore BooknotesPublic Lives
                        40  TLCWhile You Were OutTrading Spaces
                        41  LIFEHer Hidden Truth (CC)
                        42  COMEDYTrigger Happy TV (CC)Trigger Happy TV (CC)Reno 
                        911! (CC)Reno 911! (CC)
                        43  NICKSpongeBob SquarePantsSpongeBob SquarePantsAll 
                        Grown UpRomeo!
                        44  TNT<<The MummyThe Matrix (CC)>>
                        45  USATraffic: The Miniseries
                        46  ESPNNFL PrimetimeCollege Basketball>
                        47  ESPN2NHL Hockey
                        48  FSN<College BasketballCollege Hockey>>
                        49  TCM<<The Dirty Dozen (CC)Vertigo>>
                        50  CNNCapital GangCNN Presents
                        51  HN<<Headline News>>
                        52  CNBCOutside the BoxSuze Orman
                        53  FNCFox Report Saturday (CC)From the Heartland (CC)
                        57  RELIG<<Religious Access Programming>>
                        58  EDUACC<<Educational Access Programming>>
                        6:00PM 6:30PM 7:00PM 7:30PM 

                        60  EDUACC<<Educational Access Programming>>
                        61  EDUACC<<Educational Access Programming>>
                        62  MTVOsbournesTo Be Announced`Til Death Do Us Part: 
                        Carmen and Dave`Til Death Do Us Part: Carmen and Dave
                        63  VH1SpotlightBest Week EverI Love the '80s
                        64  SPIKERide with Funkmaster FlexRide with Funkmaster 
                        Flex2004 Lynn Swann All-Star MVParty
                        65  GAC<Top 20 Country CountdownGrand Ole Opry Live
                        66  A&ECity Confidential (CC)American Justice (CC)

                        67  DSCDouble AgentsDog Show (CC)>>

                        68  SCI-FIJohn Carpenter's Vampires
                        69  HISTExtreme History with Roger Daltrey (CC)Mail Call 
                        (CC)High Rollers: A History of Gambling (CC)>

                        70  TVGCTV Guide Close UpTV Talk

                        119  OXYGN<Tale of Two WivesOne True Thing>>
                        120  NOG/NReal AccessDegrassi: The Next Generation 
                        (CC)Radio Free Roscoe
                        6:00PM 6:30PM 7:00PM 7:30PM 

                        121  D-KIDSMystery HuntersMystery HuntersTruth or 
                        ScareTruth or Scare
                        122  TOONDLegend of Tarzan (CC)Fillmore (CC)Weekenders 
                        (CC)Recess (CC)
                        128  BNEWSBloomberg News
                        135  MTV2Stoopid, Crazy, Cool: Most Outrageous Sports 
                        MomentsTrue LifeTom Green Uncensored
                        137  TRIOThe MothThe Moth
                        161  GAMEWin, Lose or DrawLove ConnectionWho Wants to Be 
                        a Millionaire (CC)
                        162  BBCMy HeroKeeping Up AppearancesThe Vice
                        163  TVLANDCheers (CC)Cheers (CC)Carol Burnett and 
                        FriendsAll in the Family
                        183  style.Style StarStyle StarThe Look for LessThe Look 
                        for Less
                        201  D-HOMEBurger Meister with Marcel DesaulniersCreole 
                        Cooking with Leah ChaseTailgate PartyTailgate Party
                        202  DIYTo Be AnnouncedDIY to the RescueHome IQ
                        203  FLNGreat AdventureFantasy CampCastaways in Italy
                        215  GASScaredy CampRobot WarsPlay 2 ZSK8-TV
                        220  DHCCritical HourDiagnosis: Unknown
                        222  FITTVWorld's Greatest SpasSpa FindersPeak 
                        Performance
                        230  TBNCoral RidgeIn Touch (CC)
                        231  ILIFENews (CC)To Be AnnouncedTo Be Announced
                        6:00PM 6:30PM 7:00PM 7:30PM 

                        271  DTIMESBeijing CrackdownRaising the Flag
                        272  SCICHExtreme EarthAmerica's Great Parks
                        273  NGCNational Geographic: On AssignmentLiving 
                        DangerouslyCrittercam: WildTech AdventuresCrittercam: 
                        WildTech Adventures
                        274  D-WINGFasten Your Seatbelts, PleaseTravel Tech: 
                        Private Jets Revealed
                        275  BIOPaparazzi! (CC)Bio at the MoviesHulk Hogan: 
                        American Made
                        276  HIS-IHistory ExplorerHistory ExplorerWorld Justice
                        294  TechtvNerd NationFuture Fighting MachinesFuture 
                        Fighting Machines
                        401  FSWOSky Sports NewsEnglish League Soccer>
                        402  ESPNN<<ESPNEWS>>
                        403  ESPNC<SportsCenturySportsCenturySportsCentury
                        404  OLNSkiingBull Riding
                        405  GOLFPlaying Lessons from the ProsGolf Central 
                        (CC)PGA Merchandise Show
                        406  OUTDRClosing the DistanceAmerican BirdhunterFour 
                        WheelerHot Rod TV
                        408  SPEED<<Auto Racing
                        410  ESPN2NHL Hockey
                        411  ESPAP<<ESPN2 Alternate Programming>>
                        471  VH1CO<<VH1 Country Music Videos>>
                        6:00PM 6:30PM 7:00PM 7:30PM 

                        473  VH1CL60's GenerationAll-Star Jams
                        476  FUSEUraniumRockzillaNo. 1 Countdown
                        502  WE<Born YesterdayThe Good Mother>
                        503  IFC<<Go Tigers!Dinner for Five (CC)Branded to Kill>
                        504  LMN<Danielle Steel's `Mixed Blessings'She Cried No>
                        506  FMC<Class ActionThe French Connection>>
                        517  ENCRe<Bio-DomeAlien>
                        519  LOVEe<Love Is All There IsIn Love and War>
                        521  MYSTe<Shattered (CC)Just Cause>
                        523  WSTNeGunsmokeThe Wild, Wild West Revisited>
                        527  TRUEe<Jackie Chan: My StuntsMayflower Madam>
                        529  ACTNeKull the ConquerorDark Angel>
                        533  STZeDaylight
                        534  STZHDeDaylight
                        535  STZeDaylight
                        540  STZKe<Pokemon 4EverSpaced Invaders>
                        550  HBOe<Chain ReactionHalf Past Dead>
                        6:00PM 6:30PM 7:00PM 7:30PM 

                        552  HBO2e<Running on Empty (CC)Swimfan
                        554  HBOSG<<The First Wives ClubMuriel's Wedding
                        556  HBOFA Kid in King Arthur's CourtBlack Knight (CC)>>
                        562  MAXe<Super Troopers (CC)From Hell (CC)>
                        563  MAXHDe<Super Troopers (CC)From Hell (CC)>
                        564  MOMAXe<<Life or Something like ItThe Sweetest Thing
                        575  SHOeBandits (CC)
                        577  SHOT<<In the Army Now (CC)Forget Paris
                        579  SHOCResurrection Blvd. (CC)Resurrection Blvd. 
                        (CC)Resurrection Blvd. (CC)
                        581  SHOXOut in FiftyThe Sweeper>
                        590  TMCe<Festival in CannesCrossroads (CC)>
                        592  TMCX<<Lisa Picard Is FamousIllegally Yours
                        801  iN1English League Soccer
                        802  iN2Marilyn Manson: Guns, Gods and GovernmentMarilyn 
                        Manson: Guns, Gods and Government>
                        803  iN3<Charlie's Angels: Full ThrottleThe League of 
                        Extraordinary Gentlemen>
                        804  iN4<<Bruce AlmightyRugrats Go Wild
                        805  iN5Rugrats Go WildRugrats Go Wild>
                        6:00PM 6:30PM 7:00PM 7:30PM 

                        844  HTNETIt's a KillerQuality Time>
                        851  SPICECall Her Princess IISensualist>
                        853  PLBYPrivate Calls (CC)Weekend Flash (CC)Sex Under 
                        Hot Lights (CC)
                        806  iN6X2: X-Men United