struct wordobject {
	int lexref;
	int flag;
	int weight;
	void *nextwordobject;
	};

struct wordobject *newwordobject();

