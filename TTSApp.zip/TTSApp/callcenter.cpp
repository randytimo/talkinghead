#include<windows.h>
#include<iostream>
#include<string>
#include<sql.h>
#include<sqlext.h>
#include "Worldfacts.h"
#include "kdbase.h"
#include "ttsapp.h"

char currentsecuritycode[32];
char currentpostalcode[32];
char currentcontactname[64];
int currentdonotcall;
int incall=0;
int callstate;
int callpintrys=0;
int callziptrys=0;

HWND cchWnd;

CTTSApp *gCTTSApp;

char outputstring[256];

int callcentersilence=0;
int callcentermute=0;
int callcenterresponsestate=0;



int numidlemessages=7;

char idlesmessages[][256]={
	"Please enter your 6 digit PIN number.",
	"Please enter the last 3 digits or your zip code.",
	"Please choose billing, account maintenance, or customer service",
	"Would you like to review last month's bill or review your minutes used?",
	"Would you like to review your features or add new features?",
	"What type of problem are you having with your service?",
	"Caller I Dee, Security Screen, Call Waiting, Voice Mail, Custom Ringing, 3 Way Calling, Call Forwarding, or Last Call Return"
	};





int callcenterplansavailable(){
	SetDlgItemText( cchWnd, IDE_EDITBOX, "Plan A: 1500 minutes for $45.00,Plan A: 2500 minutes for $65.00,Plan A: 5000 minutes for $80.00.");
	gCTTSApp->HandleSpeak();
	return(1);
};


int callcenterfunctionsavailable(){
	SetDlgItemText( cchWnd, IDE_EDITBOX, "You may request to be on the do not call list, to get last month's bill, or to get last month's minutes.");
	gCTTSApp->HandleSpeak();
	return(1);
	}

int	callcenterfunctionsselected(){
char string[256];

	if(currentdonotcall) {
		strcpy(string,"You are currently on the do not call list. ");
		}
	else {
		strcpy(string,"You are currently not on the do not call list. ");
		}

	SetDlgItemText( cchWnd, IDE_EDITBOX, string);
	gCTTSApp->HandleSpeak();

	return(1);
	}


int callcenterstatemessage(){
	if(callstate<numidlemessages) {
		SetDlgItemText( cchWnd, IDE_EDITBOX, idlesmessages[callstate]);
		gCTTSApp->HandleSpeak();
		}
		return(1);


}

int callcentertimer() { // Gets called 100 times/sec during call

	callcentersilence++;

	if(callcentersilence==1000) {
		callcenterstatemessage();
		}

	else if(callcentersilence==2000) {
		SetDlgItemText( cchWnd, IDE_EDITBOX, "If you are finished, please hang up.");
		gCTTSApp->HandleSpeak();
		}
	else if(callcentersilence==2400) {
		incall=0;
		SetDlgItemText( cchWnd, IDE_EDITBOX, "Call complete, thank you.");
		gCTTSApp->HandleSpeak();

		}


	if(callcentermute) callcentermute--;


	return(1);
	}

int callcentermutetime(int hundredthsecs) {

	callcentermute=hundredthsecs;

	return(1);
	}

int callcenterresetsilence() {

	callcentersilence=0;

	return(1);
	}

int callcentermuted() {

	if(callcentermute) return(1);
	else return(0);

	}

int callcentersetdonotcall(int onoff) {
	if(onoff) {
	setdbentry("c:\\Northwind.mdb","Customers","DoNotCall","True","PIN",currentsecuritycode);
	currentdonotcall=1;
	}
	else {
	setdbentry("c:\\Northwind.mdb","Customers","DoNotCall","False","PIN",currentsecuritycode);
	currentdonotcall=0;
	}
	return(1);
	}





char *extractonlydigits(char *inputstring) {

	int b=0;

	int l=strlen(inputstring);

	for(int a=0;a<l;a++) {

		if(isdigit(inputstring[a])) {
			outputstring[b++]=inputstring[a];
			}

		}

	if(b) {
			outputstring[b++]=0;
			return(outputstring);

		}
	
	return(NULL);


	}



int callcenterinitialization(CTTSApp *pCTTSApp,HWND hWnd) {

	gCTTSApp=pCTTSApp;
	cchWnd=hWnd;
	callstate=0;
	callpintrys=0;
	callziptrys=0;

	return(1);
	}


int callcentersecuritycode(char *resulttext){
	char string[128];
    char string2[80];

	if(quack("c:\\Northwind.mdb","Customers","ContactName","PIN",extractonlydigits(resulttext),string)) {


 //   SetDlgItemText( cchWnd, IDE_EDITBOX, string );
//	gCTTSApp->HandleSpeak();
	strcpy(currentsecuritycode,extractonlydigits(resulttext));
	strcpy(currentcontactname,string);



	if(quack("c:\\Northwind.mdb","Customers","PostalCode","PIN",currentsecuritycode,string)) {
		strcpy(currentpostalcode,extractonlydigits(string));

		}

	if(quack("c:\\Northwind.mdb","Customers","DoNotCall","PIN",currentsecuritycode,string)) {
		if(string[0]=='T'||string[0]=='t') currentdonotcall=1;
		else currentdonotcall=0;

		}




	return(1);


	}

	return(0);

};


int callcenterlastmonthbill(){
	char string[128];

	char string2[128];

	if(quack("c:\\Northwind.mdb","Customers","LastMonth","PIN",currentsecuritycode,string)) {

		wsprintf(string2,"Your bill for last month was $%s.",string);
	SetDlgItemText( cchWnd, IDE_EDITBOX, string2);
	gCTTSApp->HandleSpeak();



		}


	return(0);
	}

int callcenterlastmonthminutes(){
	char string[128];

	char string2[128];

	if(quack("c:\\Northwind.mdb","Customers","Hours","PIN",currentsecuritycode,string)) {

		wsprintf(string2,"Your total minutes for last month were %s.",string);

	SetDlgItemText( cchWnd, IDE_EDITBOX, string2);
	gCTTSApp->HandleSpeak();



		}


	return(0);
	}




int callcenterzipcode(char *resulttext){

	char *instring=extractonlydigits(resulttext);


	if(instring) {

	int l1=strlen(instring);
	int l2=strlen(currentpostalcode);

	if(l1<3||l2<3) return(0);

	if(!strncmp(&instring[l1-3],&currentpostalcode[l2-3],3)) {
		return(1);
		}
	}

	return(0);

};
	