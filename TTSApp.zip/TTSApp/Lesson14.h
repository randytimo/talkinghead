#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag);
GLvoid KillGLWindow(GLvoid);								// Properly Kill The Window
int DrawGLScene(GLvoid);									// Here's Where We Do All The Drawing
extern HDC			hDC;		// Private GDI Device Context
extern HWND		hWnd;		// Holds Our Window Handle

extern int openglon;
extern int faceon;
extern int transphead;
extern int hcountdest;

GLvoid glPrint(const char *fmt, ...);					// Custom GL "Print" Routine

