struct moleculeobject {
	int R;
	int Y;
	int C;
	int Q;
	unsigned char W;
	int QAttr;
	unsigned char RF;
	unsigned char Flag;
	unsigned short LexID;
	void *nextmoleculeobject;
	};


struct moleculeobject *newlmoleculeobject();
