#include <windows.h>		// Header File For Windows
#include <stdio.h>			// Header File For Standard Input/Output
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

int LoadGLTextures();									// Load Bitmaps And Convert To Textures
AUX_RGBImageRec *LoadBMP(char *Filename);				// Loads A Bitmap Image
int DrawGLLogo(GLvoid);									// Here's Where We Do All The Drawing

