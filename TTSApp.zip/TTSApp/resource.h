//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ttsapp.rc
//
#define IDS_SAVE_NOTIFY                 1
#define IDS_NOTIFY_TITLE                2
#define IDS_SAVE_ERROR                  3
#define IDS_AUDIOOUT_ERROR              4
#define IDS_VOICE_INIT_ERROR            4
#define IDS_UNSUPPORTED_FORMAT          5
#define IDI_APPICON                     101
#define IDD_MAIN                        101
#define IDB_MICFULL                     127
#define IDB_MICEYESCLO                  128
#define IDB_MICEYESNAR                  129
#define IDB_MICMOUTH10                  148
#define IDB_MICMOUTH11                  149
#define IDB_MICMOUTH12                  150
#define IDB_MICMOUTH13                  151
#define IDB_MICMOUTH2                   152
#define IDB_MICMOUTH3                   153
#define IDB_MICMOUTH4                   154
#define IDB_MICMOUTH5                   155
#define IDB_MICMOUTH6                   156
#define IDB_MICMOUTH7                   157
#define IDB_MICMOUTH8                   158
#define IDB_MICMOUTH9                   159
#define IDD_ABOUT                       161
#define IDB_BITMAP1                     167
#define IDD_DIALOG1                     168
#define IDD_IMPWIZARD                   169
#define IDB_BITMAP2                     170
#define IDB_BITMAP3                     171
#define IDE_EDITBOX                     1000
#define IDC_ABOUT_TTSAPP_VERSION        1000
#define IDC_MOUTHPOS                    1001
#define IDB_SPEAK                       1002
#define IDB_PAUSE                       1003
#define IDB_STOP                        1004
#define IDC_EVENTS                      1006
#define IDC_DEBUG                       1007
#define IDC_SPEAKXML                    1008
#define IDB_OPEN                        1009
#define IDC_COMBO_VOICES                1011
#define IDB_RESET                       1012
#define IDC_RATE_SLIDER                 1014
#define IDC_VOLUME_SLIDER               1015
#define IDC_COMBO_OUTPUT                1018
#define IDC_SAVETOWAV                   1020
#define IDB_SPEAKWAV                    1021
#define IDC_CHARACTER                   1023
#define IDB_SKIP                        1026
#define IDC_SKIP_EDIT                   1031
#define IDC_SKIP_SPIN                   1032
#define IDC_ABOUT                       1033
#define IDC_BUTTON1                     1036
#define IDC_BUTTON2                     1037
#define IDC_EDIT1                       1038
#define IDC_BUTTON3                     1039
#define IDC_EDIT2                       1040
#define IDC_BUTTON11                    1040
#define IDC_IHEARD                      1041
#define IDC_BUTTON12                    1041
#define IDC_BUTTON4                     1042
#define IDC_LIST3                       1045
#define IDC_BUTTON5                     1046
#define IDC_BUTTON6                     1047
#define IDC_BUTTON7                     1048
#define IDC_BUTTON8                     1049
#define IDC_BUTTON9                     1050
#define IDC_MOLECULEFILENAME            1053
#define IDC_LIST1                       1054
#define IDC_TOTALLEXICALITEMS           1055
#define IDC_LEXREF                      1056
#define IDC_STATUS                      1057
#define IDC_LIST2                       1058
#define IDC_BUTTON10                    1058
#define IDC_COMBO1                      1059
#define IDC_RADIO1                      1060
#define IDC_RADIO2                      1061
#define IDC_RADIO3                      1062
#define IDC_EDIT3                       1063
#define IDC_EDIT4                       1064
#define IDC_EDIT5                       1065
#define IDC_EDIT6                       1066
#define IDC_PICTURE                     1067
#define IDC_RADIO4                      1068
#define IDC_EDIT7                       1072
#define IDC_EDIT8                       1073
#define IDC_EDIT9                       1074
#define IDC_EDIT10                      1075
#define IDC_EDIT11                      1076
#define IDC_EDIT12                      1077
#define IDC_TREE2                       1078
#define IDC_EDIT13                      1079

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        173
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1080
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
