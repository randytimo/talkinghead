extern char currentsecuritycode[];
extern char currentpostalcode[];
extern char currentcontactname[];

extern int incall;
extern int callstate;
extern int callpintrys;
extern int callziptrys;


extern int callcentersecuritycode(char *resulttext);
extern int callcenterzipcode(char *resulttext);
extern int callcenterinitialization(CTTSApp *pCTTSApp,HWND hWnd);
int callcentersetdonotcall(int onoff);
int callcentertimer(); // Gets called 100 times/sec during call
int callcentermutetime(int hundredthsecs);
int callcentermuted();
int callcenterresetsilence();
int callcenterfunctionsavailable();
int callcenterfunctionsselected();
int callcenterlastmonthminutes();
int callcenterlastmonthbill();
int callcenterplansavailable();
int callcenterstatemessage();







	