#include "globals.h"
#include "ttsapp.h"
#include "stdio.h"
#include "string.h"
#include "kgfileio.h"
#include "srmatrix.h"


struct SRMobject *newSRMobject(){
	struct SRMobject *tempso;

	tempso=new SRMobject;

	if(tempso) {

		tempso->NxName=0;
		tempso->NxRef=0;
		tempso->NxType=0;
		tempso->Parent=0;
		tempso->Status=0;
		tempso->BaseAddr=0;
		tempso->VectorMag=0;
		tempso->VectorDir=0;
		tempso->CreatedTime=0;
		tempso->LastUpdated=0;
		tempso->nextSRMobject=NULL;

		}

	return(tempso);


	}

struct SMMx *newSMMx(){
	struct SMMx *tempsm;

	tempsm=new SMMx;

	if(tempsm) {
		tempsm->numSRMobjects=0;
		tempsm->srm=NULL;
		}
	return(tempsm);
	}



