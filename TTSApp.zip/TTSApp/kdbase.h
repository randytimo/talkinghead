int checkforbirthstone(char *sentence,char *retstring);
int  quack(char *accessdbname, char *tablename, char *selectcolumn, char *matchcolumn, char *matchstring,char *retstring);
int checkforsongs(char *sentence,char *retstring);
int checkforsports(char *sentence,char *retstring);
int  quack2(char *accessdbname, char *tablename, char *selectcolumn, char *matchcolumn, char *matchstring, char *matchcolumn2, char *matchstring2,char *retstring);
int checkforbirthday(char *sentence,char *retstring);
int  quack3(char *accessdbname, char *tablename, char *selectcolumn, char *matchcolumn, char *matchstring,char *retstring);
int checkforbibleverse(char *sentence,char *retstring);
int checkfortvlisting(char *sentence,char *retstring);
int  setdbentry(char *accessdbname, char *tablename, char *setcolumn,char *setvalue, char *matchcolumn, char *matchstring);







