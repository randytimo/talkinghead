
#include <windows.h>		// Header File For Windows
#include <math.h>			// Header File For Windows Math Library
#include <stdio.h>			// Header File For Standard Input/Output
#include <stdarg.h>			// Header File For Variable Argument Routines
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

#include "lesson6.h"

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

GLuint	base;				// Base Display List For The Font Set
GLfloat	rot;				// Used To Rotate The Text

int openglon=0;

bool	keys[256];			// Array Used For The Keyboard Routine
bool	active=TRUE;		// Window Active Flag Set To TRUE By Default
bool	fullscreen=TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default

GLYPHMETRICSFLOAT gmf[256];	// Storage For Information About Our Outline Font Characters

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

char texts[][80]={"language","culture","transportation","motion","emotion"};
int textnum=5;
int textcur=0;
float textheat[32];
float textheatdest[32];
int dotext=0;
int tcount=0;
int infocount=0;
int hcountdest=0;
int hcount2=0;

float rotx,roty,rotz;
float drotx,droty,drotz;

struct meshloadstruct {
	int totalvertices; // total vertices in mesh
	int totalfaces; // total faces defined in mesh
	float (*vertices)[3];
	float (*normals)[3];
	int (*faces)[3];
	float avgx;
	float avgy;
	float avgz;
	};

struct meshloadstruct meshes[8];

char info[]="The multi-dimensional natural language processing (NLP) system is a computational system with hardware and software components that perform processes that understand and act upon spoken, written and other forms of human language. The hardware consists of either general computing devices that use specialized software to perform these functions, or specialized computing devices that are optimized to operate the specialized multi-dimensional NLP system software. The software contains real-world knowledge stored in a distributed knowledge network that exhibits neural network-like structure and content, and algorithms that mimic certain brain functions. The algorithms are optimized to rapidly access and process stored knowledge to interpret the meaning of human language text, and perform further processing such as initiating searches or automated business functions, or translating the human language input text from one language to one or more other languages. The theory underlying these inventions comes from several academic disciplines whose collective work was required to solve problems plaguing all who have sought and are seeking to automate language understanding.";
int infopos=0;

int hcount=0;
int dcount=0;

GLuint headlist[32];

int faceon=0;
int transphead=1;

// Normalize a 3d vector to length 1

void Normalize(float *v)
{
	GLfloat d;
	
	d = (float) sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
	if (d==0.0f) return;
	
	v[0]/=d;	v[1]/=d;	v[2]/=d;
}

// Read a line from an open file into buffer

int readaline(FILE *fp,char *dest,int max){
	int a;
	char c;

	if(feof(fp)) return(0);
	a=0;
	while(((c=fgetc(fp))!=0xd)&&a<max) {
		dest[a++]=c;
		}

	dest[a]=0;

	fgetc(fp);
	return(a);
	}

// Free system memory use by a loaded mesh

void freedisplaylist(struct meshloadstruct *mstruct) {

 delete [] mstruct->vertices;
 delete [] mstruct->normals;
 delete [] mstruct->faces;

	}

// Create a display list object from a loaded mesh

int createdisplaylist(struct meshloadstruct *mstruct) {
	int totalvertices; // total vertices in mesh
	int totalfaces; // total faces defined in mesh
	float (*vertices)[3];
	float (*normals)[3];
	int (*faces)[3];
	float avgx;
	float avgy;
	float avgz;
	int facea,faceb,facec;

	if(!mstruct) return(0);

	totalvertices=mstruct->totalvertices; // total vertices in mesh
	totalfaces=mstruct->totalfaces; // total faces defined in mesh
	vertices=mstruct->vertices;
	normals=mstruct->normals;
	faces=mstruct->faces;
	avgx=mstruct->avgx;
	avgy=mstruct->avgy;
	avgz=mstruct->avgz;

	GLuint thislist=glGenLists(1);
	if(thislist==0) {
		return(0);
		}

	glNewList(thislist,GL_COMPILE_AND_EXECUTE);

//	glColor3f(0.0f,1.0f,0.0f);

	glBegin(GL_TRIANGLES);

	float zoomfactor=1.5;

	for(int a=0;a<totalfaces;a++) {
		facea=faces[a][0];		faceb=faces[a][1];		facec=faces[a][2];
		
		glNormal3fv(normals[facea]);
		glVertex3f((vertices[facea][0]-avgx)/zoomfactor, (vertices[facea][1]-avgy)/zoomfactor, (vertices[facea][2]-avgz)/zoomfactor);
		glNormal3fv(normals[faceb]);
		glVertex3f((vertices[faceb][0]-avgx)/zoomfactor, (vertices[faceb][1]-avgy)/zoomfactor, (vertices[faceb][2]-avgz)/zoomfactor);
		glNormal3fv(normals[facec]);
		glVertex3f((vertices[facec][0]-avgx)/zoomfactor, (vertices[facec][1]-avgy)/zoomfactor, (vertices[facec][2]-avgz)/zoomfactor);
		}

	glEnd();
	glEndList();

	return(thislist);
}

// Interpolate between 2 loaded mesh objects creating a third mesh object in memory

int interpolatemeshes(struct meshloadstruct *mstruct1,struct meshloadstruct *mstruct2,struct meshloadstruct *mstruct3,float iratio) {
	float (*vertices)[3] = new float[mstruct1->totalvertices][3];
	float (*normals)[3] = new float[mstruct1->totalvertices][3];
	int (*faces)[3] = new int[mstruct1->totalfaces][3];
	float mratio;

	if(!vertices||!normals||!faces) return(0);
	if(iratio<0.0) iratio=0.0;
	if(iratio>1.0) iratio=1.0;
	
	mratio=1.0f-iratio;

	for(int a=0;a<mstruct1->totalvertices;a++) {
		vertices[a][0]=mstruct1->vertices[a][0]*mratio+mstruct2->vertices[a][0]*iratio;
		vertices[a][1]=mstruct1->vertices[a][1]*mratio+mstruct2->vertices[a][1]*iratio;
		vertices[a][2]=mstruct1->vertices[a][2]*mratio+mstruct2->vertices[a][2]*iratio;

		normals[a][0]=mstruct1->normals[a][0]*mratio+mstruct2->normals[a][0]*iratio;
		normals[a][1]=mstruct1->normals[a][1]*mratio+mstruct2->normals[a][1]*iratio;
		normals[a][2]=mstruct1->normals[a][2]*mratio+mstruct2->normals[a][2]*iratio;
		}

	for(int a=0;a<mstruct1->totalfaces;a++) {
		faces[a][0]=mstruct1->faces[a][0];
		faces[a][1]=mstruct1->faces[a][1];
		faces[a][2]=mstruct1->faces[a][2];
		}


	mstruct3->totalvertices=mstruct1->totalvertices;
	mstruct3->totalfaces=mstruct1->totalfaces;
	mstruct3->faces=faces;
	mstruct3->vertices=vertices;
	mstruct3->normals=normals;
	mstruct3->avgx=mstruct1->avgx*mratio+mstruct2->avgx*iratio;
	mstruct3->avgy=mstruct1->avgy*mratio+mstruct2->avgy*iratio;
	mstruct3->avgz=mstruct1->avgz*mratio+mstruct2->avgz*iratio;
	return(1);
	}


// Read an exported mesh file in ASE format from 3ds studio max, be sure to include normals
// when exporting


int readasefile(char *filename,char *object,struct meshloadstruct *mstruct) {
	FILE *fp;
	char sresult[260];
	char string[80];

	int capturedl=0;

	int vertexnum,totalvertices,totalfaces;
	float vertexx,vertexy,vertexz;

	int facenum,facea,faceb,facec;
	float normx,normy,normz;

	float verticesxtotal=0.0;
	float verticesytotal=0.0;
	float verticesztotal=0.0;

	if((fp=fopen(filename,"rb"))==NULL) {
		return(0);
	}

	float (*vertices)[3] = NULL;
	float (*normals)[3] = NULL;
	int (*faces)[3] = NULL;

	while(readaline(fp,sresult,256)) {

		if(!strncmp(sresult,"*3DSMAX_ASCIIEXPORT",strlen("*3DSMAX_ASCIIEXPORT"))){
			}
		else if(!strncmp(sresult,"*COMMENT",strlen("*COMMENT"))){
			}
		else if(!strncmp(sresult,"*SCENE",strlen("*SCENE"))){
			}
		else if(!strncmp(sresult,"*MATERIAL_LIST",strlen("*MATERIAL_LIST"))){
			}
		else if(!strncmp(sresult,"*GEOMOBJECT",strlen("*GEOMOBJECT"))){
			}
		else if(!strncmp(sresult,"	*MESH",strlen("	*MESH"))){
			}
		else if(!strncmp(sresult,"	*NODE_NAME",strlen("	*NODE_NAME"))){
			sscanf(&sresult[strlen("	*NODE_NAME")],"%s",string);
			if(!strncmp(object,string,strlen(object))) {
				capturedl=1;
				}
			else {
				capturedl=0;
				}
		}

		else if(capturedl) {

		if(!strncmp(sresult,"		*MESH_NUMVERTEX",strlen("		*MESH_NUMVERTEX"))){
			sscanf(&sresult[strlen("		*MESH_NUMVERTEX")],"%d",&totalvertices);

			if(vertices==NULL) {
				vertices = new float[totalvertices][3];
				normals = new float[totalvertices][3];

				}


			}
		else if(!strncmp(sresult,"		*MESH_NUMFACES",strlen("		*MESH_NUMFACES"))){
			sscanf(&sresult[strlen("		*MESH_NUMFACES")],"%d",&totalfaces);

			if(faces==NULL) {
				faces = new int[totalfaces][3];
				}

			}
		else if(!strncmp(sresult,"			*MESH_VERTEX",strlen("			*MESH_VERTEX"))){
			sscanf(&sresult[strlen("			*MESH_VERTEX")],"%d %f %f %f",&vertexnum,&vertexx,&vertexy,&vertexz);

			if(vertexnum>=0&&vertexnum<totalvertices) {
				vertices[vertexnum][0]=vertexx; 
				vertices[vertexnum][1]=vertexy; 
				vertices[vertexnum][2]=vertexz;

				verticesxtotal+=vertexx;				verticesytotal+=vertexy;				verticesztotal+=vertexz;

				}
			}
		else if(!strncmp(sresult,"			*MESH_FACE",strlen("			*MESH_FACE"))){
			sscanf(&sresult[strlen("			*MESH_FACE")],"%d: A:%d B:%d C:%d",&facenum,&facea,&faceb,&facec);

			if(facenum>=0&&facenum<totalfaces) {
				faces[facenum][0]=facea; faces[facenum][1]=faceb; faces[facenum][2]=facec;
				}
		}
		else if(!strncmp(sresult,"				*MESH_VERTEXNORMAL",strlen("				*MESH_VERTEXNORMAL"))){
			sscanf(&sresult[strlen("				*MESH_VERTEXNORMAL")],"%d %f %f %f",&vertexnum,&normx,&normy,&normz);
			if(vertexnum>=0&&vertexnum<totalvertices) {
				normals[vertexnum][0]=normx;			normals[vertexnum][1]=normy;			normals[vertexnum][2]=normz;
				}
		}
		}


	}

	fclose(fp);

	mstruct->totalvertices=totalvertices; // total vertices in mesh
	mstruct->totalfaces=totalfaces; // total faces defined in mesh
	mstruct->vertices=vertices;
	mstruct->normals=normals;
	mstruct->faces=faces;
	mstruct->avgx=verticesxtotal/(float)totalvertices;
	mstruct->avgy=verticesytotal/(float)totalvertices;
	mstruct->avgz=verticesztotal/(float)totalvertices;

	return(1);

}


GLvoid BuildFont(GLvoid)								// Build Our Bitmap Font
{
	HFONT	font;										// Windows Font ID

	base = glGenLists(256);								// Storage For 256 Characters

	font = CreateFont(	-12,							// Height Of Font
						0,								// Width Of Font
						0,								// Angle Of Escapement
						0,								// Orientation Angle
						FW_LIGHT,						// Font Weight
						FALSE,							// Italic
						FALSE,							// Underline
						FALSE,							// Strikeout
						ANSI_CHARSET,					// Character Set Identifier
						OUT_TT_PRECIS,					// Output Precision
						CLIP_DEFAULT_PRECIS,			// Clipping Precision
						ANTIALIASED_QUALITY,			// Output Quality
						FF_DONTCARE|DEFAULT_PITCH,		// Family And Pitch
//						"Comic Sans MS");				// Font Name
						"Micrososft Sans Serif");				// Font Name

	SelectObject(hDC, font);							// Selects The Font We Created

	wglUseFontOutlines(	hDC,							// Select The Current DC
						0,								// Starting Character
						255,							// Number Of Display Lists To Build
						base,							// Starting Display Lists
						0.0f,							// Deviation From The True Outlines
						0.1f,							// Font Thickness In The Z Direction
						WGL_FONT_POLYGONS,				// Use Polygons, Not Lines
						gmf);							// Address Of Buffer To Recieve Data
}

GLvoid KillFont(GLvoid)									// Delete The Font
{
  glDeleteLists(base, 256);								// Delete All 256 Characters
}

GLvoid glPrint(const char *fmt, ...)					// Custom GL "Print" Routine
{
	float		length=0;								// Used To Find The Length Of The Text
	char		text[256];								// Holds Our String
	va_list		ap;										// Pointer To List Of Arguments

	if (fmt == NULL)									// If There's No Text
		return;											// Do Nothing

	va_start(ap, fmt);									// Parses The String For Variables
	    vsprintf(text, fmt, ap);						// And Converts Symbols To Actual Numbers
	va_end(ap);											// Results Are Stored In Text

	for (unsigned int loop=0;loop<(strlen(text));loop++)	// Loop To Find Text Length
	{
		length+=gmf[text[loop]].gmfCellIncX;			// Increase Length By Each Characters Width
	}

	glTranslatef(-length/2,0.0f,0.0f);					// Center Our Text On The Screen

	glPushAttrib(GL_LIST_BIT);							// Pushes The Display List Bits
	glListBase(base);									// Sets The Base Character to 0
	glCallLists(strlen(text), GL_UNSIGNED_BYTE, text);	// Draws The Display List Text
	glPopAttrib();										// Pops The Display List Bits
}

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	if (height==0)										// Prevent A Divide By Zero By
	{
		height=1;										// Making Height Equal One
	}

	glViewport(0,0,width,height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height*1.25f,0.1f,100.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
}

float lightposition[]={0.0,15.0,10.0,1.0};


void initlights(void)
{
    GLfloat ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
    GLfloat diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    GLfloat specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    GLfloat position[] = { 0.0f, 3.0f, 2.0f, 0.0f };
    GLfloat lmodel_ambient[] = { 0.4f, 0.4f, 0.4f, 1.0f };
    GLfloat local_view[] = { 0.0f };

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, position);
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
    glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, local_view);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_CULL_FACE); 
    glCullFace(GL_BACK);
}


int InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	//	LoadGLTextures();									// Load Bitmaps And Convert To Textures

#if 0
	glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping ( NEW )

	glShadeModel(GL_SMOOTH);		
#else
//	glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping ( NEW )

	glShadeModel(GL_SMOOTH);		
#endif

	
	// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.5f, 0.5f);				// Black Background
//	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
//	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);	// Really Nice Perspective Calculations
#if 0	
	glEnable(GL_LIGHT0);								// Enable Default Light (Quick And Dirty)
	glEnable(GL_LIGHTING);								// Enable Lighting
	glLightfv(GL_LIGHT0,GL_POSITION,lightposition);
#else
	initlights();

#endif


	glEnable(GL_COLOR_MATERIAL);						// Enable Coloring Of Material
//	glEnable(GL_LINE_SMOOTH);						// Enable Coloring Of Material

//	glEnable(GL_BLEND);								// Enable Lighting
//	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

	BuildFont();										// Build The Font
	if(readasefile("face3.ase","\"head:1\"",&meshes[0])) {
		}
	if(readasefile("face3.ase","\"head:2\"",&meshes[1])) {
		}
	if(readasefile("face3.ase","\"head:3\"",&meshes[2])) {
		}

	for(int a=0;a<16;a++) {
		if(interpolatemeshes(&meshes[1],&meshes[2],&meshes[3],((float)a)/16.0f)) {
			headlist[a]=createdisplaylist(&meshes[3]);
			freedisplaylist(&meshes[3]);
			}
		}
	for(int a=16;a<32;a++) {
		if(interpolatemeshes(&meshes[2],&meshes[0],&meshes[3],((float)(a-16))/16.0f)) {
			headlist[a]=createdisplaylist(&meshes[3]);
			freedisplaylist(&meshes[3]);
			}
		}

	freedisplaylist(&meshes[0]);
	freedisplaylist(&meshes[1]);
	freedisplaylist(&meshes[2]);


	return TRUE;										// Initialization Went OK
}

int DrawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{
	char string[32];

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer


	if(dotext) {
	glLoadIdentity();									// Reset The Current Modelview Matrix
	glTranslatef(0.0f,-2.0f,-12.0f);						// Move One Unit Into The Screen
	glColor4f(1.0f,1.0f,0.0f,0.4f);
  //	glPrint("KnowledgeNetica");						// Print GL Text To The Screen
  	glPrint("K-Netica");						// Print GL Text To The Screen
	}


	if(rotx<drotx) rotx+=0.1f;
	if(roty<droty) roty+=0.1f;
	if(rotz<drotz) rotz+=0.1f;
	if(rotx>drotx) rotx-=0.1f;
	if(roty>droty) roty-=0.1f;
	if(rotz>drotz) rotz-=0.1f;

	glLoadIdentity();									// Reset The Current Modelview Matrix

	if(dotext) {
	glTranslatef(0.0f,1.0f,-25.0f);						// Move One Unit Into The Screen
	}
	else {
	glTranslatef(0.0f,-0.4f,-12.0f);						// Move One Unit Into The Screen

	}


	if(faceon) {
		rotx=0.0f;
		roty=0.0f;
		}


	glRotatef(270.0,1.0f,0.0f,0.0f);					// Rotate On The Y Axis
	glRotatef(-roty,0.0f,0.0f,1.0f);					// Rotate On The Y Axis
	glRotatef(-rotx,1.0f,0.0f,0.0f);					// Rotate On The Y Axis

		if((rand()&0xff)==0xff) {
		drotx=(((float)(rand()&0x7fff))/32768.0f)*40.0f-20.0f;
		droty=(((float)(rand()&0x7fff))/32768.0f)*40.0f-20.0f;
		}




//	glColor3f(0.0f,1.0f,0.0f);// Green
	glColor3f(233.0f/255.0f,189.0f/255.0f,178.0f/255.0f);// flesh

hcount2++;
if(hcount2==1) {
	hcount2=0;
	if(hcount<hcountdest) hcount++;
	else if(hcount>hcountdest) hcount--;
	}

	glCallList(headlist[hcount]);


	if(dotext) {
		for(int a=0;a<textnum;a++) {
			glLoadIdentity();									// Reset The Current Modelview Matrix
			float xpos=((float)(a)/(float)textnum-0.5f)*textheat[a]*8.0f;
			float ypos=textheat[a]*4.0f+1.0f;
			glTranslatef(xpos,ypos,-15.0f);						// Move One Unit Into The Screen
			glColor4f(textheat[a],0.0f,0.0f,textheat[a]);
 			glPrint(texts[a]);						// Print GL Text To The Screen

			textheat[a]=textheat[a]+(textheatdest[a]-textheat[a])/10.0f;

			}


			tcount++;
			if(tcount==50) {
				for(int a=0;a<textnum;a++) {
					textheatdest[a]=((float)rand())/32768.0f;
					}
				tcount=0;
				}
		}


	if(dotext) {
		glLoadIdentity();									// Reset The Current Modelview Matrix
		glTranslatef(0.0f,1.2f,-25.0f);						// Move One Unit Into The Screen
		glRotatef(-rot,0.0f,1.0f,0.0f);					// Rotate On The Y Axis
		glTranslatef(0.0f,0.0f,-2.0f);						// Move One Unit Into The Screen
		glColor4f(0.0f,1.0f,1.0f,0.4f);

		strncpy(string,&info[infopos],30);
		string[30]=0;

		infocount++;
		if(infocount==2) {
			infocount=0;
			infopos++;
			if(infopos==(strlen(info)-30)) infopos=0;
			}

 		glPrint(string);						// Print GL Text To The Screen
		}

	return TRUE;										// Everything Went OK
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	if (fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}

	KillFont();
}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
 *	title			- Title To Appear At The Top Of The Window				*
 *	width			- Width Of The GL Window Or Fullscreen Mode				*
 *	height			- Height Of The GL Window Or Fullscreen Mode			*
 *	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
 *	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/
 
BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen=FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								title,								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 0,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	return TRUE;									// Success
}

extern HWND ghDlg;
extern int visualizemoleculestate(HWND hDlg);

#if 1
LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{

		case WM_PAINT:							// Watch For Window Activate Message
				if(ghDlg) {
					
					//visualizemoleculestate(ghDlg);


					}

			break;
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=TRUE;						// Program Is Active
			}
			else
			{
				active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		case WM_SYSCOMMAND:							// Intercept System Commands
		{
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
			break;									// Exit
		}
		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

		case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			keys[wParam] = TRUE;					// If So, Mark It As TRUE
	//		if(wParam==27) {
	//			PostQuitMessage(0);						// Send A Quit Message
//
//				}

			return 0;								// Jump Back
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
			keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

#endif
