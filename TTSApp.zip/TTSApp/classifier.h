
int putwordsinSTMWordList();

struct wordobject *CLFindWordObject(struct STMobject *STM,struct wordobject *wobject);
int CLAddWordToWordList(struct STMobject *STM,struct wordobject *wobject);
int CLClassifyWords(struct STMobject *STM,int *words,int wordcount,int *idioms,int idiomcount,int *molecules,int moleculecount);

