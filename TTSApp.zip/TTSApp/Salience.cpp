#include "stdio.h"
#include "stdlib.h"
#include "malloc.h"
#include "string.h"
#include "salience.h"

char *salience_paragraph_marker="Paragraph Salience:";
int psaliences[256];
int ppositions[256];




char * salience_paragraphs(char *memfile, int filesize) {
	int t=0;
	int l=strlen(salience_paragraph_marker);
	int svalue=0;
	int hvalue=0;
	int hnum=0; //paragraph number of highest salience
	char *memparagraph=NULL;
	int psize;

	for(int a=0;a<filesize-l;a++) {
		if(!strncmp(&memfile[a],salience_paragraph_marker,l-1)){//match
			char *valstring=&memfile[a+l];
			sscanf(valstring,"%d",&svalue);
			psaliences[t]=svalue; ppositions[t]=a;
			if(svalue>hvalue) {
				hvalue=svalue; hnum=t;
			}
			t++;
			}
		
		if(t==256) break;


		}

	if(hnum+1==t) {
		psize=filesize-ppositions[hnum];
		}
	else {
		psize=ppositions[hnum+1]-ppositions[hnum];
		}
	
	
	memparagraph=(char *)malloc(psize+1);
	if(memparagraph) {
		memcpy(memparagraph,&memfile[ppositions[hnum]],psize);
		memparagraph[psize-1]=0;
		}



	return(memparagraph);
	}

char * salience_search(char *filename){
	FILE *fp;
	int result;
	char *sresult=NULL;

	if((fp=fopen(filename,"rb"))==NULL) {
		return(sresult);
	}

	result = fseek( fp, 0L, SEEK_END);
	int filesize=ftell(fp);
	result = fseek( fp, 0L, SEEK_SET);

	if(filesize>10&&filesize<2000000) {
		char *memfile=(char *)malloc(filesize);
		if(memfile) {
			fread(memfile,filesize,1,fp);
			fclose(fp);


			char *topsalience=salience_paragraphs(memfile,filesize);
			if(topsalience) {
				//free(topsalience);
				
				sresult=topsalience;

				}
			free(memfile);

			}
		else {
			fclose(fp);
			}

		}
	
	return(sresult);


}

char * filetomemory(char *filename){
	FILE *fp;
	int result;
	char *sresult=NULL;
	char *memfile=NULL;

	if((fp=fopen(filename,"rb"))==NULL) {
		return(sresult);
	}

	result = fseek( fp, 0L, SEEK_END);
	int filesize=ftell(fp);
	result = fseek( fp, 0L, SEEK_SET);

	if(filesize>10&&filesize<2000000) {
		memfile=(char *)malloc(filesize+1);
		if(memfile) {
			fread(memfile,filesize,1,fp);
			memfile[filesize]=0;
			fclose(fp);

#if 0
			for(int a=0;a<filesize-1;a++) {
				if(memfile[a]>='1'&&memfile[a]<=9) {
					
					}
			}
#endif


			}
		else {
			fclose(fp);
			}

		}
	
	return(memfile);


}