 #ifndef __TTSAPP_GLOBALS_H__
#define __TTSAPP_GLOBALS_H__

// App includes
#include "TTSApp.h"         

#define WM_RECOEVENT    WM_APP+1      // Window message used for recognition events
#define GID_DICTATION   0           // Dictation grammar has grammar ID 0


// Other global variables
extern int                  g_iBmp;
extern HIMAGELIST           g_hListBmp;
extern const int            g_aMapVisemeToImage[22];

// Output formats
extern const SPSTREAMFORMAT g_aOutputFormat[NUM_OUTPUTFORMATS];
extern TCHAR*               g_aszOutputFormat[NUM_OUTPUTFORMATS];

  
#endif // __TTSAPP_GLOBALS_H__
