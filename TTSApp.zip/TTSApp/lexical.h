struct lexicalobject {
	unsigned char bytecount;
	unsigned char idiomcount;
	unsigned short moleculecount;
	char *bytes;
	int *idioms;
	int *molecules;
	void *nextlexicalobject;
	};

struct lexicalobject *newlexicalobject();

int LXGetRef(char *string,struct lexicalobject *sourcestrings[],int start, int end);
int LXGetType(char *string);
void LXBubbleSort(struct lexicalobject *sourcestrings[], int n);
int LXDeleteObjects(struct lexicalobject *sourcestrings[], int n);
int LXAddNewLexicalWord(char *lexstring,struct lexicalobject *sourcestrings[],int *totlex);
int LXInsertObject(struct lexicalobject *sourcestrings[],struct lexicalobject *lobj,int lpos,int *TotalLexObjects);



