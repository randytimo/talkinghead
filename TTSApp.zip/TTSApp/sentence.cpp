#include "globals.h"
#include "stdio.h"
#include "string.h"
#include "sentence.h"



char sentencetypestrings[][80]={
	"who was #inputnoun",
	"who is #inputnoun",
	"what is a #inputnoun",
	"what is the #inputnoun",
	"when did #inputverb",
	"when is #inputverb",
	"where is #inputnoun",
	"where is #inputnoun",
	"why is #inputnoun",
	"why are #inputnoun",
	"can you #inputverb",
	};


// ttp://mobile.wunderground.com/cgi-bin/findweather/getForecast?query=anoka%2Cmn


	
int sentencetype(char *string) {
	return(1);
	}



struct sentenceobject *newsetenceobject(){

	struct sentenceobject *tempso;

	tempso=new sentenceobject;
	if(tempso) {
		tempso->idiomqueue=NULL;
		tempso->moleculequeue=NULL;
		tempso->wordqueue=NULL;
		tempso->numberofwords=0;
		}

	return(tempso);

	}
