#include "globals.h"
#include "ttsapp.h"
#include "stdio.h"
#include "string.h"
#include "molecule.h"

#include "kgconverter.h"
#include "worldfacts.h"
#include "kgfileio.h"
#include "lexical.h"


struct lexicalobject *LexicalObjects[MAXLEXOBJECTS];
struct moleculeobject *MoleculeObjects[MAXMOLECULEOBJECTS];



int lextypestarts[8]={0,300000,400000,450000,475000,500000}; //0=normal 1=idioms 2=pronunciation 3=syllables 4=temp
int lextypetotals[8]={0,0,0,0,0,0,0,0}; //0=normal 1=idioms 2=pronunciation

int LexRefDerivative;


int TotalLexObjects=0;
int TotalMolObjects=0;

TCHAR               szAFileName[NORM_SIZE] = _T("");
TCHAR               szOutFileName[NORM_SIZE] = _T("");
TCHAR               szOutFileName2[NORM_SIZE] = _T("");





//-------------------------------------------------------------
// GetMoleculeType returns the type of lexcial item by analyzing the
// input string. 0=word 1=idiom 2=pronunciation 3=syllables
//-------------------------------------------------------------

int GetMoleculeType(struct moleculeloadstruct *mstruct) {
	int c;

	if(!strcmp(mstruct->R,"syllables")) return(3);
	else if(!strcmp(mstruct->R,"pronunciation")) return(2);
	else if(strchr( mstruct->X, ' ' )) return(1);
	else return(0);

// pdest = strrchr( string, ' ' );

	}


//-------------------------------------------------------------
// DeleteMoleculeObjects write the lexical objects array to disk
//-------------------------------------------------------------

int DeleteMoleculeObjects(struct moleculeobject *sourcestrings[], int n)
{
  int i;

  for ( i=0;i< n; i++) {
	  if(sourcestrings[i]) {
		delete sourcestrings[i];
		sourcestrings[i]=NULL;
		}
	}
  
  return(1);
 }

//-------------------------------------------------------------
// SaveLexicals writes the string values of the sorted lexical
// array to disk.
//-------------------------------------------------------------

int ConvertIdioms(struct lexicalobject *sourcestrings[], int n)
{
  int i,j;
	char string[80];
	char seps[]   = " \t\n";
	char *token;

    for ( i=0;i< n; i++) {// all words
		strcpy(string,sourcestrings[i]->bytes);
		token = strtok( string, seps );
		while( token != NULL ){
			int LexRef=LXGetRef(token,&LexicalObjects[lextypestarts[BASELEXPOS]],0,lextypetotals[BASELEXPOS]-1);

			if(LexRef>=0) {
				int m=LexicalObjects[LexRef]->idiomcount; // current lexicon's molecule count
				int *newidiarray=new int[m+1]; // make array 1 bigger
				for(int a=0;a<m;a++) {
					newidiarray[a]=LexicalObjects[LexRef]->idioms[a];
					}

				newidiarray[m]=i+lextypestarts[IDIOMLEXPOS]; // point to newly created molecule

				if(LexicalObjects[LexRef]->idiomcount) delete LexicalObjects[LexRef]->idioms;
				LexicalObjects[LexRef]->idiomcount++;
				LexicalObjects[LexRef]->idioms=newidiarray;
				}

				/* Get next token: */
				token = strtok( NULL, seps );
			}

	}
  
  return(1);
 }




int AddMoleculeObject(struct moleculeloadstruct *curmolecule) {

	struct moleculeobject *tmpmol;
	int LexRef;

			//tmpmol=new moleculeobject;
			tmpmol=newlmoleculeobject();

			if(tmpmol) {

			int moltype=GetMoleculeType(curmolecule);// Get molecule type for pronunciation, syllable identification

			int xlextype=LXGetType(curmolecule->X);// Get lexical type of atom 
			int rlextype=LXGetType(curmolecule->R);// Get lexical type of atom 
			int ylextype=LXGetType(curmolecule->Y);// Get lexical type of atom 
			int clextype=LXGetType(curmolecule->C);// Get lexical type of atom 
			int qlextype=LXGetType(curmolecule->Q);// Get lexical type of atom 
			int qattrlextype=LXGetType(curmolecule->QAttr);// Get lexical type of atom 

			if(moltype==2) {
				ylextype=2;
	
				}	
			else if(moltype==3) {
				ylextype=3;
				}

	
			LexRef=LXGetRef(curmolecule->X,&LexicalObjects[lextypestarts[xlextype]],0,lextypetotals[xlextype]-1)+lextypestarts[xlextype];
			if(LexRef<0) {
				AddTempLexicalObject(curmolecule->X);
				LexRef=LXGetRef(curmolecule->X,&LexicalObjects[lextypestarts[TEMPLEXPOS]],0,lextypetotals[TEMPLEXPOS]-1)+lextypestarts[TEMPLEXPOS];

				}





			tmpmol->R=LXGetRef(curmolecule->R,&LexicalObjects[lextypestarts[rlextype]],0,lextypetotals[rlextype]-1)+lextypestarts[rlextype];

			if(tmpmol->R<0) {
				AddTempLexicalObject(curmolecule->R);
				tmpmol->R=LXGetRef(curmolecule->R,&LexicalObjects[lextypestarts[TEMPLEXPOS]],0,lextypetotals[TEMPLEXPOS]-1)+lextypestarts[TEMPLEXPOS];

				}


			tmpmol->Y=LXGetRef(curmolecule->Y,&LexicalObjects[lextypestarts[ylextype]],0,lextypetotals[ylextype]-1)+lextypestarts[ylextype];

			if(tmpmol->Y<0) {
				AddTempLexicalObject(curmolecule->Y);
				tmpmol->Y=LXGetRef(curmolecule->Y,&LexicalObjects[lextypestarts[TEMPLEXPOS]],0,lextypetotals[TEMPLEXPOS]-1)+lextypestarts[TEMPLEXPOS];

				}


			tmpmol->C=LXGetRef(curmolecule->C,&LexicalObjects[lextypestarts[clextype]],0,lextypetotals[clextype]-1)+lextypestarts[clextype];


			if(tmpmol->C<0) {
				AddTempLexicalObject(curmolecule->C);
				tmpmol->C=LXGetRef(curmolecule->C,&LexicalObjects[lextypestarts[TEMPLEXPOS]],0,lextypetotals[TEMPLEXPOS]-1)+lextypestarts[TEMPLEXPOS];

				}




			tmpmol->Q=LXGetRef(curmolecule->Q,&LexicalObjects[lextypestarts[qlextype]],0,lextypetotals[qlextype]-1)+lextypestarts[qlextype];


			if(tmpmol->Q<0) {
				AddTempLexicalObject(curmolecule->Q);
				tmpmol->Q=LXGetRef(curmolecule->Q,&LexicalObjects[lextypestarts[TEMPLEXPOS]],0,lextypetotals[TEMPLEXPOS]-1)+lextypestarts[TEMPLEXPOS];

				}


			tmpmol->W=curmolecule->W;
			tmpmol->QAttr=LXGetRef(curmolecule->QAttr,&LexicalObjects[lextypestarts[qattrlextype]],0,lextypetotals[qattrlextype]-1)+lextypestarts[qattrlextype];
			tmpmol->RF=curmolecule->RF;
			tmpmol->Flag=curmolecule->Flag;
			tmpmol->LexID=curmolecule->LexID;

			if(LexRef>=0&&LexRef<500000) {
				int m=LexicalObjects[LexRef]->moleculecount; // current lexicon's molecule count
				int *newmolarray=new int[m+1]; // make array 1 bigger
				for(int a=0;a<m;a++) {
					newmolarray[a]=LexicalObjects[LexRef]->molecules[a];
					}

				MoleculeObjects[TotalMolObjects]=tmpmol;
				newmolarray[m]=TotalMolObjects++; // point to newly created molecule

				if(LexicalObjects[LexRef]->moleculecount) delete LexicalObjects[LexRef]->molecules;
				LexicalObjects[LexRef]->moleculecount++;
				LexicalObjects[LexRef]->molecules=newmolarray;
			}
			return(1);
			}
			

			return(0);







	}







int AddIdiomsToMainLexicon(char *istring) {
				char string[128];
				char seps[]   = " \t\n";
				char *token;

				strcpy(string,istring);

				  token = strtok( string, seps );
				   while( token != NULL ) {
						if(LXAddNewLexicalWord(token,&LexicalObjects[lextypestarts[BASELEXPOS]],&lextypetotals[BASELEXPOS])) {
							}
						token = strtok( NULL, seps );
						}
	return(1);
	}
	



int ConvertLexicalObjects(char *filename) {
	FILE *fp;
	int done=0;

	lextypetotals[BASELEXPOS]=0;
	lextypetotals[IDIOMLEXPOS]=0;
	lextypetotals[PRONLEXPOS]=0;
	lextypetotals[SYNLEXPOS]=0;
	lextypetotals[TEMPLEXPOS]=0;

	


	if((fp=fopen(filename,"rb"))==NULL) {
		return(0);
		}

	while(fgetc(fp)!=0xd&&!feof(fp)); //0xd Skip first line in file
	fgetc(fp); //0xa

	struct moleculeloadstruct *curmolecule=new moleculeloadstruct();

	while(!feof(fp)) {

	
		if(readfilemolecule(fp,curmolecule)) {

			int moltype=GetMoleculeType(curmolecule);// Get molecule type for pronunciation, syllable identification

			int xlextype=LXGetType(curmolecule->X);// Get lexical type of atom 
			int rlextype=LXGetType(curmolecule->R);// Get lexical type of atom 
			int ylextype=LXGetType(curmolecule->Y);// Get lexical type of atom 
			int clextype=LXGetType(curmolecule->C);// Get lexical type of atom 
			int qlextype=LXGetType(curmolecule->Q);// Get lexical type of atom 
			int qattrlextype=LXGetType(curmolecule->QAttr);// Get lexical type of atom 

			if(moltype==2) {
				ylextype=2;
	
				}	
			else if(moltype==3) {
				ylextype=3;

				}

				if(LXAddNewLexicalWord(curmolecule->X,&LexicalObjects[lextypestarts[xlextype]],&lextypetotals[xlextype])) {
					}
#if 1
			if(xlextype==1) {
				AddIdiomsToMainLexicon(curmolecule->X);
				}

#endif


			if(LXAddNewLexicalWord(curmolecule->R,&LexicalObjects[lextypestarts[rlextype]],&lextypetotals[rlextype])) {
				}
			if(LXAddNewLexicalWord(curmolecule->Y,&LexicalObjects[lextypestarts[ylextype]],&lextypetotals[ylextype])) {
				}

#if 1
			if(ylextype==1) {
				AddIdiomsToMainLexicon(curmolecule->Y);
				}
#endif

			if(LXAddNewLexicalWord(curmolecule->C,&LexicalObjects[lextypestarts[clextype]],&lextypetotals[clextype])) {
				}


			if(LXAddNewLexicalWord(curmolecule->Q,&LexicalObjects[lextypestarts[qlextype]],&lextypetotals[qlextype])) {
				}

#if 1
			if(qlextype==1) {
				AddIdiomsToMainLexicon(curmolecule->Q);
				}
#endif



			if(LXAddNewLexicalWord(curmolecule->QAttr,&LexicalObjects[lextypestarts[qattrlextype]],&lextypetotals[qattrlextype])) {
				}
			}
		}

	delete curmolecule;
	fclose(fp);

	return(1);

}
	









int CountLexicalObjects(char *filename,int lexidtostore,int *moleculeobjects,int *lexicalobjects) {
	FILE *fp;

	struct moleculeloadstruct *tmpmolecule;
	int moleculecount=0;
	int uniquelexicalobjects=0;
	int done=0;

	if((fp=fopen(filename,"rb"))==NULL) {
		return(0);
		}

#if 1
	while(fgetc(fp)!=0xd&&!feof(fp)); //0xd Skip first line in file
	fgetc(fp); //0xa
#endif

	struct moleculeloadstruct *curmolecule=new moleculeloadstruct();
	struct moleculeloadstruct *lastmolecule=new moleculeloadstruct();

	readfilemolecule(fp,lastmolecule); moleculecount++; //uniquelexicalobjects++;

	while(!feof(fp)) {
		if(readfilemolecule(fp,curmolecule)) {

		if(strcmp(curmolecule->X,lastmolecule->X)) { //duplicate lexicon

			int lexID=lastmolecule->LexID;
	
			if(lexID==lexidtostore) {
				uniquelexicalobjects++;
				}
			}

		tmpmolecule=lastmolecule;
		lastmolecule=curmolecule;
		curmolecule=tmpmolecule;

		moleculecount++;
		}
		}

	delete curmolecule;
	delete lastmolecule;


	fclose(fp);
	*moleculeobjects=moleculecount;
	*lexicalobjects=uniquelexicalobjects;

	return(1);

	}



int ConvertMoleculeObjects(char *filename,struct moleculeobject *moldestarray[],int maxmolecules) {
	FILE *fp;

//	char string[128];
	int LexRef;
	int totalmolecules=0;

	if((fp=fopen(filename,"rb"))==NULL) {
		return(0);
		}

#if 1
	while(fgetc(fp)!=0xd&&!feof(fp)); //0xd Skip first line in file
	fgetc(fp); //0xa
#endif

	struct moleculeloadstruct *curmolecule=new moleculeloadstruct();

	while(!feof(fp)&&totalmolecules<maxmolecules) {
		if(readfilemolecule(fp,curmolecule)) {

//			moldestarray[totalmolecules]=new moleculeobject;
			moldestarray[totalmolecules]=newlmoleculeobject();
			

			if(moldestarray[totalmolecules]) {

			int moltype=GetMoleculeType(curmolecule);// Get molecule type for pronunciation, syllable identification

			int xlextype=LXGetType(curmolecule->X);// Get lexical type of atom 
			int rlextype=LXGetType(curmolecule->R);// Get lexical type of atom 
			int ylextype=LXGetType(curmolecule->Y);// Get lexical type of atom 
			int clextype=LXGetType(curmolecule->C);// Get lexical type of atom 
			int qlextype=LXGetType(curmolecule->Q);// Get lexical type of atom 
			int qattrlextype=LXGetType(curmolecule->QAttr);// Get lexical type of atom 

			if(moltype==2) {
				ylextype=2;
	
				}	
			else if(moltype==3) {
				ylextype=3;

				}

	
			LexRef=LXGetRef(curmolecule->X,&LexicalObjects[lextypestarts[xlextype]],0,lextypetotals[xlextype]-1)+lextypestarts[xlextype];

			moldestarray[totalmolecules]->R=LXGetRef(curmolecule->R,&LexicalObjects[lextypestarts[rlextype]],0,lextypetotals[rlextype]-1)+lextypestarts[rlextype];
			moldestarray[totalmolecules]->Y=LXGetRef(curmolecule->Y,&LexicalObjects[lextypestarts[ylextype]],0,lextypetotals[ylextype]-1)+lextypestarts[ylextype];
			moldestarray[totalmolecules]->C=LXGetRef(curmolecule->C,&LexicalObjects[lextypestarts[clextype]],0,lextypetotals[clextype]-1)+lextypestarts[clextype];
			moldestarray[totalmolecules]->Q=LXGetRef(curmolecule->Q,&LexicalObjects[lextypestarts[qlextype]],0,lextypetotals[qlextype]-1)+lextypestarts[qlextype];
			moldestarray[totalmolecules]->W=curmolecule->W;
			moldestarray[totalmolecules]->QAttr=LXGetRef(curmolecule->QAttr,&LexicalObjects[lextypestarts[qattrlextype]],0,lextypetotals[qattrlextype]-1)+lextypestarts[qattrlextype];
			moldestarray[totalmolecules]->RF=curmolecule->RF;
			moldestarray[totalmolecules]->Flag=curmolecule->Flag;
			moldestarray[totalmolecules]->LexID=curmolecule->LexID;

			if(LexRef>=0&&LexRef<500000) {
				int m=LexicalObjects[LexRef]->moleculecount; // current lexicon's molecule count
				int *newmolarray=new int[m+1]; // make array 1 bigger
				for(int a=0;a<m;a++) {
					newmolarray[a]=LexicalObjects[LexRef]->molecules[a];
					}

				newmolarray[m]=totalmolecules; // point to newly created molecule

				if(LexicalObjects[LexRef]->moleculecount) delete LexicalObjects[LexRef]->molecules;
				LexicalObjects[LexRef]->moleculecount++;
				LexicalObjects[LexRef]->molecules=newmolarray;
			}
			



			totalmolecules++;
			}
		}
	}

	delete curmolecule;
	fclose(fp);

	return(totalmolecules);

	}

int AddTempLexicalObject(char *string) {



	int TempLexRef=LXGetRef(string,&LexicalObjects[lextypestarts[TEMPLEXPOS]],0,lextypetotals[TEMPLEXPOS]-1);

	if(TempLexRef<=0||lextypetotals[TEMPLEXPOS]==0) {
	
	if(LXAddNewLexicalWord(string,&LexicalObjects[lextypestarts[TEMPLEXPOS]],&lextypetotals[TEMPLEXPOS])) {

		}
	}


	
	return(0);
	}


struct lexicalobject *GetLexicalObject(char *string){

	int LexRef=LXGetRef(string,&LexicalObjects[lextypestarts[BASELEXPOS]],0,lextypetotals[BASELEXPOS]-1);

	if(LexRef>=0&&LexRef<lextypetotals[BASELEXPOS]) {
		return(LexicalObjects[LexRef]);
		}
	else {

		if(!lextypetotals[TEMPLEXPOS]) return(NULL);

	int LexRef=LXGetRef(string,&LexicalObjects[lextypestarts[TEMPLEXPOS]],0,lextypetotals[TEMPLEXPOS]-1);

	if(LexRef>=0&&LexRef<lextypetotals[TEMPLEXPOS]) {
		return(LexicalObjects[LexRef+lextypestarts[TEMPLEXPOS]]);
		}



		return(NULL);
		}
	}

int GetLexicalReference(char *string){

	int LexRef=LXGetRef(string,&LexicalObjects[lextypestarts[BASELEXPOS]],0,lextypetotals[BASELEXPOS]-1);

	if(LexRef>=0&&LexRef<lextypetotals[BASELEXPOS]) {
		return(LexRef);
		}
	else {

		if(!lextypetotals[TEMPLEXPOS]) return(-1);

		int LexRef=LXGetRef(string,&LexicalObjects[lextypestarts[TEMPLEXPOS]],0,lextypetotals[TEMPLEXPOS]-1);

		if(LexRef>=0&&LexRef<lextypetotals[TEMPLEXPOS]) {
			return(LexRef+lextypestarts[TEMPLEXPOS]);
			}



		}

	return(-1);// Not found
	}

struct lexicalobject *GetLexicalObjectAt(int LexRef){

	if(LexRef>=0&&LexRef<500000) {
		return(LexicalObjects[LexRef]);
		}
	else {
		return(NULL);
		}
	}

struct moleculeobject *GetMoleculeObjectAt(int MolRef){
	if(MolRef>=0&&MolRef<TotalMolObjects) {
		return(MoleculeObjects[MolRef]);
		}
	else {
		return(NULL);
		}


	}

int IsKnowledgeLoaded() {
	if(TotalMolObjects) return(1);
	else return(0);
	}


int OpenAndLoadKnowledgeFiles(HWND hDlg) {

		if(MessageBox(hDlg,"Press OK to Load entire knowledge network files","Knowledge Network Load",MB_OKCANCEL)==IDOK) {

			BOOL bFileOpened=openisylknowledge(hDlg,szAFileName,_T("TXT (*.txt)\0*.txt\0All Files (*.*)\0*.*\0") );

			if( bFileOpened ) {
				SetDlgItemText( hDlg, IDC_MOLECULEFILENAME, szAFileName );
				strcpy(szOutFileName,szAFileName);
				strcpy(szOutFileName2,szAFileName);
				make_ext(szOutFileName,"lex");
				make_ext(szOutFileName2,"mol");
				LoadAllLexicalObjects(szOutFileName);
				LoadAllMoleculeObjects(szOutFileName2);

				LexRefDerivative=GetLexicalReference("Derivative");

				return(1);
				}

		}
		return(0);
}



/*****************************************************************************************
* About() *
*---------*
*   Description:
*       Message handler for the "About" box.
******************************************************************************************/
   


LRESULT CALLBACK KGDialogProc( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
    USES_CONVERSION;
	BOOL				bFileOpened;
	HWND hwndList;
	char string[128];
	char string2[128];
	int u,n,m;

	int xlextype=0;


    switch( message )
    {
		case WM_INITDIALOG:
			TotalLexObjects=0;
			TotalMolObjects=0;
			break;


		case WM_CLOSE:

		//	DeleteMoleculeObjects(MoleculeObjects,TotalMolObjects);
		//	LXDeleteObjects(LexicalObjects,TotalLexObjects);

			break;


        case WM_COMMAND:
        {
            WORD wId    = LOWORD(wParam); 
            WORD wEvent = HIWORD(wParam); 
            
            switch( wId )
            {
                case IDOK:
                case IDCANCEL:
                    EndDialog( hDlg, LOWORD(wParam) );
                    return TRUE;

				case IDC_BUTTON5:

					SetDlgItemText( hDlg, IDC_STATUS, "Identifying all lexical objects...");

					if(ConvertLexicalObjects(szAFileName)) {

						wsprintf(string,"Lexs %d Idioms %d Prons %d Syllables %d",lextypetotals[BASELEXPOS],lextypetotals[IDIOMLEXPOS],lextypetotals[PRONLEXPOS],lextypetotals[SYNLEXPOS]);
						SetDlgItemText( hDlg, IDC_TOTALLEXICALITEMS, string );
				////		SaveLexicals("c:\\alllexs0.txt",&LexicalObjects[lextypestarts[BASELEXPOS]], lextypetotals[BASELEXPOS]);
				//		SaveLexicals("c:\\alllexs1.txt",&LexicalObjects[lextypestarts[1]], lextypetotals[1]);
				//		SaveLexicals("c:\\alllexs2.txt",&LexicalObjects[lextypestarts[2]], lextypetotals[2]);
				//		SaveLexicals("c:\\alllexs3.txt",&LexicalObjects[lextypestarts[3]], lextypetotals[3]);



						SetDlgItemText( hDlg, IDC_STATUS, "Mapping all molecules to lexical objects...");
						TotalMolObjects=ConvertMoleculeObjects(szAFileName,MoleculeObjects,MAXMOLECULEOBJECTS);


						SetDlgItemText( hDlg, IDC_STATUS, "Mapping all idioms to lexical objects...");
						ConvertIdioms(&LexicalObjects[lextypestarts[IDIOMLEXPOS]], lextypetotals[IDIOMLEXPOS]);
#if 1

						SetDlgItemText( hDlg, IDC_STATUS, "Saving lexical objects to disk...");
						SaveAllLexicalObjects(szOutFileName);
						SetDlgItemText( hDlg, IDC_STATUS, "Saving molecule objects to disk...");
						SaveMoleculeObjects(szOutFileName2,MoleculeObjects, TotalMolObjects);
#endif
						SetDlgItemText( hDlg, IDC_STATUS, "Completed...");

						}

                  return TRUE;

				case IDC_BUTTON3:
	
					GetDlgItemText(hDlg,IDC_EDIT1,string,128);

		//			n=LXGetRef(string,LexicalObjects,0,TotalLexObjects-1);
					
					n=LXGetRef(string,&LexicalObjects[lextypestarts[xlextype]],0,lextypetotals[xlextype]-1);

			



		            if( n>=0 ) {
						wsprintf(string2," LexRef=%d",n);
						 SetDlgItemText( hDlg, IDC_LEXREF, string2 );

	 					 hwndList = GetDlgItem(hDlg, IDC_LIST1); 
				         SendMessage(hwndList, LB_RESETCONTENT,0,0);

						 m=LexicalObjects[n]->moleculecount;
						 for(int a=0;a<m;a++) {
							 int molref=LexicalObjects[n]->molecules[a];
							 wsprintf(string,"R:%s Y:%s C:%s Q:%s",LexicalObjects[MoleculeObjects[molref]->R]->bytes,LexicalObjects[MoleculeObjects[molref]->Y]->bytes,LexicalObjects[MoleculeObjects[molref]->C]->bytes,LexicalObjects[MoleculeObjects[molref]->Q]->bytes);
					         SendMessage(hwndList, LB_ADDSTRING,0,(LPARAM)string);
							}

						 hwndList = GetDlgItem(hDlg, IDC_LIST2); 
				         SendMessage(hwndList, LB_RESETCONTENT,0,0);
						 SendMessage(hwndList, LB_INITSTORAGE,256,64);

						 m=LexicalObjects[n]->idiomcount;
						 for(int a=0;a<m;a++) {
							 int molref=LexicalObjects[n]->idioms[a];
							 wsprintf(string,"%s",LexicalObjects[molref]->bytes);
					         SendMessage(hwndList, LB_ADDSTRING,0,(LPARAM)string);
							}




					
						}
					else {
						SetDlgItemText( hDlg, IDC_LEXREF, "Not Found" );
						}


				return TRUE;
			case IDC_BUTTON4:

				LoadAllLexicalObjects(szOutFileName);

				LoadAllMoleculeObjects(szOutFileName2);

				wsprintf(string,"Lexs %d Idioms %d Prons %d Syllables %d",lextypetotals[BASELEXPOS],lextypetotals[IDIOMLEXPOS],lextypetotals[PRONLEXPOS],lextypetotals[SYNLEXPOS]);
				SetDlgItemText( hDlg, IDC_TOTALLEXICALITEMS, string );
	
				return TRUE;

			case IDC_BUTTON1:
					bFileOpened=openisylknowledge(hDlg,szAFileName,_T("TXT (*.txt)\0*.txt\0All Files (*.*)\0*.*\0") );

		            if( bFileOpened ) {
						 SetDlgItemText( hDlg, IDC_MOLECULEFILENAME, szAFileName );
						 strcpy(szOutFileName,szAFileName);
						 strcpy(szOutFileName2,szAFileName);
						 make_ext(szOutFileName,"lex");
						 make_ext(szOutFileName2,"mol");

					}


				return TRUE;

            }

        }
	}
    return FALSE;
	}   /* About */
