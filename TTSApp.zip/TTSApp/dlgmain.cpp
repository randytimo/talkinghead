//#define LOCALONLY 1


/////////////////////////////////////////////////////////////////////////
//  DlgMain.CPP
//
//  This module handles the main dialog box, and it's controls.
//
//  The main dialog is actually the application's main window class, there
//  is no conventional "Window class", only this dialog class which is
//  registered in WinMain.
//
//  Revision History:
//      06/06/99    Created
//Copyright (c) Microsoft Corporation. All rights reserved.
//
/////////////////////////////////////////////////////////////////////////
#include "globals.h"
#include "salience.h"

#include "lesson14.h"
#include "WorldFacts.h"
#include "getwebfile.h"
#include "time.h"
#include "mmsystem.h"
#include "molecule.h"

#include "kdbase.h"
#include "kgconverter.h"
#include "impwizard.h"
#include "callcenter.h"
#include "lexical.h"
#include "wakeup.h"





char koutstring[4096];
char string4[512];

#define IDT_TIMER1 1234
extern int dotext;

int LOCALONLY=1;

int timeout=0;

//
// Other local functions
//
inline void TTSAppStatusMessage( HWND hWnd, TCHAR* szMessage );

// some ample queries for the list box
char username[80]="Joe";
int numbersamples=7;
char samplestrings[32][80]={
           "what is the population of pittsburgh",
           "what is an aardvark",
           "what do you know about the wizard of oz",
           "what is the population of minneapolis", 
           "what is a piano", 
           "who is the president of the united states", 
		   "who invented the light bulb"};



// ---------------------------------------------------------------------------
// CTTSApp::DlgProcMain
// ---------------------------------------------------------------------------
// Description:         Main window procedure.
// Arguments:
//  HWND [in]           Window handle.
//  UINT [in]           Message identifier.
//  WPARAM [in]         Depends on message.
//  LPARAM [in]         Depends on message.
// Returns:
//  LPARAM              Depends on message.




void CTTSApp::RecoEvent()
{
    USES_CONVERSION;
    CSpEvent event;
int p;

    // Process all of the recognition events
    while (event.GetFrom(m_cpRecoCtxt) == S_OK)
    {
        switch (event.eEventId)
        {
            case SPEI_SOUND_START:
                m_bInSound = TRUE;
                break;

            case SPEI_SOUND_END:
                if (m_bInSound)
                {
                    m_bInSound = FALSE;
                    if (!m_bGotReco)
                    {
                        // The sound has started and ended, 
                        // but the engine has not succeeded in recognizing anything
						const TCHAR szNoise[] = _T("<noise>");
//                        ::SendDlgItemMessage( m_hDlg, IDC_EDIT_DICT, 
//							EM_REPLACESEL, TRUE, (LPARAM) szNoise );
                    }
                    m_bGotReco = FALSE;
                }
                break;

            case SPEI_RECOGNITION:
                // There may be multiple recognition results, so get all of them
                {
                    m_bGotReco = TRUE;
                    static const WCHAR wszUnrecognized[] = L"<Unrecognized>";

                    CSpDynamicString dstrText;

	
#if 0	
                    if (FAILED(event.RecoResult()->GetText(SP_GETWHOLEPHRASE, SP_GETWHOLEPHRASE, FALSE, 
                                                            &dstrText, NULL)))
                    {
                        dstrText = wszUnrecognized;
                    }
#else
                   if (FAILED(event.RecoResult()->GetText(SP_GETWHOLEPHRASE, SP_GETWHOLEPHRASE, TRUE, 
                                                            &dstrText, NULL)))
                    {
                        dstrText = wszUnrecognized;
                    }
#endif

					                    // Concatenate a space onto the end of the recognized word
                    dstrText.Append(L" ");

//                    ::SendDlgItemMessage( m_hDlg, IDC_EDIT_DICT, EM_REPLACESEL, TRUE, (LPARAM) W2T(dstrText) );

					char *resulttext=strlwr(W2T(dstrText));


					SetDlgItemText(m_hDlg,IDC_IHEARD,resulttext);

					if(strlen(resulttext)<3) break;

					if(callcentermuted()) {
						break;
						}

					if(incall) {

						callcenterresetsilence();

					 if(!strncmp(resulttext,"quit",4)||!strncmp(resulttext,"stop",4)||!strncmp(resulttext,"end",3)) {
						 m_cpVoice->Speak( L"Call complete...", SPF_ASYNC, 0 );
						 incall=0;
						 break;
						}
					 else if(!strncmp(resulttext,"goodbye",5)) {
						 m_cpVoice->Speak( L"Call complete...", SPF_ASYNC, 0 );
						 incall=0;
						 break;
						}
					 else if(containsstring(resulttext,"thank you")) {
						 m_cpVoice->Speak( L"You're welcome.", SPF_ASYNC, 0 );
						
						 break;
						}
					else if(containsstring(resulttext,"back")||containsstring(resulttext,"menu")) {
						if(callstate) {
							callstate=2;
							callcenterstatemessage();
							}
						 break;
						}
					else if(!strncmp(resulttext,"help",4)) {
						callcenterstatemessage();
						 break;
						}
#if 1
					if(callstate==2) {
					 if(containsstring(resulttext,"do not call")) {
						if(containsstring(resulttext,"on ")||containsstring(resulttext,"add ")||containsstring(resulttext,"put ")) {
							callcentermutetime(300);
							callcentersetdonotcall(1);
							m_cpVoice->Speak( L"You have been put on the do not call list.", SPF_ASYNC, 0 );
							}
						else if(containsstring(resulttext,"off ")||containsstring(resulttext,"remove")) {
							callcentermutetime(300);
							callcentersetdonotcall(0);
							m_cpVoice->Speak( L"You have been taken off the do not call list.", SPF_ASYNC, 0 );
							}
						 break;
						}


					else if(containsstring(resulttext,"bill")&&containsstring(resulttext,"last")) {
						callcenterlastmonthbill();
						break;
		
						}
					else if(containsstring(resulttext,"minute")&&containsstring(resulttext,"last")) {
						callcenterlastmonthminutes();
						 break;
						}


					else if(containsstring(resulttext,"add ")||containsstring(resulttext,"to get ")) {

							if(containsstring(resulttext,"caller")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your caller ID is activated.", SPF_ASYNC, 0 );
								break;
	
								}
							else if(containsstring(resulttext,"security")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your security screen is activated.", SPF_ASYNC, 0 );
								break;
								}
							else if(containsstring(resulttext,"waiting")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your call waiting is activated.", SPF_ASYNC, 0 );
								break;
								}
							else if(containsstring(resulttext,"mail")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your voice mail is activated.", SPF_ASYNC, 0 );
								break;
								}
							else if(containsstring(resulttext,"ringing")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your custom ringing is activated.", SPF_ASYNC, 0 );
								break;
								}
							else if(containsstring(resulttext,"forwarding")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your call forwarding is activated.", SPF_ASYNC, 0 );
								break;
								}
							else if(containsstring(resulttext,"return")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your call return is activated.", SPF_ASYNC, 0 );
								break;
								}
					}

					else if(containsstring(resulttext,"disconnected")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"You had 3 late payments, please contact customer service to reconnect.", SPF_ASYNC, 0 );
								break;
								}
					else if(containsstring(resulttext,"features")&&containsstring(resulttext,"available")) {
								SetDlgItemText( m_hWnd, IDE_EDITBOX, "Caller I Dee, Security Screen, Call Waiting, Voice Mail, Custom Ringing, 3 Way Calling, Call Forwarding, or Last Call Return");
								HandleSpeak();
 								break;
								}
}
#endif

	
					 switch(callstate) {
						case 0: //waiting for PIN code
							if(strlen(resulttext)<6) break;

							
							if(callcentersecuritycode(resulttext)) {
								callcentermutetime(200);

							    m_cpVoice->Speak( L"Thank you, please say the last 3 digits of your zipcode.", SPF_ASYNC, 0 );
								callstate=1;

								}
							else {
								callcentermutetime(300);
							    m_cpVoice->Speak( L"Unknown PIN, please try again.", SPF_ASYNC, 0 );
								callpintrys++;
								if(callpintrys==4) {
										callcentermutetime(200);
										m_cpVoice->Speak( L"I'm sorry, your PIN is unrecogized, call complete.", SPF_ASYNC, 0 );
										incall=0;
										callstate=0;
									}
								}

							break;
						case 1: //waiting for zip code
							if(callcenterzipcode(resulttext)) {
								char string[256];
								callcentermutetime(300);
					//			wsprintf(string,"Hello %s. Say menu or help at anytime for assistance. Would you like account maintenance, billing, or customer service?",currentcontactname);
								wsprintf(string,"Hello %s, how may I help you?",currentcontactname);
								SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
								HandleSpeak();
   								callstate=2;
								}
							else {
								callcentermutetime(300);
							    m_cpVoice->Speak( L"Incorrect code, please try again.", SPF_ASYNC, 0 );
								callziptrys++;
								if(callziptrys==4) {
									callcentermutetime(300);
									m_cpVoice->Speak( L"I'm sorry, your access code is unrecogized, please hold for the next available service representative.", SPF_ASYNC, 0 );
										incall=0;
									}
								}

							break;
						case 2:// Past security cleared
						if(containsstring(resulttext,"ill")) {
								SetDlgItemText( m_hWnd, IDE_EDITBOX, "Would you like to review last month's bill or review your minutes used?");
								HandleSpeak();
   								callstate=3;
							}
						else if(containsstring(resulttext,"count")) {
								SetDlgItemText( m_hWnd, IDE_EDITBOX, "Would you like to review your features or add new features?");
								HandleSpeak();
   								callstate=4;
							}
						else if(containsstring(resulttext,"service")) {
								SetDlgItemText( m_hWnd, IDE_EDITBOX, "What type of problem are you having with your service, or would you like to be put on the do not call list?");
								HandleSpeak();
   								callstate=5;
							}

							break;


						case 3:// Billing

		
								if(containsstring(resulttext,"ill")) {
									callcenterlastmonthbill();
									}
								else if(containsstring(resulttext,"minute")) {
									callcenterlastmonthminutes();
									}
		
		
						break;

						case 4:// Past security cleared
							if(containsstring(resulttext,"review")) {
								callcenterfunctionsselected();
								}
							else if(containsstring(resulttext,"add")) {

								SetDlgItemText( m_hWnd, IDE_EDITBOX, "Caller I Dee, Security Screen, Call Waiting, Voice Mail, Custom Ringing, 3 Way Calling, Call Forwarding, or Last Call Return");
								HandleSpeak();
   								callstate=6;

								}

							break;

						case 5:// Past security cleared

							if(containsstring(resulttext,"disconnected")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"You had 3 late payments, please contact customer service to reconnect.", SPF_ASYNC, 0 );
								}
							else if(containsstring(resulttext,"do not call")) {
								if(containsstring(resulttext,"on ")) {
									callcentermutetime(300);
									callcentersetdonotcall(1);
									m_cpVoice->Speak( L"You have been put on the do not call list.", SPF_ASYNC, 0 );
									}
								else if(containsstring(resulttext,"off ")) {
									callcentermutetime(300);
									callcentersetdonotcall(0);
									m_cpVoice->Speak( L"You have been taken off the do not call list.", SPF_ASYNC, 0 );
									}

								}


							break;
						case 6:// Past security cleared

							if(containsstring(resulttext,"caller")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your caller ID is activated.", SPF_ASYNC, 0 );
								}
							else if(containsstring(resulttext,"security")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your security screen is activated.", SPF_ASYNC, 0 );
								}
							else if(containsstring(resulttext,"waiting")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your call waiting is activated.", SPF_ASYNC, 0 );
								}
							else if(containsstring(resulttext,"mail")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your voice mail is activated.", SPF_ASYNC, 0 );
								}
							else if(containsstring(resulttext,"ringing")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your custom ringing is activated.", SPF_ASYNC, 0 );
								}
							else if(containsstring(resulttext,"forwarding")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your call forwarding is activated.", SPF_ASYNC, 0 );
								}
							else if(containsstring(resulttext,"return")) {
								callcentermutetime(300);
								m_cpVoice->Speak( L"Your call return is activated.", SPF_ASYNC, 0 );
								}


							break;

					 }	

						break;

						}




					if(!strcmp(resulttext,"speak ")) {
						//HandleSpeak();
						PostMessage(m_hWnd,WM_COMMAND,IDB_SPEAK,0);
						}
					else if(!strncmp(resulttext,"quit ",5)) {
						//HandleSpeak();
						PostMessage(m_hWnd,WM_COMMAND,IDB_STOP,0);
						}

					else if(!strcmp(resulttext,"rotate ")) {
						faceon=0;
						}
					else if(!strcmp(resulttext,"move ")) {
						faceon=0;
						}
					else if(!strcmp(resulttext,"stop rotating ")) {
						faceon=1;
						}
					else if(!strcmp(resulttext,"stop moving ")) {
						faceon=1;
						}
					else if(!strcmp(resulttext,"stops rotating ")) {
						faceon=1;
						}
					else if(!strcmp(resulttext,"spin ")) {
						faceon=0;
						}
					else if(!strcmp(resulttext,"stop spinning ")) {
						faceon=1;
						}
					else if(!strcmp(resulttext,"stops spinning ")) {
						faceon=1;
						}
					else if(!strncmp(resulttext,"stop ",5)) {
					//HandleSpeak();
						PostMessage(m_hWnd,WM_COMMAND,IDB_STOP,0);
						}

					else if(containsstring(resulttext,"repeat that")) {
						HandleSpeak();
						}
					else if(containsstring(resulttext,"three dimensional")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"OK, please wait...", SPF_ASYNC, 0 );

						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON5,0);
						}
					else if(containsstring(resulttext,"very good")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Thank you!", SPF_ASYNC, 0 );

						}
					else if(containsstring(resulttext,"good job ")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Thank you!", SPF_ASYNC, 0 );

						}
					else if(containsstring(resulttext,"great job ")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Thank you! I do my best.", SPF_ASYNC, 0 );

						}
					else if(containsstring(resulttext,"what you know")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Countries of the world is my current specialty.", SPF_ASYNC, 0 );

						}
					else if(containsstring(resulttext,"what do you know")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Countries of the world is my current specialty.", SPF_ASYNC, 0 );

						}
					else if(containsstring(resulttext,"ask you")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Countries of the world is my current specialty.", SPF_ASYNC, 0 );

						}
					else if(containsstring(resulttext,"good morning")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Good morning to you.", SPF_ASYNC, 0 );

						}
					else if(containsstring(resulttext,"good evening")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Good evening human.", SPF_ASYNC, 0 );

						}
					else if(containsstring(resulttext,"good afternoon")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Good afternoon.", SPF_ASYNC, 0 );

						}
					else if(containsstring(resulttext,"good night")) {
						//HandleSpeak();
						 m_cpVoice->Speak( L"Good night human.", SPF_ASYNC, 0 );

						}
					else if(!strncmp(resulttext,"hi ",3)) {
//						 m_cpVoice->Speak( L"Hello human!", SPF_ASYNC, 0 );

					char string[80];
					wsprintf(string,"Hi there %s.",username);
						SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
						HandleSpeak();


						}	
					else if(!strncmp(resulttext,"think you ",10)) {
						 m_cpVoice->Speak( L"You're very welcome.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"sorry")) {
						switch(rand()&3) {
							case 0:
								m_cpVoice->Speak( L"Thats alright.", SPF_ASYNC, 0 );

								break;
							case 1:
								m_cpVoice->Speak( L"Don't worry about it.", SPF_ASYNC, 0 );
								break;
							case 2:
								m_cpVoice->Speak( L"No problem.", SPF_ASYNC, 0 );
								break;
							case 3:
								m_cpVoice->Speak( L"That's ok.", SPF_ASYNC, 0 );
								break;


						}

						 


						}	
					else if(containsstring(resulttext,"stop text ")) {
						dotext=0;
						transphead=0;
						}	
					else if(containsstring(resulttext,"start text ")) {
						dotext=1;
						transphead=1;
						}	
					else if(containsstring(resulttext,"start the text ")) {
						dotext=1;
						transphead=1;
						}	
					else if(containsstring(resulttext,"stop the text ")) {
						dotext=0;
						transphead=0;
						}	
				else if(!strncmp(resulttext,"hello ",6)) {
					//	 m_cpVoice->Speak( L"Hello human!", SPF_ASYNC, 0 );
					char string[80];
					wsprintf(string,"Hello %s.",username);
						SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
						HandleSpeak();

						}	
				else if(containsstring(resulttext,"who am i ")) {
					//	 m_cpVoice->Speak( L"Hello human!", SPF_ASYNC, 0 );
					char string[80];
					wsprintf(string,"I believe your name is %s.",username);
						SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
						HandleSpeak();

						}	
				else if(containsstring(resulttext,"swallow ")&&containsstring(resulttext,"speed ")) {
						 m_cpVoice->Speak( L"African or European?", SPF_ASYNC, 0 );
						}	
				else if(containsstring(resulttext,"what is my name ")) {
					//	 m_cpVoice->Speak( L"Hello human!", SPF_ASYNC, 0 );
					char string[80];
					wsprintf(string,"I believe your name is %s.",username);
						SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
						HandleSpeak();

						}	
					else if(containsstring(resulttext,"how are you ")) {
						 m_cpVoice->Speak( L"I'm doing great! Can I answer a question for you?", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"thank you")) {
						 m_cpVoice->Speak( L"You are welcome.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"thanks")) {
						 m_cpVoice->Speak( L"You are welcome.", SPF_ASYNC, 0 );
						}
					else if(containsstring(resulttext,"full screen")) {
						 m_cpVoice->Speak( L"OK.", SPF_ASYNC, 0 );
						 if(hWnd) ShowWindow(hWnd,SW_SHOWMAXIMIZED);
						}
					else if(containsstring(resulttext,"goodbye")) {
						 m_cpVoice->Speak( L"Bye.", SPF_ASYNC, 0 );
						 if(hWnd) {
							 KillGLWindow();
							}
						}
					else if(containsstring(resulttext,"the time")) {
						char string[40];
						_strtime( string );
						    SetDlgItemText( m_hWnd, IDE_EDITBOX, string );
							HandleSpeak();

						}
				else if(containsstring(resulttext,"time it is")) {
						char string[40];
						_strtime( string );
						    SetDlgItemText( m_hWnd, IDE_EDITBOX, string );
							HandleSpeak();

						}
				else if(containsstring(resulttext,"time is it")) {
						char string[40];
						_strtime( string );
						    SetDlgItemText( m_hWnd, IDE_EDITBOX, string );
							HandleSpeak();

						}
				else if(containsstring(resulttext,"todays date")) {
						char string[40];
						_strdate( string );
						    SetDlgItemText( m_hWnd, IDE_EDITBOX, string );
							HandleSpeak();

						}

				else if(containsstring(resulttext,"date todays")) {
						char string[40];
						_strdate( string );
						    SetDlgItemText( m_hWnd, IDE_EDITBOX, string );
							HandleSpeak();

						}
			else if(containsstring(resulttext,"is the date")) {
						char string[40];
						_strdate( string );
						    SetDlgItemText( m_hWnd, IDE_EDITBOX, string );
							HandleSpeak();

						}


					
					else if(!strcmp(resulttext,"what is your name ")) {
						 m_cpVoice->Speak( L"My name is Ike.", SPF_ASYNC, 0 );
						}	
					else if(!strncmp(resulttext,"why are you ",12)) {
						 m_cpVoice->Speak( L"Because that is the way I was made.", SPF_ASYNC, 0 );
						}	
					else if(!strncmp(resulttext,"can i ",6)) {
						 m_cpVoice->Speak( L"You go right ahead.", SPF_ASYNC, 0 );
						}	
					else if(!strcmp(resulttext,"what old are you ")) {
						 m_cpVoice->Speak( L"I am not even a year old.", SPF_ASYNC, 0 );
						}	
					else if(!strncmp(resulttext,"why should i invest ",20)) {
						 m_cpVoice->Speak( L"Because it is the core people that build a successful company.", SPF_ASYNC, 0 );
						}	
					else if(!strncmp(resulttext,"can you ",8)) {
						switch(rand()&3) {
							case 0:
								 m_cpVoice->Speak( L"I will do my best.", SPF_ASYNC, 0 );

								break;
							case 1:
								m_cpVoice->Speak( L"Some things I am better at than others.", SPF_ASYNC, 0 );
								break;
							case 2:
								m_cpVoice->Speak( L"I am young but I will try.", SPF_ASYNC, 0 );
								break;
							case 3:
								m_cpVoice->Speak( L"I am limited to what I know.", SPF_ASYNC, 0 );
								break;


						}
						}	
						else if(!strncmp(resulttext,"how can you ",12)) {
						switch(rand()&3) {
							case 0:
								 m_cpVoice->Speak( L"Through advanced algorithms.", SPF_ASYNC, 0 );

								break;
							case 1:
								m_cpVoice->Speak( L"By utilizing knowledge.", SPF_ASYNC, 0 );
								break;
							case 2:
								m_cpVoice->Speak( L"Because I have been taught to.", SPF_ASYNC, 0 );
								break;
							case 3:
								m_cpVoice->Speak( L"It is within my skill set.", SPF_ASYNC, 0 );
								break;


						}
						}	
						else if(!strncmp(resulttext,"how do you know",12)) {
						switch(rand()&3) {
							case 0:
								 m_cpVoice->Speak( L"Through advanced algorithms.", SPF_ASYNC, 0 );

								break;
							case 1:
								m_cpVoice->Speak( L"By utilizing knowledge.", SPF_ASYNC, 0 );
								break;
							case 2:
								m_cpVoice->Speak( L"Because I have been taught.", SPF_ASYNC, 0 );
								break;
							case 3:
								m_cpVoice->Speak( L"It is within my skill set.", SPF_ASYNC, 0 );
								break;


						}
						}	
					else if(containsstring(resulttext,"make more money")) {
						 m_cpVoice->Speak( L"Invest in a promising young company.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"make money")) {
						 m_cpVoice->Speak( L"Invest in a promising young company.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"make me rich")) {
						 m_cpVoice->Speak( L"Invest in a promising young company.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"i get rich")) {
						 m_cpVoice->Speak( L"Invest in a promising young company.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"seafood ")) {
						 m_cpVoice->Speak( L"There is a Red Lobster 3 miles ahead on your left.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"chinese ")) {
						 m_cpVoice->Speak( L"There is a Chinese restaurant called HAPPY GARDEN at 2212 COMMERCE BLVD in MOUND", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"fast food ")) {
						 m_cpVoice->Speak( L"There is a McDonalds located at 15500 HIGHWAY 7 in MINNETONKA.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"restaurant ")) {
						 m_cpVoice->Speak( L"There is an OLD CHICAGO located at 17790 HIGHWAY 7 in MINNETONKA.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"pizza ")) {
						 m_cpVoice->Speak( L"There is a Deevawnies pizza located at 15200 HIGHWAY 7 in MINNETONKA.", SPF_ASYNC, 0 );
						}	


					else if(!strcmp(resulttext,"pause ")) {
						//HandleSpeak();
						PostMessage(m_hWnd,WM_COMMAND,IDB_PAUSE,0);
						}
					else if(!strcmp(resulttext,"resume ")) {
						//HandleSpeak();
						PostMessage(m_hWnd,WM_COMMAND,IDB_PAUSE,0);
						}
					else if(!strcmp(resulttext,"reset ")) {
						//HandleSpeak();
						PostMessage(m_hWnd,WM_COMMAND,IDB_RESET,0);
						}
					else if(!strncmp(resulttext,"will you ",9)) {
						 m_cpVoice->Speak( L"I will do my best.", SPF_ASYNC, 0 );
						}	
					else if(containsstring(resulttext,"quiet")) {
						mciSendString("stop freddy",NULL,0,0);
						}	
					else if(containsstring(resulttext,"the music")) {
						mciSendString("stop freddy",NULL,0,0);
						}	
					else if(containsstring(resulttext,"music")) {
						mciSendString("open c:\\test.mp3 alias freddy",NULL,0,0);
						mciSendString("play freddy",NULL,0,0);
						}


					else if(containsstring(resulttext,"call center")) {
#if 1
						mciSendString("close freddy",NULL,0,0);

						mciSendString("open c:\\phnring.wav alias freddy",NULL,0,0);
						mciSendString("play freddy",NULL,0,0);
	
						Sleep(3000);
						mciSendString("close freddy",NULL,0,0);


					    m_cpVoice->Speak( L"K-Netica call center, please say your 6 digit PIN.", SPF_ASYNC, 0 );
						incall=1;
						callcenterinitialization(this,m_hWnd);

#else

						char string[80];
						mciSendString("close freddy",NULL,0,0);

						mciSendString("open c:\\phnring.wav alias freddy",NULL,0,0);
						mciSendString("play freddy",NULL,0,0);
	
						Sleep(3000);
						mciSendString("close freddy",NULL,0,0);

					    m_cpVoice->Speak( L"K-Netica call center, please enter security code.", SPF_ASYNC, 0 );

						Sleep(4000);
	
						mciSendString("open c:\\scode.wav alias freddy",NULL,0,0);
						mciSendString("play freddy",NULL,0,0);


	
						Sleep(4000);

						mciSendString("close freddy",NULL,0,0);

						wsprintf(string,"Hello %s. How may I help you?",username);
						SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
						HandleSpeak();


				//	    m_cpVoice->Speak( L"K-Netica call center, please enter security code.", SPF_ASYNC, 0 );




#endif


						}	




#ifdef LOCALONLY
	//				if(LOCALONLY) {
					if(strlen(resulttext)>6) {
						char tempstring[512];
						strcpy(tempstring,resulttext);
						if(parse_sentence(strupr(tempstring))) {
							SetDlgItemText( m_hWnd, IDC_EDIT1, resulttext);
							PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON6,0);
							}
						}
	//				}
		//			else {
#else




					else if(p=containsstring(resulttext,"forecast for ")) {
						//HandleSpeak();
					//	m_cpVoice->Speak( L"I'll check the national weather service.", SPF_ASYNC, 0 );
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[p]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON1,0);
						}
					else if(p=containsstring(resulttext,"weather like in ")) {
						//HandleSpeak();
					//	m_cpVoice->Speak( L"I'll check the national weather service.", SPF_ASYNC, 0 );
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[p]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON1,0);
						}
					else if(p=containsstring(resulttext,"weather in ")) {
						//HandleSpeak();
					//	m_cpVoice->Speak( L"I'll check the national weather service.", SPF_ASYNC, 0 );
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[p]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON1,0);
						}
					else if(p=containsstring(resulttext,"forecast in ")) {
						//HandleSpeak();
					//	m_cpVoice->Speak( L"I'll check the national weather service.", SPF_ASYNC, 0 );
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[p]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON1,0);
						}
					else if(p=containsstring(resulttext,"my name is ")) {
						
						strcpy(username, &resulttext[p]);
						char string[80];
						wsprintf(string,"Hello %s.",username);
						SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
						HandleSpeak();
						//W2T(dstrText);
						
						}
					else if(p=containsstring(resulttext,"birth stone ")) {
						
						
						char string[80];

						if(checkforbirthstone(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
					else if(p=containsstring(resulttext,"berth stone ")) {
						
						
						char string[80];

						if(checkforbirthstone(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
					else if(p=containsstring(resulttext,"gem stone ")) {
						
						
						char string[80];

						if(checkforbirthstone(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
				else if(p=containsstring(resulttext,"song from ")) {
					
						char string[256];

						if(checkforsongs(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
				else if(p=containsstring(resulttext,"songs from ")) {
					
						char string[256];

						if(checkforsongs(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
				else if(p=containsstring(resulttext,"songs in ")) {
					
						char string[256];

						if(checkforsongs(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
				else if(p=containsstring(resulttext,"sports events ")) {
					
						char string[1024];

						if(checkforsports(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
					else if(p=containsstring(resulttext,"sporting events ")) {
					
						char string[1024];

						if(checkforsports(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
				else if(p=containsstring(resulttext,"gemstone ")) {
						
						
						char string[80];

						if(checkforbirthstone(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
			else if(p=containsstring(resulttext,"birthday on ")) {
						
						
						char string[512];

						if(checkforbirthday(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
			else if(p=containsstring(resulttext,"bible verse about ")) {
						
						
						char string[1024];

						if(checkforbibleverse(&resulttext[p],string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
						}
			else if(p=containsstring(resulttext,"on channel ")) {
						
						char string[1024];

						if(checkfortvlisting(resulttext,string)) {
							SetDlgItemText( m_hWnd, IDE_EDITBOX, string);
							HandleSpeak();
							}
			}

#if 1
			else if(p=containsstring(resulttext,"about the word ")) {
						
						

						if(IsKnowledgeLoaded()) {
					//		strcpy(string4,&resulttext[p]);
							char *token;
							token = strtok( &resulttext[p], " " );

							struct lexicalobject *lexobj=GetLexicalObject(token);

							if( lexobj ) {
								int nummol=lexobj->moleculecount;
								if (nummol>20) nummol=20;

								strcpy(koutstring," ");

								for(int a=0;a<nummol;a++) {
									struct moleculeobject *molobj=GetMoleculeObjectAt(lexobj->molecules[a]);
									if(molobj) {
									struct lexicalobject *atomlexobjc=GetLexicalObjectAt(molobj->C);
									struct lexicalobject *atomlexobjy=GetLexicalObjectAt(molobj->Y);
									struct lexicalobject *atomlexobjr=GetLexicalObjectAt(molobj->R);
									sprintf(string4,"%s is a %s for %s in the context of %s. ",token,atomlexobjr->bytes,atomlexobjy->bytes,atomlexobjc->bytes);										     
									strcat(koutstring,string4);

									}
								}

							SetDlgItemText( m_hWnd, IDE_EDITBOX, koutstring);
							HandleSpeak();
							
							}
						}
			}
#endif









			else if(strlen(resulttext)>6&&LOCALONLY) {
						char tempstring[512];
						strcpy(tempstring,resulttext);
						if(parse_sentence(strupr(tempstring))) {
							SetDlgItemText( m_hWnd, IDC_EDIT1, resulttext);
							PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON6,0);
							}
						}








					else if(!strncmp(resulttext,"define ",7)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[7]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON3,0);
						}
					else if(!strncmp(resulttext,"defined ",8)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[8]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON3,0);
						}


#if 1
					else if(!strncmp(resulttext,"question ",9)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[9]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}

					else if(!strncmp(resulttext,"what is an ",11)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[0]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}

					else if(!strncmp(resulttext,"what is the ",12)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[0]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}

					else if(!strncmp(resulttext,"what is a ",10)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[0]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}
					else if(!strncmp(resulttext,"what is ",8)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[0]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}
					else if(!strncmp(resulttext,"what are ",9)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[0]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}
					else if(!strncmp(resulttext,"what his ",9)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[0]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}
					else if(!strncmp(resulttext,"who ",4)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[0]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}
					else if(!strncmp(resulttext,"what time ",10)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[0]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}
					else if(!strncmp(resulttext,"where is ",9)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[0]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}


#else
					else if(!strncmp(resulttext,"what is an ",11)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[11]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON3,0);
						}

					else if(!strncmp(resulttext,"what is the ",12)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[12]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON3,0);
						}

					else if(!strncmp(resulttext,"what is a ",10)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[10]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON3,0);
						}
					else if(!strncmp(resulttext,"what is ",8)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[8]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON3,0);
						}
					else if(!strncmp(resulttext,"what are ",9)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[9]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON3,0);
						}
					else if(!strncmp(resulttext,"what his ",9)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[9]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON3,0);
						}
					else if(!strncmp(resulttext,"question ",9)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[9]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}

#endif

					else if(!strncmp(resulttext,"search web ",10)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[10]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON2,0);
						}
					else if(!strncmp(resulttext,"tell me about ",14)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[14]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON2,0);
						}
					else if(!strncmp(resulttext,"what do you know about ",23)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[23]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON2,0);
						}
					else if(!strncmp(resulttext,"question ",9)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[9]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}
					else if(!strncmp(resulttext,"questioned ",11)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[11]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON4,0);
						}
					else if(!strncmp(resulttext,"what can you tell me about ",27)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[27]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON2,0);
						}
					else if(!strncmp(resulttext,"who is ",7)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[7]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON2,0);
						}
					else if(!strncmp(resulttext,"who his ",8)) {
						//HandleSpeak();
						SetDlgItemText( m_hWnd, IDC_EDIT1, &resulttext[8]);
						PostMessage(m_hWnd,WM_COMMAND,IDC_BUTTON2,0);
						}

#endif
//					}


#if 0

#define MY_MAX_ALTERNATES 4

   // setup MY_MAX_ALTERNATES phrase alternate objects 
    CComPtr<ISpPhraseAlt>   pcpPhrase[MY_MAX_ALTERNATES];
    ULONG ulCount;
// ISpPhraseAlt  **ppPhrases;
// int ulCount;
CSpDynamicString pwszAlternate;
event.RecoResult()->ISpPhrase;

    // get the top MY_MAX_ALTERNATES alternates to the entire recognized phrase
    int hr = event.RecoResult()->GetAlternates(0,
                                     SPPR_ALL_ELEMENTS , 
                                     MY_MAX_ALTERNATES,
                                     pcpPhrase,
                                     &ulCount);
    // Check hr

    // check each alternate in order of highest likelihood
    for (int i = 0; i < ulCount; i++) {
         
		
		hr = ppPhrases[i]->GetText(SP_GETWHOLEPHRASE, SP_GETWHOLEPHRASE, TRUE, &pwszAlternate, NULL);


                    // Concatenate a space onto the end of the recognized word
                    dstrText.Append(L" ");

                    ::SendDlgItemMessage( m_hDlg, IDC_EDIT_DICT, EM_REPLACESEL, TRUE, (LPARAM) W2T(pwszAlternate) );

         // Check hr

         // ... check if this alternate is more appropriate ...

         // if it is more appropriate, then commit the alternate
    //     if (fMoreAppropriate) {
      //       hr = pcpPhraseAlt[i]->Commit();
             // Check hr
        // }

         // free the alternate text
        // if (pwszAlternate) ::CoTaskMemFree(pwszAlternate);
         
    }

#endif

                    // Concatenate a space onto the end of the recognized word
                //    dstrText.Append(L" ");

               //     ::SendDlgItemMessage( m_hDlg, IDC_EDIT_DICT, EM_REPLACESEL, TRUE, (LPARAM) W2T(dstrText) );

                }
                break;

        }
    }
} 











LRESULT CALLBACK CTTSApp::DlgProcMain(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    CTTSApp* pThis = (CTTSApp *)::GetWindowLong( hwnd, GWL_USERDATA );

    // Call the appropriate function to handle the messages
    switch(uMsg)                                                    
    {
#if 0
	case WM_HELP:
		if(wParam==VK_F1) {
//			if (!CreateGLWindow("KnowledgeNetica demonstration",800,600,16,FALSE)) {break;}								// Quit If Window Was Not Created
//			DrawGLScene();									// Here's Where We Do All The Drawing
//			SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
//			openglon=1;
			}
		else {
//			KillGLWindow();						// Kill Our Current Window
//			openglon=0;
			}

		break;
#endif


       case WM_TIMER:
		   if(openglon) {
		   DrawGLScene();									// Here's Where We Do All The Drawing
			SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
		   }

		   if(incall) {
			   callcentertimer();
			}

		   return TRUE;


      case WM_RECOEVENT:
            // All recognition events send this message, because that is how we
            // specified we should be notified
            pThis->RecoEvent();
			
			

            return TRUE;

        case WM_INITDIALOG:
            ::SetWindowLong( hwnd, GWL_USERDATA, lParam );

// Set two timers. 
 
SetTimer(hwnd,             // handle to main window 
    IDT_TIMER1,            // timer identifier 
    10,                 // 10-second interval 
    (TIMERPROC) NULL);     // no timer callback 




            pThis = (CTTSApp *)lParam;


			if(LOCALONLY) {
			 SendMessage((HWND) GetDlgItem(hwnd,IDC_RADIO1),(UINT) BM_SETCHECK,(WPARAM) BST_CHECKED, (LPARAM) 0 );

				}
			else {
				SendMessage((HWND) GetDlgItem(hwnd,IDC_RADIO1),(UINT) BM_SETCHECK,(WPARAM) BST_UNCHECKED, (LPARAM) 0 );
				}






            return pThis->OnInitDialog( hwnd );

        case WM_TTSAPPCUSTOMEVENT:
            pThis->MainHandleSynthEvent();
            return TRUE;

        case WM_HSCROLL:
            pThis->HandleScroll( (HWND) lParam );
            return TRUE;

        case WM_COMMAND:
            if( pThis )
            {
                pThis->MainHandleCommand( (int)(LOWORD(wParam)), (HWND)lParam, 
                                 (UINT)HIWORD(wParam) );
            }
            return TRUE;

		case WM_CLOSE:
			KillTimer(hwnd,IDT_TIMER1);

            pThis->MainHandleClose();
			return TRUE;
    }

    return FALSE;
}

/////////////////////////////////////////////////////////////////
HRESULT CTTSApp::InitSapi()
/////////////////////////////////////////////////////////////////
{
    HRESULT                 hr;
    
    hr = m_cpVoice.CoCreateInstance( CLSID_SpVoice );

    return hr;
}

/////////////////////////////////////////////////////////////////
HIMAGELIST CTTSApp::InitImageList()
/////////////////////////////////////////////////////////////////
{
    HIMAGELIST hListBmp;
    HBITMAP hBmp;

    hListBmp = ImageList_Create( CHARACTER_WIDTH, CHARACTER_HEIGHT, ILC_COLOR32 | ILC_MASK, 1, 0 );
    if (hListBmp)
    {
        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICFULL ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH2 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH3 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH4 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH5 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH6 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH7 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH8 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH9 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH10 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH11 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH12 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICMOUTH13 ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICEYESNAR ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        hBmp = LoadBitmap( m_hInst, MAKEINTRESOURCE( IDB_MICEYESCLO ) );
        ImageList_AddMasked( hListBmp, hBmp, 0xff00ff );
        DeleteObject( hBmp );

        ImageList_SetOverlayImage( hListBmp, 1, 1 );
        ImageList_SetOverlayImage( hListBmp, 2, 2 );
        ImageList_SetOverlayImage( hListBmp, 3, 3 );
        ImageList_SetOverlayImage( hListBmp, 4, 4 );
        ImageList_SetOverlayImage( hListBmp, 5, 5 );
        ImageList_SetOverlayImage( hListBmp, 6, 6 );
        ImageList_SetOverlayImage( hListBmp, 7, 7 );
        ImageList_SetOverlayImage( hListBmp, 8, 8 );
        ImageList_SetOverlayImage( hListBmp, 9, 9 );
        ImageList_SetOverlayImage( hListBmp, 10, 10 );
        ImageList_SetOverlayImage( hListBmp, 11, 11 );
        ImageList_SetOverlayImage( hListBmp, 12, 12 );
        ImageList_SetOverlayImage( hListBmp, 13, 13 );
        ImageList_SetOverlayImage( hListBmp, 14, WEYESNAR );
        ImageList_SetOverlayImage( hListBmp, 15, WEYESCLO );
    }
    return hListBmp;
}

/////////////////////////////////////////////////////////////////
BOOL CTTSApp::OnInitDialog( HWND hWnd )
/////////////////////////////////////////////////////////////////
{
    HRESULT                         hr          = S_OK;
        
    // Store this as the "Main Dialog"
    m_hWnd  = hWnd;

    // Add some default text to the main edit control
    SetDlgItemText( hWnd, IDE_EDITBOX, _T("K-Netica response.") );
	
	SetDlgItemText( m_hWnd, IDC_EDIT1, _T("what is the population of Afghanistan") );
	SetDlgItemText( m_hWnd, IDC_EDIT2, _T("aardvark") );

    // Set the event mask in the rich edit control so that it notifies us when text is
    // changed in the control
    SendMessage( GetDlgItem( hWnd, IDE_EDITBOX ), EM_SETEVENTMASK, 0, ENM_CHANGE );

    // Initialize the Output Format combo box
    for( int i=0; i<NUM_OUTPUTFORMATS; i++ )
    {
        SendDlgItemMessage( hWnd, IDC_COMBO_OUTPUT, CB_ADDSTRING, 0,
                    (LPARAM)g_aszOutputFormat[i] );

        SendDlgItemMessage( hWnd, IDC_COMBO_OUTPUT, CB_SETITEMDATA, i, 
                    (LPARAM)g_aOutputFormat[i] );
    }

    if ( !m_cpVoice )
    {
        hr = E_FAIL;
    }

    // Set the default output format as the current selection.
    if( SUCCEEDED( hr ) )
    {
        CComPtr<ISpStreamFormat> cpStream;
        HRESULT hrOutputStream = m_cpVoice->GetOutputStream(&cpStream);

        if (hrOutputStream == S_OK)
        {
            CSpStreamFormat Fmt;
            hr = Fmt.AssignFormat(cpStream);
            if (SUCCEEDED(hr))
            {
                SPSTREAMFORMAT eFmt = Fmt.ComputeFormatEnum();
                for( i=0; i<NUM_OUTPUTFORMATS; i++ )
                {
                    if( g_aOutputFormat[i] == eFmt )
                    {
                        m_DefaultFormatIndex = i;
                        SendDlgItemMessage( hWnd, IDC_COMBO_OUTPUT, CB_SETCURSEL, m_DefaultFormatIndex, 0 );
                    }
                }
            }
        }
        else
        {
            SendDlgItemMessage( hWnd, IDC_COMBO_OUTPUT, CB_SETCURSEL, 0, 0 );
        }
    }

    // Use the SAPI5 helper function in sphelper.h to initialize the Voice combo box.
    if ( SUCCEEDED( hr ) )
    {
        hr = SpInitTokenComboBox( GetDlgItem( hWnd, IDC_COMBO_VOICES ), SPCAT_VOICES );
    }
    
	if ( SUCCEEDED( hr ) )
	{
		SpCreateDefaultObjectFromCategoryId( SPCAT_AUDIOOUT, &m_cpOutAudio );
	}

    // Set default voice data 
    VoiceChange();

    // Set Range for Skip Edit Box...
    SendDlgItemMessage( hWnd, IDC_SKIP_SPIN, UDM_SETRANGE, TRUE, MAKELONG( 50, -50 ) );

	// Set the notification message for the voice
	if ( SUCCEEDED( hr ) )
	{
		m_cpVoice->SetNotifyWindowMessage( hWnd, WM_TTSAPPCUSTOMEVENT, 0, 0 );
	}

    // We're interested in all TTS events
    if( SUCCEEDED( hr ) )
    {
        hr = m_cpVoice->SetInterest( SPFEI_ALL_TTS_EVENTS, SPFEI_ALL_TTS_EVENTS );
    }

    // Get default rate and volume
    if( SUCCEEDED( hr ) )
    {
        hr = m_cpVoice->GetRate( &m_DefaultRate );
        // initialize sliders and edit boxes with default rate
		if ( SUCCEEDED( hr ) )
		{
        	SendDlgItemMessage( hWnd, IDC_RATE_SLIDER, TBM_SETRANGE, TRUE, MAKELONG( SPMIN_RATE, SPMAX_RATE ) );
        	SendDlgItemMessage( hWnd, IDC_RATE_SLIDER, TBM_SETPOS, TRUE, m_DefaultRate );
        	SendDlgItemMessage( hWnd, IDC_RATE_SLIDER, TBM_SETPAGESIZE, TRUE, 5 );
		}
    }

    if( SUCCEEDED( hr ) )
    {
        hr = m_cpVoice->GetVolume( &m_DefaultVolume );
        // initialize sliders and edit boxes with default volume
		if ( SUCCEEDED( hr ) )
		{
	        SendDlgItemMessage( hWnd, IDC_VOLUME_SLIDER, TBM_SETRANGE, TRUE, MAKELONG( SPMIN_VOLUME, SPMAX_VOLUME ) );
	        SendDlgItemMessage( hWnd, IDC_VOLUME_SLIDER, TBM_SETPOS, TRUE, m_DefaultVolume );
	        SendDlgItemMessage( hWnd, IDC_VOLUME_SLIDER, TBM_SETPAGESIZE, TRUE, 10 );
		}
    }

    // If any SAPI initialization failed, shut down!
    if( FAILED( hr ) )
    {
        MessageBox( NULL, _T("Error initializing speech objects. Shutting down."), _T("Error"), MB_OK );
        SendMessage( hWnd, WM_CLOSE, 0, 0 );
		return(FALSE);
		
    }
    else
    {
        //
        // Create the child windows to which we'll blit our result
        //
        HWND hCharWnd = GetDlgItem(hWnd, IDC_CHARACTER);
        RECT rc;

        GetClientRect(hCharWnd, &rc);
        rc.left = (rc.right - CHARACTER_WIDTH) / 2;
        rc.top = (rc.bottom - CHARACTER_HEIGHT) / 2;
        m_hChildWnd = CreateWindow( CHILD_CLASS, NULL, 
                            WS_CHILDWINDOW | WS_VISIBLE,
                            rc.left, rc.top,
                            rc.left + CHARACTER_WIDTH, rc.top + CHARACTER_HEIGHT,
                            hCharWnd, NULL, m_hInst, NULL );

        if ( !m_hChildWnd )
        {
            MessageBox( hWnd, _T("Error initializing speech objects. Shutting down."), _T("Error"), MB_OK );
            SendMessage( hWnd, WM_CLOSE, 0, 0 );
			return(FALSE);
			
        }
        else
        {
            // Load Mouth Bitmaps and use and ImageList since we'll blit the mouth
            // and eye positions over top of the full image
            g_hListBmp = InitImageList();
        }
    }










//bool CSimpleDict::InitDialog( HWND hDlg )
//{
    m_hDlg = hWnd;
    
    hr = S_OK;
    CComPtr<ISpRecognizer> cpRecoEngine;
    hr = cpRecoEngine.CoCreateInstance(CLSID_SpInprocRecognizer);

    if( SUCCEEDED( hr ) )
    {
        hr = cpRecoEngine->CreateRecoContext( &m_cpRecoCtxt );
    }


    // Set recognition notification for dictation
    if (SUCCEEDED(hr))
    {
        hr = m_cpRecoCtxt->SetNotifyWindowMessage( hWnd, WM_RECOEVENT, 0, 0 );
    }
    
    
    if (SUCCEEDED(hr))
    {
        // This specifies which of the recognition events are going to trigger notifications.
        // Here, all we are interested in is the beginning and ends of sounds, as well as
        // when the engine has recognized something
        const ULONGLONG ullInterest = SPFEI(SPEI_RECOGNITION);
        hr = m_cpRecoCtxt->SetInterest(ullInterest, ullInterest);
    }

    // create default audio object
    CComPtr<ISpAudio> cpAudio;
    hr = SpCreateDefaultObjectFromCategoryId(SPCAT_AUDIOIN, &cpAudio);

    // set the input for the engine
    hr = cpRecoEngine->SetInput(cpAudio, TRUE);
    hr = cpRecoEngine->SetRecoState( SPRST_ACTIVE );




    
    if (SUCCEEDED(hr))
    {
        // Specifies that the grammar we want is a dictation grammar.
        // Initializes the grammar (m_cpDictationGrammar)
        hr = m_cpRecoCtxt->CreateGrammar( GID_DICTATION, &m_cpDictationGrammar );
    }
    if  (SUCCEEDED(hr))
    {
        hr = m_cpDictationGrammar->LoadDictation(NULL, SPLO_STATIC);
    }
    if (SUCCEEDED(hr))
    {
        hr = m_cpDictationGrammar->SetDictationState( SPRS_ACTIVE );
    }
    if (FAILED(hr))
    {
        m_cpDictationGrammar.Release();
    }

//    return (hr == S_OK);





           HWND hwndList = GetDlgItem(m_hDlg, IDC_LIST3);

		   for(int a=0;a<numbersamples;a++) {

           SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) samplestrings[a]); 
		   }

















	//hr = m_cpVoice->Speak( L"  I am Ike, welcome to a new age of knowledge", SPF_ASYNC, 0 );

	return(TRUE);
	
}

/////////////////////////////////////////////////////////////////
void CTTSApp::Stop()
/////////////////////////////////////////////////////////////////
// 
// Resets global audio state to stopped, updates the Pause/Resume button
// and repaints the mouth in a closed position
//
{
    // Stop current rendering with a PURGEBEFORESPEAK...
    HRESULT hr = m_cpVoice->Speak( NULL, SPF_PURGEBEFORESPEAK, 0 );

    if( FAILED( hr ) )
    {
    	TTSAppStatusMessage( m_hWnd, _T("Stop error\r\n") );
    }

    SetWindowText( GetDlgItem( m_hWnd, IDB_PAUSE ), _T("Pause") );
    m_bPause = FALSE;
    m_bStop = TRUE;             
    // Mouth closed
    g_iBmp = 0;
    SendMessage( m_hChildWnd, WM_PAINT, 0, 0 );
    InvalidateRect( m_hChildWnd, NULL, FALSE );
}





/////////////////////////////////////////////////////////////////
void CTTSApp::MainHandleCommand( int id, HWND hWndControl, UINT codeNotify )
/////////////////////////////////////////////////////////////////
//
// Handle each of the WM_COMMAND messages that come in, and deal with
// them appropriately
//
{
    UINT                cNumChar = 0;
    HRESULT             hr = S_OK;
    TCHAR               szAFileName[NORM_SIZE] = _T("");
	static BOOL			bIsUnicode = FALSE;
    BOOL                bWavFileOpened = FALSE;
    int                 iFormat;
    CComPtr<ISpStream>  cpWavStream;
    CComPtr<ISpStreamFormat>    cpOldStream;
    HWND                hwndEdit;
	BOOL                bFileOpened = FALSE;
	char *sresult;

    // Get handle to the main edit box
    hwndEdit = GetDlgItem( m_hWnd, IDE_EDITBOX );

	char javastring[200]="java -cp c:\\googleapi\\googleapi;c:\\eclipse\\eclipse\\workspace\\Googly Googly ";
	char javadefinition[200]="java -cp c:\\googleapi\\googleapi;c:\\eclipse\\eclipse\\workspace\\KneticaTerm KneticaTerm ";
	char javasmart[200]="java -cp c:\\googleapi\\googleapi;c:\\eclipse\\eclipse\\workspace\\KneticaStart KneticaStart ";
	
	char javasearchterms[200]="what is the capital of russia";
	char javasearchterm[200]="aardvark";
	char javasearchsmart[200]="what is the atmosphere of jupiter";
	char *resultstring;
	int l,p,justdidaplus,hitcomma;

    switch(id)
    {
		case IDC_RADIO1:

			LOCALONLY =1-LOCALONLY;

		//LOCALONLY = SendMessage((HWND) GetDlgItem(m_hWnd,IDC_RADIO1),(UINT) BM_GETCHECK,(WPARAM) 0, (LPARAM) 0 );
			if(LOCALONLY) {
			 SendMessage((HWND) GetDlgItem(m_hWnd,IDC_RADIO1),(UINT) BM_SETCHECK,(WPARAM) BST_CHECKED, (LPARAM) 0 );

				}
			else {
				SendMessage((HWND) GetDlgItem(m_hWnd,IDC_RADIO1),(UINT) BM_SETCHECK,(WPARAM) BST_UNCHECKED, (LPARAM) 0 );
				}

 


	break;

	case IDC_BUTTON8:

		GetDlgItemText(m_hWnd,IDC_EDIT1,javasearchterm,200);

#if 1



		setdbentry("c:\\Northwind.mdb","Customers","City","Frankenstein","ContactName","Maria Anders");




#elif 1
		resultstring=getdrug("diovan");
		if(resultstring) {
				SetDlgItemText( m_hWnd, IDE_EDITBOX, resultstring );
				HandleSpeak();


			}


#elif 1
		if(quack3("c:\\kjvnew.mdb","BibleTable","TextData","TextData","abraham",javasearchterms)) {
	//	if(quack2("c:\\Almanac2.mdb","Birthdays","Month","Month","07","Day","07",javasearchterms)) {
				SetDlgItemText( m_hWnd, IDE_EDITBOX, javasearchterms );
				HandleSpeak();

			}
#elif 0
		if(quack2("c:\\Almanac2.mdb","Birthdays","Person1","Month","10","Day","21",javasearchterms)) {
	//	if(quack2("c:\\Almanac2.mdb","Birthdays","Month","Month","07","Day","07",javasearchterms)) {
				SetDlgItemText( m_hWnd, IDE_EDITBOX, javasearchterms );
				HandleSpeak();

			}
#elif 0


		if(checkforsongs(javasearchterm,javasearchterms)) {
				SetDlgItemText( m_hWnd, IDE_EDITBOX, javasearchterms );
				HandleSpeak();

			}
#else
		if(quack("c:\\Almanac2.mdb","Stone","MonthName","Month","07",javasearchterms)) {
				SetDlgItemText( m_hWnd, IDE_EDITBOX, javasearchterms );
				HandleSpeak();

			}
#endif

		break;
	case IDC_BUTTON1:
		strcpy(javasearchsmart,"/cgi-bin/findweather/getForecast?query=");
		p=strlen(javasearchsmart);

		GetDlgItemText(m_hWnd,IDC_EDIT1,javasearchterms,200);

#if 1
		hitcomma=0;
		l=strlen(javasearchterms)-2;
		for(int a=l;a>=0;a--) {
			if(isspace(javasearchterms[a])) {
				if(hitcomma) {
				javasearchterms[a]='+';
				}
				else {
				javasearchterms[a]=',';
				hitcomma=1;
				}
			}
		}

		
#endif

//http://mobile.wunderground.com/cgi-bin/findweather/getForecast?query=anoka%2Cmn

	resultstring=getweather(javasearchterms);
	//resultstring=getweather("anoka,mn");
		if(resultstring) {


#if 1
				SetDlgItemText( m_hWnd, IDE_EDITBOX, resultstring );
				HandleSpeak();


#else
			
			int mytestints[26]={-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};

			resultstring=parseloadedwebpage(mytestints);

			if(resultstring) {
				SetDlgItemText( m_hWnd, IDE_EDITBOX, resultstring );
				HandleSpeak();
				}
#endif

			}
   
		break;
	case IDC_BUTTON7:
		strcpy(javasearchsmart,"/?q=");
		p=strlen(javasearchsmart);

		GetDlgItemText(m_hWnd,IDC_EDIT1,javasearchterms,200);
		l=strlen(javasearchterms);
		justdidaplus=0;

		for(int a=0;a<l;a++) {
			if(isspace(javasearchterms[a])) {
				if(!justdidaplus) {
					javasearchsmart[p++]='+';
					justdidaplus=1;
					}
			}
			else {
				justdidaplus=0;
				javasearchsmart[p++]=javasearchterms[a];
			}
		}

		javasearchsmart[p]=0;

		resultstring=getwebfile("www.online-medical-dictionary.org",javasearchsmart);
		if(resultstring) {
			
			int mytestints[14]={-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,0,-1,-1};

			resultstring=parseloadedwebpage(mytestints);

			if(resultstring) {
				SetDlgItemText( m_hWnd, IDE_EDITBOX, resultstring );
				HandleSpeak();
				}
			}
   
		break;

	case IDC_BUTTON6:
#if 0

		strcpy(javasearchsmart,"/projects/infolab/startfarm.cgi?query=");
		p=strlen(javasearchsmart);

		GetDlgItemText(m_hWnd,IDC_EDIT1,javasearchterms,200);
		l=strlen(javasearchterms);
		for(int a=0;a<l;a++) {
			if(isspace(javasearchterms[a])) {
				if(!justdidaplus) {
					javasearchsmart[p++]='+';
					justdidaplus=1;
					}
			}
			else {
				justdidaplus=0;
				javasearchsmart[p++]=javasearchterms[a];
			}
		}

		javasearchsmart[p]=0;

		resultstring=getwebfile("www.ai.mit.edu",javasearchsmart);
		if(resultstring) {
			SetDlgItemText( m_hWnd, IDE_EDITBOX, resultstring );
			HandleSpeak();
			}
   
#else
			GetDlgItemText(m_hWnd,IDC_EDIT1,javasearchterms,200);
			resultstring=parse_sentence(strupr(javasearchterms));
			if(resultstring) {
				//SetDlgItemText(m_hWnd,IDC_EDIT1,resultstring);
				 SetDlgItemText( m_hWnd, IDE_EDITBOX, resultstring );
				HandleSpeak();
				}
#endif

		break;


	case IDC_BUTTON5:
		if(!openglon) {
	//		if (!CreateGLWindow("KnowledgeNetica demonstration",800,600,16,TRUE))
			if (!CreateGLWindow("KnowledgeNetica demonstration",640,480,16,TRUE))
				{
				break;								// Quit If Window Was Not Created
				}
	DrawGLScene();									// Here's Where We Do All The Drawing
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)


			openglon=1;
			}
		else {
			KillGLWindow();						// Kill Our Current Window
openglon=0;
			}
		
		break;





	case IDC_LIST3:

		switch (codeNotify) { 
                        case LBN_SELCHANGE: 
 
                           // Show the selected player's statistics. 
 
                           HWND hwndList = GetDlgItem(m_hWnd, IDC_LIST3); 
                           int nItem = SendMessage(hwndList, LB_GETCURSEL,0, 0);
        //  int i = SendMessage(hwndList, LB_GETITEMDATA,nItem, 0); 
 



						   SetDlgItemText(m_hWnd,IDC_EDIT1,samplestrings[nItem]);
						   break;
			}
    
		
		break;

	case IDC_BUTTON4:
		
		char searchstring[400];

		    strcpy(searchstring,javasmart);

			GetDlgItemText(m_hWnd,IDC_EDIT1,javasearchterms,200);

			strcat(searchstring,javasearchterms);

			if(strlen(javasearchterms)<4) break;

			WinExec(searchstring,SW_HIDE);
#if 1

			timeout=0;
			while(!FindWindow("ConsoleWindowClass",NULL)&&timeout<20) {
				Sleep(500);
				timeout++;
			}


			timeout=0;
			while(FindWindow("ConsoleWindowClass",NULL)&&timeout<20) {
				Sleep(500);
				timeout++;
			}

			hr = m_cpVoice->Speak( L"Search Complete", SPF_ASYNC, 0 );


			sresult=filetomemory("c:\\ksearch.txt");

	        if ( sresult ){
					
				int l=strlen(sresult);

				for(int a=0;a<l-6;a++) {
					if(!strncmp("Source",&sresult[a],6)) {
						sresult[a]=0;
						break;
						}
					}

				for(int a=0;a<l-7;a++) {
					if(!strncmp("Go back",&sresult[a],7)) {
						sresult[a]=0;
						break;
						}
					}
				for(int a=0;a<l-7;a++) {
					if(!strncmp("You asked me",&sresult[a],12)) {
						sresult[a]=0;
						break;
						}
					}
				


					    SetDlgItemText( m_hWnd, IDE_EDITBOX, &sresult[29] );
                        free( sresult );


                    }
 	

		//	hr = m_cpVoice->Speak( L"Press Speak for me to read the definition.", SPF_ASYNC, 0 );



			HandleSpeak();
#endif


			break;	
		case IDC_BUTTON3:
		
//		char searchstring[400];
		//	HANDLE filehandle;
		//	WIN32_FIND_DATA fd;

		    strcpy(searchstring,javadefinition);

			GetDlgItemText(m_hWnd,IDC_EDIT1,javasearchterm,200);



			strcat(searchstring,javasearchterm);
if(strlen(javasearchterm)<4) break;
			//SetDlgItemText( m_hWnd, IDC_EDIT1, _T(javasearchterms) );
		
		//	hr = m_cpVoice->Speak( L"Please wait while I find the definition from the internet.", SPF_ASYNC, 0 );

		//	hr = m_cpVoice->Speak( L"I've left the window open for you to see the progress", SPF_ASYNC, 0 );
			

		//	WinExec(searchstring,SW_SHOW);
			WinExec(searchstring,SW_HIDE);
#if 1
			timeout=0;
			while(!FindWindow("ConsoleWindowClass",NULL)&&timeout<40) {
				Sleep(500);
				timeout++;
			}


			timeout=0;
			while(FindWindow("ConsoleWindowClass",NULL)&&timeout<80) {
				Sleep(500);
				timeout++;

			}

			hr = m_cpVoice->Speak( L"Search Complete", SPF_ASYNC, 0 );


			sresult=filetomemory("c:\\TermOut.txt");

	        if ( sresult ){
					
				int l=strlen(sresult);

				for(int a=0;a<l-6;a++) {
					if(!strncmp("Synon",&sresult[a],5)) {
						sresult[a]=0;
						break;
						}
					}
				


					    SetDlgItemText( m_hWnd, IDE_EDITBOX, &sresult[20] );
                        free( sresult );


                    }
 	

		//	hr = m_cpVoice->Speak( L"Press Speak for me to read the definition.", SPF_ASYNC, 0 );



			HandleSpeak();
#endif


			break;	
	
	case IDC_BUTTON2:
		
//		char searchstring[400];
		//	HANDLE filehandle;
		//	WIN32_FIND_DATA fd;

		    strcpy(searchstring,javastring);

			GetDlgItemText(m_hWnd,IDC_EDIT1,javasearchterms,200);



			strcat(searchstring,javasearchterms);

			

			//SetDlgItemText( m_hWnd, IDC_EDIT1, _T(javasearchterms) );
		if(strlen(javasearchterms)<4) break;


			hr = m_cpVoice->Speak( L"Please wait while I extract salient pages from the internet.", SPF_ASYNC, 0 );

			hr = m_cpVoice->Speak( L"I've left the window open for you to see the progress", SPF_ASYNC, 0 );
			

			WinExec(searchstring,SW_SHOW);


			timeout=0;
			while(!FindWindow("ConsoleWindowClass",NULL)&&timeout<10) {
				Sleep(1000);
				timeout++;
			}


			timeout=0;
			while(FindWindow("ConsoleWindowClass",NULL)&&timeout<300) {
				Sleep(1000);
				timeout++;
			}

			hr = m_cpVoice->Speak( L"Search Complete", SPF_ASYNC, 0 );

			hr = m_cpVoice->Speak( L"I am now ranking the salience of the extracted text.", SPF_ASYNC, 0 );

			sresult=salience_search("C:\\Out.txt");
		
	        if ( sresult ){
					    SetDlgItemText( m_hWnd, IDE_EDITBOX, sresult );
                        free( sresult );
                    }
			hr = m_cpVoice->Speak( L"I have returned the most salient text I found.", SPF_ASYNC, 0 );
			hr = m_cpVoice->Speak( L"Press Speak for me to read it aloud.", SPF_ASYNC, 0 );


			break;
#if 0
	case IDC_BUTTON1:
		sresult=salience_search("C:\\Out.txt");

        if ( sresult ){
					    SetDlgItemText( m_hWnd, IDE_EDITBOX, sresult );
                        free( sresult );
                    }




			break;
#endif

		// About Box display
	    case IDC_ABOUT:
            ::DialogBox( m_hInst, (LPCTSTR)IDD_ABOUT, m_hWnd, (DLGPROC)About );
			break;
	    
		case IDC_BUTTON9:
            ::DialogBox( m_hInst, (LPCTSTR)IDD_DIALOG1, m_hWnd, (DLGPROC)KGDialogProc );
			break;
		case IDC_BUTTON10:
#if 1
			if(WUIsAwake()) {
				::DialogBox( m_hInst, (LPCTSTR)IDD_IMPWIZARD, m_hWnd, (DLGPROC)IMPDialogProc );
				}
			else {

			if(WUInitialize()) {
				::DialogBox( m_hInst, (LPCTSTR)IDD_IMPWIZARD, m_hWnd, (DLGPROC)IMPDialogProc );
				}
			}

#else

			if(IsKnowledgeLoaded()||1) {
				::DialogBox( m_hInst, (LPCTSTR)IDD_IMPWIZARD, m_hWnd, (DLGPROC)IMPDialogProc );
				}
			else {

			if(OpenAndLoadKnowledgeFiles(m_hWnd)) {
				::DialogBox( m_hInst, (LPCTSTR)IDD_IMPWIZARD, m_hWnd, (DLGPROC)IMPDialogProc );
				}
			}
#endif

			break;

        // Any change to voices is sent to VoiceChange() function
        case IDC_COMBO_VOICES:
            if( codeNotify == CBN_SELCHANGE )
            {
                hr = VoiceChange();
            }

            if( FAILED( hr ) )
            {
            	TTSAppStatusMessage( m_hWnd, _T("Error changing voices\r\n") );
            }

            break;

        // If user wants to speak a file pop the standard windows open file
        // dialog box and load the text into a global buffer (m_pszwFileText)
        // which will be used when the user hits speak.
        case IDB_OPEN:
            bFileOpened = CallOpenFileDialog( szAFileName,
                        _T("TXT (*.txt)\0*.txt\0XML (*.xml)\0*.xml\0All Files (*.*)\0*.*\0") );
            if( bFileOpened )
            {
				DWORD	dwFileSize = 0;
				
                USES_CONVERSION;
                wcscpy( m_szWFileName, T2W( szAFileName ) );
				ReadTheFile( szAFileName, &bIsUnicode, &m_pszwFileText );
				
				if( bIsUnicode )
				{
					// Unicode source
					UpdateEditCtlW( m_pszwFileText );
				}
				else
				{
					// MBCS source
#ifdef _UNICODE
					TCHAR *pszFileText = _tcsdup( m_pszwFileText );
#else
					// We're compiling ANSI, so we need to convert the string to MBCS
					// Note that a W2T may not be good here, since this string might 
					// be very big
                    TCHAR *pszFileText = NULL;
                    int iNeeded = ::WideCharToMultiByte( CP_ACP, 0, m_pszwFileText, -1, NULL, 0, NULL, NULL );
                    pszFileText = (TCHAR *) ::malloc( sizeof( TCHAR ) * ( iNeeded + 1 ) );
                    ::WideCharToMultiByte( CP_ACP, 0, m_pszwFileText, -1, pszFileText, iNeeded + 1, NULL, NULL );
#endif
                    if ( pszFileText )
                    {
					    SetDlgItemText( m_hWnd, IDE_EDITBOX, pszFileText );
                        free( pszFileText );
                    }

				}
            }
            else
            {
                wcscpy( m_szWFileName, L"" );
            }
            // Always SetFocus back to main edit window so text highlighting will work
            if(!openglon) SetFocus( hwndEdit );
            break;
        
        // Handle speak
        case IDB_SPEAK:
			HandleSpeak();
			break;

        case IDB_PAUSE:
            if( !m_bStop )
            {
                if( !m_bPause )
                {
                    SetWindowText( GetDlgItem( m_hWnd, IDB_PAUSE ), _T("Resume") );
                    // Pause the voice...
                    m_cpVoice->Pause();
                    m_bPause = TRUE;
                    TTSAppStatusMessage( m_hWnd, _T("Pause\r\n") );
                }
                else
                {
                    SetWindowText( GetDlgItem( m_hWnd, IDB_PAUSE ), _T("Pause") );
                    m_cpVoice->Resume();
                    m_bPause = FALSE;
                }
            }
            if(!openglon) SetFocus( hwndEdit );
            break;

        case IDB_STOP:
            TTSAppStatusMessage( m_hWnd, _T("Stop\r\n") );
            // Set the global audio state to stop
            Stop();
            if(!openglon) SetFocus( hwndEdit );
            break;

        case IDB_SKIP:
            {
                if(!openglon) SetFocus( hwndEdit );
                int fSuccess = false;
                int SkipNum = GetDlgItemInt( m_hWnd, IDC_SKIP_EDIT, &fSuccess, true );
                ULONG ulGarbage = 0;
                WCHAR szGarbage[] = L"Sentence";
                if ( fSuccess )
                {
                    TTSAppStatusMessage( m_hWnd, _T("Skip\r\n") );
                    hr = m_cpVoice->Skip( szGarbage, SkipNum, &ulGarbage );
                }
                else
                {
                    TTSAppStatusMessage( m_hWnd, _T("Skip failed\r\n") );
                }
                break;
            }

        case IDE_EDITBOX:
            // Set the global audio state to stop if user has changed contents of edit control
            if( codeNotify == EN_CHANGE )
            {
                Stop();
            }
            break;

        case IDB_SPEAKWAV:
            bWavFileOpened = CallOpenFileDialog( szAFileName,
                         _T("WAV (*.wav)\0*.wav\0All Files (*.*)\0*.*\0") );
            // Speak the wav file using SpeakStream
            if( bWavFileOpened )
            {
                CComPtr<ISpStream>       cpWavStream;
                WCHAR                       szwWavFileName[NORM_SIZE] = L"";;

                USES_CONVERSION;
                wcscpy( szwWavFileName, T2W( szAFileName ) );

                // User helper function found in sphelper.h to open the wav file and
                // get back an IStream pointer to pass to SpeakStream
                hr = SPBindToFile( szwWavFileName, SPFM_OPEN_READONLY, &cpWavStream );

                if( SUCCEEDED( hr ) )
                {
                    hr = m_cpVoice->SpeakStream( cpWavStream, SPF_ASYNC, NULL );
                }

                if( FAILED( hr ) )
                {
                    TTSAppStatusMessage( m_hWnd, _T("Speak error\r\n") );
                }
            }
            break;

        // Reset all values to defaults
        case IDB_RESET:
            TTSAppStatusMessage( m_hWnd, _T("Reset\r\n") );
            SendDlgItemMessage( m_hWnd, IDC_VOLUME_SLIDER, TBM_SETPOS, TRUE, m_DefaultVolume );
            SendDlgItemMessage( m_hWnd, IDC_RATE_SLIDER, TBM_SETPOS, TRUE, m_DefaultRate );
            SendDlgItemMessage( m_hWnd, IDC_SAVETOWAV, BM_SETCHECK, BST_UNCHECKED, 0 );
            SendDlgItemMessage( m_hWnd, IDC_EVENTS, BM_SETCHECK, BST_UNCHECKED, 0 );
            SetDlgItemText( m_hWnd, IDE_EDITBOX, _T("Enter text you wish spoken here.") );

            // reset output format
            SendDlgItemMessage( m_hWnd, IDC_COMBO_OUTPUT, CB_SETCURSEL, m_DefaultFormatIndex, 0 );
            SendMessage( m_hWnd, WM_COMMAND, MAKEWPARAM(IDC_COMBO_OUTPUT, CBN_SELCHANGE), 0 );

            // Change the volume and the rate to reflect what the UI says
            HandleScroll( ::GetDlgItem( m_hWnd, IDC_VOLUME_SLIDER ) );
            HandleScroll( ::GetDlgItem( m_hWnd, IDC_RATE_SLIDER ) );

            if(!openglon) SetFocus( hwndEdit );
            break;

        case IDC_COMBO_OUTPUT:
            if( codeNotify == CBN_SELCHANGE )
            {
                // Get the audio output format and set it's GUID
                iFormat  = SendDlgItemMessage( m_hWnd, IDC_COMBO_OUTPUT, CB_GETCURSEL, 0, 0 );
                SPSTREAMFORMAT eFmt = (SPSTREAMFORMAT)SendDlgItemMessage( m_hWnd, IDC_COMBO_OUTPUT,
                                                        CB_GETITEMDATA, iFormat, 0 );
                CSpStreamFormat Fmt;
                Fmt.AssignFormat(eFmt);
				if ( m_cpOutAudio )
				{
					hr = m_cpOutAudio->SetFormat( Fmt.FormatId(), Fmt.WaveFormatExPtr() );
				}
				else
				{
					hr = E_FAIL;
				}

                if( SUCCEEDED( hr ) )
                {
                    hr = m_cpVoice->SetOutput( m_cpOutAudio, FALSE );
                }

                if( FAILED( hr ) )
                {
                    TTSAppStatusMessage( m_hWnd, _T("Format rejected\r\n") );
                }

                EnableSpeakButtons( SUCCEEDED( hr ) );
            }
            break;

        case IDC_SAVETOWAV:
		{
			USES_CONVERSION;

			TCHAR szFileName[256];
			_tcscpy(szFileName, _T("\0"));

			BOOL bFileOpened = CallSaveFileDialog( szFileName,
                        _T("WAV (*.wav)\0*.wav\0All Files (*.*)\0*.*\0") );

			if (bFileOpened == FALSE) break;

			wcscpy( m_szWFileName, T2W(szFileName) );

			CSpStreamFormat OriginalFmt;
			hr = m_cpVoice->GetOutputStream( &cpOldStream );
			if (hr == S_OK)
			{
				hr = OriginalFmt.AssignFormat(cpOldStream);
			}
			else
			{
				hr = E_FAIL;
			}
			// User SAPI helper function in sphelper.h to create a wav file
			if (SUCCEEDED(hr))
			{
				hr = SPBindToFile( m_szWFileName, SPFM_CREATE_ALWAYS, &cpWavStream, &OriginalFmt.FormatId(), OriginalFmt.WaveFormatExPtr() ); 
			}
			if( SUCCEEDED( hr ) )
			{
				// Set the voice's output to the wav file instead of the speakers
				hr = m_cpVoice->SetOutput(cpWavStream, TRUE);
			}

            if ( SUCCEEDED( hr ) )
            {
			    // Do the Speak
			    HandleSpeak();
            }

			// Set output back to original stream
			// Wait until the speak is finished if saving to a wav file so that
			// the smart pointer cpWavStream doesn't get released before its
			// finished writing to the wav.
			m_cpVoice->WaitUntilDone( INFINITE );
			cpWavStream.Release();
			
            // Reset output
			m_cpVoice->SetOutput( cpOldStream, FALSE );
			
			TCHAR   szTitle[MAX_PATH];
            TCHAR   szConfString[MAX_PATH];
            if ( SUCCEEDED( hr ) )
            {
                LoadString( m_hInst, IDS_SAVE_NOTIFY, szConfString, MAX_PATH );
                LoadString( m_hInst, IDS_NOTIFY_TITLE, szTitle, MAX_PATH );
                MessageBox( m_hWnd, szConfString, szTitle, MB_OK | MB_ICONINFORMATION );
            }
            else
            {
                LoadString( m_hInst, IDS_SAVE_ERROR, szConfString, MAX_PATH );
                MessageBox( m_hWnd, szConfString, NULL, MB_ICONEXCLAMATION );
            }

			break;
		}
    }
    
    return;
}

/////////////////////////////////////////////////////////////////////////////////////////////
void CTTSApp::HandleSpeak()
/////////////////////////////////////////////////////////////////////////////////////////////
{
    HWND                hwndEdit;
	HRESULT             hr = S_OK;
    WCHAR               *szWTextString = NULL;

    // Get handle to the main edit box
    hwndEdit = GetDlgItem( m_hWnd, IDE_EDITBOX );

	TTSAppStatusMessage( m_hWnd, _T("Speak\r\n") );
	if(!openglon) SetFocus( hwndEdit );
	m_bStop = FALSE;
	
	// only get the string if we're not paused
	if( !m_bPause )
	{
        // Find the length of the string in the buffer
        GETTEXTLENGTHEX gtlx;
        gtlx.codepage = 1200;
        gtlx.flags = GTL_DEFAULT;
        LONG lTextLen = SendDlgItemMessage( m_hWnd, IDE_EDITBOX, EM_GETTEXTLENGTHEX, (WPARAM) &gtlx, 0 );
        szWTextString = new WCHAR[ lTextLen + 1 ];

		GETTEXTEX	GetText;
		
		GetText.cb			  = (lTextLen + 1) * sizeof( WCHAR );
		GetText.codepage	  = 1200;
		GetText.flags		  = GT_DEFAULT;
		GetText.lpDefaultChar = NULL;
		GetText.lpUsedDefChar = NULL;
		
		// Get the string in a unicode buffer
		SendDlgItemMessage( m_hWnd, IDE_EDITBOX, EM_GETTEXTEX, (WPARAM)&GetText, (LPARAM)szWTextString );

		// do we speak or interpret the XML
		hr = m_cpVoice->Speak( szWTextString, SPF_ASYNC | ((IsDlgButtonChecked( m_hWnd, IDC_SPEAKXML )) ? SPF_IS_XML : SPF_IS_NOT_XML), 0 );

        delete[] szWTextString;

		if( FAILED( hr ) )
		{
			TTSAppStatusMessage( m_hWnd, _T("Speak error\r\n") );
		}
	}
	m_bPause = FALSE;
	SetWindowText( GetDlgItem( m_hWnd, IDB_PAUSE ), _T("Pause") );
	if(!openglon) SetFocus( hwndEdit );
	// Set state to run
	hr = m_cpVoice->Resume();            

	if( FAILED( hr ) )
	{
		TTSAppStatusMessage( m_hWnd, _T("Speak error\r\n") );
	}
}

/////////////////////////////////////////////////////////////////
void CTTSApp::MainHandleSynthEvent()
/////////////////////////////////////////////////////////////////
//
// Handles the WM_TTSAPPCUSTOMEVENT application defined message and all
// of it's appropriate SAPI5 events.
//
{

    CSpEvent        event;  // helper class in sphelper.h for events that releases any 
                            // allocated memory in it's destructor - SAFER than SPEVENT
    SPVOICESTATUS   Stat;
    WPARAM          nStart;
    LPARAM          nEnd;
    int             i = 0;
    HRESULT 		hr = S_OK;

    while( event.GetFrom(m_cpVoice) == S_OK )
    {
        switch( event.eEventId )
        {
            case SPEI_START_INPUT_STREAM:
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    TTSAppStatusMessage( m_hWnd, _T("StartStream event\r\n") );
                }
                break; 

            case SPEI_END_INPUT_STREAM:
                // Set global boolean stop to TRUE when finished speaking
                m_bStop = TRUE; 
                // Highlight entire text
                nStart = 0;
                nEnd = SendDlgItemMessage( m_hWnd, IDE_EDITBOX, WM_GETTEXTLENGTH, 0, 0 );
                SendDlgItemMessage( m_hWnd, IDE_EDITBOX, EM_SETSEL, nStart, nEnd );
                // Mouth closed
                g_iBmp = 0;
                InvalidateRect( m_hChildWnd, NULL, FALSE );
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    TTSAppStatusMessage( m_hWnd, _T("EndStream event\r\n") );
                }
                break;     
                
            case SPEI_VOICE_CHANGE:
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    TTSAppStatusMessage( m_hWnd, _T("Voicechange event\r\n") );
                }
                break;

            case SPEI_TTS_BOOKMARK:
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    // Get the string associated with the bookmark
                    // and add the null terminator.
                    USES_CONVERSION;
                    TCHAR szBuff2[MAX_PATH] = _T("Bookmark event: ");

                    WCHAR *pwszEventString = new WCHAR[ wcslen( event.String() ) + 1];
                    if ( pwszEventString )
					{
                        wcscpy( pwszEventString, event.String() );
						_tcscat( szBuff2, W2T(pwszEventString) );
						free( pwszEventString );
					}

                    _tcscat( szBuff2, _T("\r\n") );
                    TTSAppStatusMessage( m_hWnd, szBuff2 );
                }
                break;

            case SPEI_WORD_BOUNDARY:
                hr = m_cpVoice->GetStatus( &Stat, NULL );
                if( FAILED( hr ) )
                {
                	TTSAppStatusMessage( m_hWnd, _T("Voice GetStatus error\r\n") );
                }

                // Highlight word
                nStart = (LPARAM)( Stat.ulInputWordPos / sizeof(char) );
                nEnd = nStart + Stat.ulInputWordLen;
                SendDlgItemMessage( m_hWnd, IDE_EDITBOX, EM_SETSEL, nStart, nEnd );
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    
                    TTSAppStatusMessage( m_hWnd, _T("Wordboundary event\r\n") );
                }
                break;

            case SPEI_PHONEME:
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    TTSAppStatusMessage( m_hWnd, _T("Phoneme event\r\n") );
                }
                break;

            case SPEI_VISEME:
                // Get the current mouth viseme position and map it to one of the 
                // 7 mouth bitmaps. 
                g_iBmp = g_aMapVisemeToImage[event.Viseme()]; // current viseme

                InvalidateRect( m_hChildWnd, NULL, FALSE );
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    TTSAppStatusMessage( m_hWnd, _T("Viseme event\r\n") );
                }
			//	hcountdest=rand()%32;
				
				hcountdest=g_iBmp*2+5;
			


                break;

            case SPEI_SENTENCE_BOUNDARY:
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    TTSAppStatusMessage( m_hWnd, _T("Sentence event\r\n") );
                }
                break;

            case SPEI_TTS_AUDIO_LEVEL:
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    USES_CONVERSION;
                    WCHAR wszBuff[MAX_PATH];
                    swprintf(wszBuff, L"Audio level: %d\r\n", (ULONG)event.wParam);
                    TTSAppStatusMessage( m_hWnd, W2T(wszBuff) );
                }
                break;

            case SPEI_TTS_PRIVATE:
                if( IsDlgButtonChecked( m_hWnd, IDC_EVENTS ) )
                {
                    TTSAppStatusMessage( m_hWnd, _T("Private engine event\r\n") );
                }
                break;

            default:
                TTSAppStatusMessage( m_hWnd, _T("Unknown message\r\n") );
                break;
        }
    }
}

/////////////////////////////////////////////////////////////////////////
void CTTSApp::HandleScroll( HWND hCtl )
/////////////////////////////////////////////////////////////////////////
{
    static long         hpos = 1;
    HWND                hVolume, hRate;
    HRESULT				hr = S_OK;

    // Get the current position of the slider
    hpos = SendMessage( hCtl, TBM_GETPOS, 0, 0 );

    // Get the Handle for the scroll bar so it can be associated with an edit box
    hVolume = GetDlgItem( m_hWnd, IDC_VOLUME_SLIDER );
    hRate = GetDlgItem( m_hWnd, IDC_RATE_SLIDER );
    
    if( hCtl == hVolume )
    {
        hr = m_cpVoice->SetVolume((USHORT)hpos);
    }
    else if( hCtl == hRate )
    {
		hr = m_cpVoice->SetRate(hpos);
    }
    
    if( FAILED( hr ) )
    {
    	TTSAppStatusMessage( m_hWnd, _T("Error setting volume / rate\r\n") );
    }

    return;
}

/////////////////////////////////////////////////////////////////
void CTTSApp::MainHandleClose()
/////////////////////////////////////////////////////////////////
{
    // Call helper functions from sphelper.h to destroy combo boxes
    // created with SpInitTokenComboBox
    SpDestroyTokenComboBox( GetDlgItem( m_hWnd, IDC_COMBO_VOICES ) );
    
    // Terminate the app
    PostQuitMessage(0);

    // Return success
    return;
}

/////////////////////////////////////////////////////////////////
HRESULT CTTSApp::VoiceChange()
/////////////////////////////////////////////////////////////////
//
// This function is called during initialization and whenever the 
// selection for the voice combo box changes. 
// It gets the token pointer associated with the voice.
// If the new voice is different from the one that's currently 
// selected, it first stops any synthesis that is going on and
// sets the new voice on the global voice object. 
//
{
    HRESULT         hr = S_OK;
    GUID*           pguidAudioFormat = NULL;
    int             iFormat = 0;

    // Get the token associated with the selected voice
    ISpObjectToken* pToken = SpGetCurSelComboBoxToken( GetDlgItem( m_hWnd, IDC_COMBO_VOICES ) );
    
    //Determine if it is the current voice
    CComPtr<ISpObjectToken> pOldToken;
    hr = m_cpVoice->GetVoice( &pOldToken );

    if (SUCCEEDED(hr))
    {
        if (pOldToken != pToken)
        {        
            // Stop speaking. This is not necesary, for the next call to work,
            // but just to show that we are changing voices.
            hr = m_cpVoice->Speak( NULL, SPF_PURGEBEFORESPEAK, 0);
            // And set the new voice on the global voice object
            if (SUCCEEDED (hr) )
            {
                hr = m_cpVoice->SetVoice( pToken );
            }
        }
    }

    EnableSpeakButtons( SUCCEEDED( hr ) );

    return hr;
}

/////////////////////////////////////////////////////////////////
BOOL CTTSApp::CallOpenFileDialog( TCHAR* szFileName, TCHAR* szFilter )  
/////////////////////////////////////////////////////////////////
//
// Display the open dialog box to retrieve the user-selected 
// .txt or .xml file for synthisizing
{
    OPENFILENAME    ofn;
    BOOL            bRetVal     = TRUE;
    LONG            lRetVal;
    HKEY            hkResult;
    TCHAR           szPath[256]       = _T("");
    DWORD           size = 256;

    // Open the last directory used by this app (stored in registry)
    lRetVal = RegCreateKeyEx( HKEY_CURRENT_USER, 
                        _T("SOFTWARE\\Microsoft\\Speech\\AppData\\TTSApp"), 0, NULL, 0,
                        KEY_ALL_ACCESS, NULL, &hkResult, NULL );

    if( lRetVal == ERROR_SUCCESS )
    {
        RegQueryValueEx( hkResult, _T("TTSFiles"), NULL, NULL, (PBYTE)szPath, &size );
    }

	size_t ofnsize = (BYTE*)&ofn.lpTemplateName + sizeof(ofn.lpTemplateName) - (BYTE*)&ofn;
    ZeroMemory( &ofn, ofnsize);


    ofn.lStructSize       = ofnsize;
    ofn.hwndOwner         = m_hWnd;    
    ofn.lpstrFilter       = szFilter;
    ofn.lpstrCustomFilter = NULL;    
    ofn.nFilterIndex      = 1;    
    ofn.lpstrInitialDir   = szPath;
    ofn.lpstrFile         = szFileName;  
    ofn.nMaxFile          = 256;
    ofn.lpstrTitle        = NULL;
    ofn.lpstrFileTitle    = NULL;    
    ofn.lpstrDefExt       = NULL;
    ofn.Flags             = OFN_FILEMUSTEXIST | OFN_READONLY | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;

    // Pop the dialog
    bRetVal = GetOpenFileName( &ofn );

    // Write the directory path you're in to the registry
    TCHAR   pathstr[256] = _T("");
    _tcscpy( pathstr, szFileName );

    int i=0; 
    while( pathstr[i] != NULL )
    {
        i++;
    }
    while( pathstr[i] != '\\' )
    {
        i --;
    }
    pathstr[i] = NULL;

    // Now write the string to the registry
    RegSetValueEx( hkResult, _T("TTSFiles"), NULL, REG_EXPAND_SZ, (PBYTE)pathstr, _tcslen(pathstr)+1 );

    RegCloseKey( hkResult );

    return bRetVal;
}

/////////////////////////////////////////////////////////////////
BOOL CTTSApp::CallSaveFileDialog( TCHAR* szFileName, TCHAR* szFilter )  
/////////////////////////////////////////////////////////////////
//
// Display the save dialog box to save the wav file
{
    OPENFILENAME    ofn;
    BOOL            bRetVal     = TRUE;
    LONG            lRetVal;
    HKEY            hkResult;
    TCHAR           szPath[256]       = _T("");
    DWORD           size = 256;

    // Open the last directory used by this app (stored in registry)
    lRetVal = RegCreateKeyEx( HKEY_CLASSES_ROOT, _T("PathTTSDataFiles"), 0, NULL, 0,
                        KEY_ALL_ACCESS, NULL, &hkResult, NULL );

    if( lRetVal == ERROR_SUCCESS )
    {
        RegQueryValueEx( hkResult, _T("TTSFiles"), NULL, NULL, (PBYTE)szPath, &size );
    
        RegCloseKey( hkResult );
    }

	size_t ofnsize = (BYTE*)&ofn.lpTemplateName + sizeof(ofn.lpTemplateName) - (BYTE*)&ofn;
    ZeroMemory( &ofn, ofnsize);

    ofn.lStructSize       = ofnsize;
    ofn.hwndOwner         = m_hWnd;    
    ofn.lpstrFilter       = szFilter;
    ofn.lpstrCustomFilter = NULL;    
    ofn.nFilterIndex      = 1;    
    ofn.lpstrInitialDir   = szPath;
    ofn.lpstrFile         = szFileName;  
    ofn.nMaxFile          = 256;
    ofn.lpstrTitle        = NULL;
    ofn.lpstrFileTitle    = NULL;    
    ofn.lpstrDefExt       = _T("wav");
    ofn.Flags             = OFN_OVERWRITEPROMPT;

    // Pop the dialog
    bRetVal = GetSaveFileName( &ofn );

	if ( ofn.Flags & OFN_EXTENSIONDIFFERENT )
	{
		_tcscat( szFileName, _T(".wav") );
	}

    // Write the directory path you're in to the registry
    TCHAR   pathstr[256] = _T("");
    _tcscpy( pathstr, szFileName );

    int i=0; 
    while( pathstr[i] != NULL )
    {
        i++;
    }
    while( pathstr[i] != '\\' )
    {
        i --;
    }
    pathstr[i] = NULL;

    // Now write the string to the registry
    lRetVal = RegCreateKeyEx( HKEY_CLASSES_ROOT, _T("PathTTSDataFiles"), 0, NULL, 0,
                        KEY_ALL_ACCESS, NULL, &hkResult, NULL );

    if( lRetVal == ERROR_SUCCESS )
    {
        RegSetValueEx( hkResult, _T("TTSFiles"), NULL, REG_EXPAND_SZ, (PBYTE)pathstr, _tcslen(pathstr)+1 );
    
        RegCloseKey( hkResult );
    }

    return bRetVal;
}

/////////////////////////////////////////////////////
HRESULT CTTSApp::ReadTheFile( TCHAR* szFileName, BOOL* bIsUnicode, WCHAR** ppszwBuff )
/////////////////////////////////////////////////////
//
// This file opens and reads the contents of a file. It
// returns a pointer to the string.
// Warning, this function allocates memory for the string on 
// the heap so the caller must free it with 'delete'.
//
{
    // Open up the file and copy it's contents into a buffer to return
	HRESULT		hr = 0;
    HANDLE		hFile;
	DWORD		dwSize = 0;
	DWORD		dwBytesRead = 0;
	    
    // First delete any memory previously allocated by this function
    if( m_pszwFileText )
    {
        delete m_pszwFileText;
    }

    hFile = CreateFile( szFileName, GENERIC_READ,
        FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_READONLY, NULL );
    if( hFile == INVALID_HANDLE_VALUE )
    {
		*ppszwBuff = NULL;
		hr = E_FAIL;
    }

	if( SUCCEEDED( hr ) )
	{
		dwSize = GetFileSize( hFile, NULL );
		if( dwSize == 0xffffffff )
		{
			*ppszwBuff = NULL;
			hr = E_FAIL;        
		}
	}
 
	if( SUCCEEDED( hr ) )
	{
		// Read the file contents into a wide buffer and then determine
		// if it's a unicode or ascii file
		WCHAR	Signature = 0;

		ReadFile( hFile, &Signature, 2, &dwBytesRead, NULL );
			
		// Check to see if its a unicode file by looking at the signature of the first character.
		if( 0xFEFF == Signature )
		{
			*ppszwBuff = new WCHAR [dwSize/2];

			*bIsUnicode = TRUE;
			ReadFile( hFile, *ppszwBuff, dwSize-2, &dwBytesRead, NULL );
			(*ppszwBuff)[dwSize/2-1] = NULL;

			CloseHandle( hFile );
		}			
		else  // MBCS source
		{
			char*	pszABuff = new char [dwSize+1];
			*ppszwBuff = new WCHAR [dwSize+1];

			*bIsUnicode = FALSE;
			SetFilePointer( hFile, NULL, NULL, FILE_BEGIN );
			ReadFile( hFile, pszABuff, dwSize, &dwBytesRead, NULL );
			pszABuff[dwSize] = NULL;
            ::MultiByteToWideChar( CP_ACP, 0, pszABuff, -1, *ppszwBuff, dwSize + 1 );

			delete( pszABuff );
			CloseHandle( hFile );
		}
	}

	return hr;
}

/////////////////////////////////////////////////////////////////////////
void CTTSApp::UpdateEditCtlW( WCHAR* pszwText )
/////////////////////////////////////////////////////////////////////////
{
	CComPtr<IRichEditOle>		cpRichEdit;
	CComPtr<ITextDocument>		cpTextDocument;
	ITextServices*				pTextServices=NULL;
	HRESULT						hr = S_OK;

	// Use rich edit control interface pointers to update text
	if( SendDlgItemMessage( m_hWnd, IDE_EDITBOX, EM_GETOLEINTERFACE, 0, (LPARAM)(LPVOID FAR *)&cpRichEdit ) )
	{
		hr = cpRichEdit.QueryInterface( &cpTextDocument );
		
		if( SUCCEEDED( hr ) )
		{
			hr = cpTextDocument->QueryInterface( IID_ITextServices, (void**)&pTextServices );
		}

		if (SUCCEEDED(hr))
		{
			BSTR bstr = SysAllocString( pszwText );
            
			hr = pTextServices->TxSetText( bstr );

			pTextServices->Release();

			SysFreeString( bstr );
		}
	}

	// Add text the old fashon way by converting it to ansi. Note information
	// loss will occur because of the WC2MB conversion.
	if( !cpRichEdit || FAILED( hr ) )  
	{
        USES_CONVERSION;
        TCHAR *pszFileText = _tcsdup( W2T(pszwText) );
		SetDlgItemText( m_hWnd, IDE_EDITBOX, pszFileText );
        free( pszFileText );
	}
}

/////////////////////////////////////////////////////////////////////////
void CTTSApp::EnableSpeakButtons( BOOL fEnable )
/////////////////////////////////////////////////////////////////////////
{
    ::EnableWindow( ::GetDlgItem( m_hWnd, IDB_SPEAK ), fEnable );
    ::EnableWindow( ::GetDlgItem( m_hWnd, IDB_PAUSE ), fEnable );
    ::EnableWindow( ::GetDlgItem( m_hWnd, IDB_STOP ), fEnable );
    ::EnableWindow( ::GetDlgItem( m_hWnd, IDB_SKIP ), fEnable );
    ::EnableWindow( ::GetDlgItem( m_hWnd, IDB_SPEAKWAV ), fEnable );
    ::EnableWindow( ::GetDlgItem( m_hWnd, IDC_SAVETOWAV ), fEnable );
}

/////////////////////////////////////////////////////
inline void TTSAppStatusMessage( HWND hWnd, TCHAR* szMessage )
/////////////////////////////////////////////////////
//
// This function prints debugging messages to the debug edit control
//
{
    static TCHAR            szDebugText[MAX_SIZE]=_T("");
    static int              i = 0;
    
    // Clear out the buffer after 100 lines of text have been written
    // to the debug window since it can only hold 4096 characters.
    if( i == 100 )
    {
        _tcscpy( szDebugText, _T("") );
        i = 0;
    }
    // Attach the new message to the ongoing list of messages
    _tcscat( szDebugText, szMessage );
    SetDlgItemText( hWnd, IDC_DEBUG, szDebugText );

    SendDlgItemMessage( hWnd, IDC_DEBUG, EM_LINESCROLL, 0, i );

    i++;

    return;
}

/*****************************************************************************************
* About() *
*---------*
*   Description:
*       Message handler for the "About" box.
******************************************************************************************/
LRESULT CALLBACK About( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
    USES_CONVERSION;

    switch( message )
    {
        case WM_COMMAND:
        {
            WORD wId    = LOWORD(wParam); 
            WORD wEvent = HIWORD(wParam); 
            
            switch( wId )
            {
                case IDOK:
                case IDCANCEL:
                    EndDialog( hDlg, LOWORD(wParam) );
                    return TRUE;
            }
        }
    }
    return FALSE;
}   /* About */
