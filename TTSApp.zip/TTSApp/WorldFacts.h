
char * parse_sentence(char *sentence);
int containsstring(char *sentence,char *string);
int containsword(char *sentence,char *string);



