#define MOLECULEFILENAME "c:\\roger\\moleculesexp.txt"

int WUInitialize();
int WUIsAwake();
