#include "globals.h"
#include "stdio.h"
#include "string.h"
#include "word.h"

struct wordobject *newwordobject(){
	struct wordobject *tempwo;

	tempwo=new wordobject;

	if(tempwo) {
		tempwo->flag=0;
		tempwo->weight=0;
		tempwo->lexref=0;
		tempwo->nextwordobject=0;

		}

	return(tempwo);


	}

