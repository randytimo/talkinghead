#include "globals.h"
#include "ttsapp.h"
#include "stdio.h"
#include "string.h"
#include "molecule.h"

#include "kgconverter.h"
#include "worldfacts.h"

#include "math.h"
#include "lesson14.h"
#include "Recognizer.h"
#include "stmmanager.h"
#include "lexical.h"


#include <commctrl.h>
#include <gl\glu.h>			// Header File For The GLu32 Library


extern char *info;

char *columnheaders[6]={"<word>","<attribute>","<associate>","<context>","<adjective>","<Weight>"};

LVCOLUMN LvCol;
HWND hList=NULL;
HWND ghDlg=NULL;

LVITEM LvItem;

HWND hEdit;

GLUquadric *quadratic;
float zdepth=-60.0;


void gl_draw_atom(double x, double y, double z, double r){
	glLoadIdentity();									// Reset The Current Modelview Matrix
	glTranslatef(x,y,z);						// Move One Unit Into The Screen
	gluSphere(quadratic,r,32,32);
}



//char *uniquecontexts[64];




int visualizemoleculestate(HWND hDlg) {
	char string[80];
	struct lexicalobject *atomlexobja;
//	struct lexicalobject *atomlexobjb;

	int c2use[256];
	int y2use[256];
	int q2use[256];
	int r2use[256];

	//double r,sinx,cosx,molinc,mangle;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer

	GetDlgItemText(hDlg,IDC_EDIT1,string,128);

	glLoadIdentity();									// Reset The Current Modelview Matrix
	glTranslatef(0.0f,0.0f,zdepth);						// Move One Unit Into The Screen
	glColor4f(1.0f,1.0f,1.0f,0.8f);
  	glPrint(string);						// Print GL Text To The Screen

	struct lexicalobject *lexobj=GetLexicalObject(string);
	


	if( lexobj ) {
		int nummol=lexobj->moleculecount;
		int ctotal=0;
		int rtotal=0;
		int qtotal=0;
		for(int a=0;a<nummol;a++) {
			c2use[a]=a;			r2use[a]=a;			q2use[a]=a;			y2use[a]=a;
			struct moleculeobject *molobj=GetMoleculeObjectAt(lexobj->molecules[a]);
			for(int b=a-1;b>=0;b--) {
				struct moleculeobject *molobjb=GetMoleculeObjectAt(lexobj->molecules[b]);
				if(molobjb->C==molobj->C&&molobjb->R==molobj->R&&molobjb->Q==molobj->Q) {c2use[a]=b; r2use[a]=b; q2use[a]=b;}
				else if(molobjb->C==molobj->C&&molobjb->R==molobj->R) {c2use[a]=b; r2use[a]=b;}
				else if(molobjb->C==molobj->C) {c2use[a]=b;}
				}
			if(c2use[a]==a) {
				ctotal++;
				}
			if(r2use[a]==a) {
				rtotal++;
				}
			if(q2use[a]==a) {
				qtotal++;
				}
		}
		


		int ctotalleft=ctotal/2;
		int ctotalright=ctotal-ctotalleft;
		int cunique=0;
		int rtotalleft=0;
		int rtotalright=0;

		for(int a=0;a<nummol;a++) {
			if(c2use[a]==a) cunique++;

			if(cunique<=ctotalleft) {
				rtotalleft++;
			}
			else {
				rtotalright++;
				}
		}


		double yheight=6.0;
		float ypos=-yheight*(double)ctotalleft/2.0;
		float xpos=-yheight*4.0;
		float ypos2=-yheight*(double)ctotalright/2.0;
		float xpos2=-xpos;
		float cypos=-yheight*(double)ctotalleft/2.0;
		float cxpos=-yheight*2.0;
		float cypos2=-yheight*(double)ctotalright/2.0;
		float cxpos2=-cxpos;



	//	xpos =0.0; ypos=0.0;
		cunique=0;
		for(int a=0;a<nummol;a++) {
			if(c2use[a]==a) {
				cunique++;


			if(cunique<=ctotalleft) {
	
					struct moleculeobject *molobj=GetMoleculeObjectAt(lexobj->molecules[a]);
					atomlexobja=GetLexicalObjectAt(molobj->C);

					glLoadIdentity();									// Reset The Current Modelview Matrix
					glTranslatef(cxpos,cypos,zdepth);						// Move One Unit Into The Screen
					glColor4f(1.0f,1.0f,1.0f,0.8f);
  					glPrint(atomlexobja->bytes);						// Print GL Text To The Screen
					glColor4f(0.0f,1.0f,0.0f,0.4f);
					gl_draw_atom(cxpos,cypos,zdepth,2.0);

					cypos+=yheight;
			}
			else {
					struct moleculeobject *molobj=GetMoleculeObjectAt(lexobj->molecules[a]);
					atomlexobja=GetLexicalObjectAt(molobj->C);

					glLoadIdentity();									// Reset The Current Modelview Matrix
					glTranslatef(cxpos2,cypos2,zdepth);						// Move One Unit Into The Screen
					glColor4f(1.0f,1.0f,1.0f,0.8f);
  					glPrint(atomlexobja->bytes);						// Print GL Text To The Screen

					glColor4f(0.0f,1.0f,0.0f,0.4f);
					gl_draw_atom(cxpos2,cypos2,zdepth,2.0);
	
					cypos2+=yheight;




				}





				}

				if(cunique<=ctotalleft) {
	
					struct moleculeobject *molobj=GetMoleculeObjectAt(lexobj->molecules[a]);
					atomlexobja=GetLexicalObjectAt(molobj->Y);

					glLoadIdentity();									// Reset The Current Modelview Matrix
					glTranslatef(xpos,ypos,zdepth);						// Move One Unit Into The Screen
					glColor4f(0.0f,1.0f,1.0f,0.8f);
  					glPrint(atomlexobja->bytes);						// Print GL Text To The Screen


					glColor4f(1.0f,0.0f,0.0f,0.4f);
					gl_draw_atom(xpos,ypos,zdepth,2.0);
										ypos+=yheight;


					}
				else  {
	
					struct moleculeobject *molobj=GetMoleculeObjectAt(lexobj->molecules[a]);
					atomlexobja=GetLexicalObjectAt(molobj->Y);

					glLoadIdentity();									// Reset The Current Modelview Matrix
					glTranslatef(xpos2,ypos2,zdepth);						// Move One Unit Into The Screen
					glColor4f(0.0f,1.0f,1.0f,0.8f);
  					glPrint(atomlexobja->bytes);						// Print GL Text To The Screen
	
					glColor4f(1.0f,0.0f,0.0f,0.4f);
					gl_draw_atom(xpos2,ypos2,zdepth,2.0);
									ypos2+=yheight;


					}
				
			}





		}

	glColor4f(1.0f,0.0f,0.0f,0.4f);
	gl_draw_atom(0.0,0.0,zdepth,1.0);
	glColor4f(0.0f,1.0f,0.0f,0.4f);
	gl_draw_atom(0.0,0.0,zdepth,2.0);
	glColor4f(0.0f,0.0f,1.0f,0.4f);
	gl_draw_atom(0.0,0.0,zdepth,3.0);


	SwapBuffers(hDC);					// Swap Buffers (Double Buffering)

	return(1);
	}

LRESULT CALLBACK IMPDialogProc( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
    USES_CONVERSION;
//	BOOL				bFileOpened;
//	HWND hwndList;
	char string[512];
	char string2[128];
	int u,n;


	int xlextype=0;
	struct lexicalobject *atomlexobj;
	struct moleculeloadstruct mlobj;


    switch( message )
    {
	case WM_NOTIFY: // the message that is being sent always
	{
	switch(LOWORD(wParam)) // hit control
	{
		case IDC_LIST1:      // did we hit our ListView contorl?

			if(((LPNMHDR)lParam)->code == NM_CLICK) 
			{

				LVHITTESTINFO pInfo;
			//	hEdit=ListView_GetEditControl(hList);

			int iSelect=SendMessage(hList,LVM_GETNEXTITEM,
					-1,LVNI_FOCUSED); // return item selected

			if(iSelect>=0) // no items
			{
				DWORD dwpos = GetMessagePos();
				pInfo.pt.x = GET_X_LPARAM(dwpos);
				pInfo.pt.y = GET_Y_LPARAM(dwpos);
				::MapWindowPoints(HWND_DESKTOP, ((LPNMHDR)lParam)->hwndFrom, &pInfo.pt, 1);
				ListView_SubItemHitTest(((LPNMHDR)lParam)->hwndFrom, &pInfo);
 
				int col=pInfo.iSubItem;

				memset(&LvItem,0,sizeof(LvItem));
				LvItem.mask=LVIF_TEXT;
				LvItem.iSubItem=col;
				LvItem.pszText=string;
				LvItem.cchTextMax=128;
				LvItem.iItem=iSelect;

				SendMessage(hList,LVM_GETITEMTEXT,iSelect, (LPARAM)&LvItem); 
				SetDlgItemText( hDlg, IDC_EDIT1, string );
				}




			}
			else if(((LPNMHDR)lParam)->code == NM_DBLCLK)
			{

			int iSelect=SendMessage(hList,LVM_GETNEXTITEM,
					-1,LVNI_FOCUSED); // return item selected

			if(iSelect>=0) // no items
			{

				memset(&LvItem,0,sizeof(LvItem));
				LvItem.mask=LVIF_TEXT;
				LvItem.iSubItem=0;
				LvItem.pszText=string;
				LvItem.cchTextMax=128;
				LvItem.iItem=iSelect;

				SendMessage(hList,LVM_GETITEMTEXT,iSelect, (LPARAM)&LvItem); 
				SetDlgItemText( hDlg, IDC_EDIT7, string );
				LvItem.iSubItem=1;
				SendMessage(hList,LVM_GETITEMTEXT,iSelect, (LPARAM)&LvItem); 
				SetDlgItemText( hDlg, IDC_EDIT8, string );
  				LvItem.iSubItem=2;
				SendMessage(hList,LVM_GETITEMTEXT,iSelect, (LPARAM)&LvItem); 
				SetDlgItemText( hDlg, IDC_EDIT9, string );
  				LvItem.iSubItem=3;
				SendMessage(hList,LVM_GETITEMTEXT,iSelect, (LPARAM)&LvItem); 
				SetDlgItemText( hDlg, IDC_EDIT10, string );
  				LvItem.iSubItem=4;
				SendMessage(hList,LVM_GETITEMTEXT,iSelect, (LPARAM)&LvItem); 
				SetDlgItemText( hDlg, IDC_EDIT11, string );
  				LvItem.iSubItem=5;
				SendMessage(hList,LVM_GETITEMTEXT,iSelect, (LPARAM)&LvItem); 
				SetDlgItemText( hDlg, IDC_EDIT12, string );
  

			}


			}





  }
				break;
}








		case WM_INITDIALOG:

			ghDlg=hDlg;
			hList=GetDlgItem(hDlg,IDC_LIST1);
	
			// Here we put the info on the Coulom headers
			// this is not data, only name of each header we like
			memset(&LvCol,0,sizeof(LvCol));                  // Zero Members
			LvCol.mask=LVCF_TEXT|LVCF_WIDTH|LVCF_SUBITEM;    // Type of mask
			LvCol.cx=0x28;                                   // width between each coloum
			LvCol.pszText="Word";                            // First Header Text
			LvCol.cx=0x64;                                   // width of column

			SendMessage(hList,LVM_SETEXTENDEDLISTVIEWSTYLE,0,LVS_EX_FULLROWSELECT); // Set style

			for(int a=0;a<6;a++) {
				LvCol.pszText=columnheaders[a];

				// Inserting Couloms as much as we want
				SendMessage(hList,LVM_INSERTCOLUMN,a,(LPARAM)&LvCol); // Insert/Show the coloum
				}


			memset(&LvItem,0,sizeof(LvItem)); // Zero struct's Members

			//  Setting properties Of members:

			LvItem.mask=LVIF_TEXT;   // Text Style
			LvItem.cchTextMax = 256; // Max size of test
			LvItem.iItem=0;          // choose item  
			LvItem.iSubItem=0;       // Put in first coluom
			LvItem.pszText=""; // Text to display (can be from a char variable) (Items)
#if 0
			SendMessage(hList,LVM_INSERTITEM,0,(LPARAM)&LvItem); // Send info to the Listview

			for(int i=1;i<=5;i++) // Add SubItems in a loop
			{
			LvItem.iSubItem=i;
			sprintf(string,"SubItem %d",i);
			LvItem.pszText=string;
			SendMessage(hList,LVM_SETITEM,0,(LPARAM)&LvItem); // Enter text to SubItems
			}
#endif
#if 0
		for(int i=1;i<=5;i++) // Add SubItems in a loop
			{
				SendMessage(hList2,LVM_INSERTITEM,0,(LPARAM)&LvItem); // Send info to the Listview
			SendMessage(hList3,LVM_INSERTITEM,0,(LPARAM)&LvItem); // Send info to the Listview
			SendMessage(hList4,LVM_INSERTITEM,0,(LPARAM)&LvItem); // Send info to the Listview
			SendMessage(hList5,LVM_INSERTITEM,0,(LPARAM)&LvItem); // Send info to the Listview
			SendMessage(hList6,LVM_INSERTITEM,0,(LPARAM)&LvItem); // Send info to the Listview
			SendMessage(hList7,LVM_INSERTITEM,0,(LPARAM)&LvItem); // Send info to the Listview
			}
#endif

				SetDlgItemText( hDlg, IDC_EDIT1, "knowledge" );
 				SetDlgItemText( hDlg, IDC_EDIT3, "DocMgmtServer/Callrecords/text" );
 				SetDlgItemText( hDlg, IDC_EDIT4, "DocMgmtServer/Callrecords/voice" );
 				SetDlgItemText( hDlg, IDC_EDIT5, "../../DataSources/ISYL_RDBMS" );
  				SetDlgItemText( hDlg, IDC_EDIT6, "../../DataSources/ISYL_URLS" );
  	
			SetDlgItemText( hDlg, IDC_EDIT13,"My car is in the shop. Are you going to go and get it for me? Maybe I can come too.");
		//	SetDlgItemText( hDlg, IDC_EDIT13, info );
	
				break;


		case WM_CLOSE:

			hList=NULL;
			ghDlg=NULL;
			break;


        case WM_COMMAND:
        {
            WORD wId    = LOWORD(wParam); 
            WORD wEvent = HIWORD(wParam); 
            
            switch( wId )
            {
                case IDOK:
                case IDCANCEL:
                    EndDialog( hDlg, LOWORD(wParam) );
                    return TRUE;

				case IDC_BUTTON5:
				

					{




						struct STMobject *STM=newstmobject();

						if(STM) {
							GetDlgItemText(hDlg,IDC_EDIT13,string,512);
							STMAddParagraphToWordList(STM, string);
							}





					}


				
				
				break;

				case IDC_BUTTON4:

				GetDlgItemText(hDlg,IDC_EDIT7,mlobj.X,64);
				GetDlgItemText(hDlg,IDC_EDIT8,mlobj.R,64);
				GetDlgItemText(hDlg,IDC_EDIT9,mlobj.Y,64);
				GetDlgItemText(hDlg,IDC_EDIT10,mlobj.C,64);
				GetDlgItemText(hDlg,IDC_EDIT11,mlobj.Q,64);
				GetDlgItemText(hDlg,IDC_EDIT12,string,64); mlobj.W=atoi(string);
				strcpy(mlobj.QAttr,"_");
				mlobj.RF=0;
				mlobj.Flag=0; 
				mlobj.LexID=0; 

				AddMoleculeObject(&mlobj);

                return TRUE;
				

			case IDC_RADIO4:



			u = SendMessage((HWND) GetDlgItem(hDlg,IDC_RADIO4),(UINT) BM_GETCHECK,(WPARAM) 0, (LPARAM) 0 );

			if(u) {
			 SendMessage((HWND) GetDlgItem(hDlg,IDC_RADIO4),(UINT) BM_SETCHECK,(WPARAM) BST_UNCHECKED, (LPARAM) 0 );
			 KillGLWindow();
			}
			else {
				SendMessage((HWND) GetDlgItem(hDlg,IDC_RADIO4),(UINT) BM_SETCHECK,(WPARAM) BST_CHECKED, (LPARAM) 0 );
				if (!CreateGLWindow("KnowledgeNetica demonstration",1024,768,16,0))	{
					return 0;									// Quit If Window Was Not Created
				}

				quadratic = gluNewQuadric();
				gluQuadricNormals(quadratic, GLU_SMOOTH);//		# Create Smooth Normals (NEW) 
				gluQuadricTexture(quadratic, GL_TRUE);	//		# Create Texture Coords (NEW) 
 
				visualizemoleculestate(hDlg);



			}

				return TRUE;

			case IDC_BUTTON1:
	
					GetDlgItemText(hDlg,IDC_EDIT1,string,128);

					struct lexicalobject *lexobj=GetLexicalObject(string);

		            if( lexobj ) {
						int nummol=lexobj->moleculecount;
						SendMessage(hList,LVM_DELETEALLITEMS,0,0);
						for(int a=0;a<nummol;a++) {
							struct moleculeobject *molobj=GetMoleculeObjectAt(lexobj->molecules[a]);

							LvItem.iItem=a;
							LvItem.iSubItem=0;
							LvItem.pszText=string;
							SendMessage(hList,LVM_INSERTITEM,0,(LPARAM)&LvItem); // Enter text to SubItems
							atomlexobj=GetLexicalObjectAt(molobj->R);
							LvItem.iSubItem=1;
							LvItem.pszText=atomlexobj->bytes;
							SendMessage(hList,LVM_SETITEM,0,(LPARAM)&LvItem); // Enter text to SubItems
							atomlexobj=GetLexicalObjectAt(molobj->Y);
							LvItem.iSubItem=2;
							LvItem.pszText=atomlexobj->bytes;
							SendMessage(hList,LVM_SETITEM,0,(LPARAM)&LvItem); // Enter text to SubItems
							atomlexobj=GetLexicalObjectAt(molobj->C);
							LvItem.iSubItem=3;
							LvItem.pszText=atomlexobj->bytes;
							SendMessage(hList,LVM_SETITEM,0,(LPARAM)&LvItem); // Enter text to SubItems
							atomlexobj=GetLexicalObjectAt(molobj->Q);
							LvItem.iSubItem=4;
							LvItem.pszText=atomlexobj->bytes;
							SendMessage(hList,LVM_SETITEM,0,(LPARAM)&LvItem); // Enter text to SubItems
							
							LvItem.iSubItem=5;
							wsprintf(string2,"%d",molobj->W);
							LvItem.pszText=string2;
							SendMessage(hList,LVM_SETITEM,0,(LPARAM)&LvItem); // Enter text to SubItems



							}





						if(SendMessage((HWND) GetDlgItem(hDlg,IDC_RADIO4),(UINT) BM_GETCHECK,(WPARAM) 0, (LPARAM) 0 )) {
							visualizemoleculestate(hDlg);
							}







						}
					else {
						SetDlgItemText( hDlg, IDC_LEXREF, "Not Found" );
						}


				return TRUE;
		



		
            }

        }
	}
			
		
    return FALSE;
	}   /* About */
