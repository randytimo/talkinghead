struct ATMobject {
	int AttName;
	int AttRef;
	int AttType;
	int ParentNx;
	int Status;
	int VectorMag;
	int VectorDir;
	int CreatedTime;
	int LastUpdated;
	void *nextATMobject;
	};

struct ATMobject *newATMobject();
