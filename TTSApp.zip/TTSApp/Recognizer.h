#include "sentence.h"

struct recognizerobject {
	char *paragraph;
	int paragraph_pos;

	};


int RZRecognizeWords(char *sentence,int *wordqueue,int *wordsadded,int *idiomqueue,int *idiomsadded,int *moleculequeue,int *moleculesadded);
int RZSetParagraph(recognizerobject *robject,char *paragraph);
int RZGetNextSentence(recognizerobject *robject,char *dest_sentence,int maxlen);
