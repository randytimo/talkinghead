#include "globals.h"
#include "ttsapp.h"
#include "stdio.h"
#include "string.h"
#include "kgfileio.h"

#define MAXPREFIXES 1024

//-------------------------------------------------------------

struct prefixloadstruct {
	char X[64];
	char R[64];
	char Y[64];
	char C[64];
	char Q[64];
	int W;
	char QAttr[64];
	int length;
	};


struct prefixloadstruct prefixes[MAXPREFIXES];
int totalprefixes=0;

//-------------------------------------------------------------

int readfileprefix(FILE *fp,struct prefixloadstruct *prefstruct) {
	char tmpstring[64];

	int prefixfiledelimiter=9;

	if(!readfiledelimitedbyline(fp,prefstruct->X, 64,prefixfiledelimiter)) return(0);
	if(!readfiledelimitedbyline(fp,prefstruct->R, 64,prefixfiledelimiter)) return(0);
	if(!readfiledelimitedbyline(fp,prefstruct->Y, 64,prefixfiledelimiter)) return(0);
	if(!readfiledelimitedbyline(fp,prefstruct->C, 64,prefixfiledelimiter)) return(0);
	if(!readfiledelimitedbyline(fp,prefstruct->Q, 64,prefixfiledelimiter)) return(0);


	if(!readfiledelimitedbyline(fp,tmpstring, 64,prefixfiledelimiter)) return(0); prefstruct->W=atoi(tmpstring);

	if(!readfiledelimitedbyline(fp,prefstruct->QAttr, 64,prefixfiledelimiter)) return(0);


	prefstruct->length=strlen(prefstruct->X);
	return(1);
	}


int MOLoadPrefixes(char *filename) {
	FILE *fp;
	int done=0;
int n=0;
	char szOutFileName[128];

	strcpy(szOutFileName,filename);
	make_ext(szOutFileName,"pre");





	if((fp=fopen(szOutFileName,"rb"))==NULL) {
		return(0);
		}

	while(fgetc(fp)!=0xd&&!feof(fp)); //0xd Skip first line in file
	fgetc(fp); //0xa

	struct prefixloadstruct *curprefix=new prefixloadstruct;

	while(!feof(fp)&&n<MAXPREFIXES) {
		if(readfileprefix(fp,curprefix)) {
				memcpy(&prefixes[n++],curprefix,sizeof(prefixloadstruct));
				}
			
		}

	totalprefixes=n;

	delete curprefix;
	fclose(fp);

	return(1);

}
	















// return Lexical reference of base word
// can't l=5 

int MOFindBaseWord(char *string,char *retstring) {
char tempstr[80];

	int l=strlen(string);

	if(l<3) return(0);
	

	if(strchr( string, 0x39 )) { // check for apostrophy
		if(l>3) {
			if(!strncmp(&string[l-3],"n't",3)) { // ends in n't


				}
			}


		}
	else {

		for(int a=0;a<totalprefixes;a++) {
			

			if(!strncmp(string,prefixes[a].X,prefixes[a].length)) {// found prefix
				retstring=&string[prefixes[a].length];
				return(1);

				}

			}


		}
	


	return(0);
	}