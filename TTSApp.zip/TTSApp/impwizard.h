
LRESULT CALLBACK IMPDialogProc( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam );
