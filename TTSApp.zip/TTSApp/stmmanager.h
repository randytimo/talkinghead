#include "word.h"
//#include "word.h"


struct STMobject {
	struct wordobject *STMWordList;
	int numwordobjects;
	
	struct moleculeobject *STMMoleculeList;
	int nummoleculeobjects;

	struct SRMobject *SRMobjectList;
	int numsmmxobjects;

	struct ATMobject *ATMxList;
	int numatmobjects;



};


struct STMobject *newstmobject();

int STMAddSentenceToWordList(struct STMobject *STM, char *sentence);
int STMAddParagraphToWordList(struct STMobject *STM, char *paragraph);

int STMAddSentenceToSentenceMxList(char *sentence);
int STMAssociateWordAndMolecules();
int STMExtractAttributes();
int STMAddMolecule(struct STMobject *STM,struct moleculeobject *molobject);
int STMAddMoleculeAttributes(struct STMobject *STM,struct moleculeobject *molobject);

