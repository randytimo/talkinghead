#include "globals.h"
#include "Recognizer.h"
#include "kgconverter.h"
#include "ctype.h"
#include "string.h"
#include "morphology.h"
#include "stmmanager.h"
#include "lexical.h"

int CLAddWordToWordList(struct STMobject *STM,struct wordobject *wobject){

	struct wordobject *tempwo=STM->STMWordList;

	for(int a=0;a<STM->numwordobjects-1;a++) { //Advance to where new object will go
		tempwo=(struct wordobject *)tempwo->nextwordobject;
		}

	tempwo->nextwordobject=wobject;
	STM->numwordobjects++;

	return(1);
	}


struct wordobject *CLFindWordObject(struct STMobject *STM,struct wordobject *wobject){

	struct wordobject *tempwo=STM->STMWordList;

	for(int a=0;a<STM->numwordobjects;a++) { //Advance to where new object will go
		if(wobject->lexref==tempwo->lexref) return(tempwo);

		tempwo=(struct wordobject *)tempwo->nextwordobject;
		}

	return(NULL);
	}

int AddWordsToSTMWordList(){

return(1);
}


int CLClassifyWords(struct STMobject *STM,int *words,int wordcount,int *idioms,int idiomcount,int *molecules,int moleculecount){
	struct wordobject *tempwo;
	struct wordobject *wordobj;
	struct wordobject *lastwordobj=NULL;
	struct moleculeobject *molobj;
	struct moleculeobject *tempmo;

		for(int a=0;a<wordcount;a++) {// Classify words
			wordobj=newwordobject(); // Add the word to STM word list

			if(wordobj) {
				wordobj->lexref=words[a];

				if(tempwo=CLFindWordObject(STM,wordobj)) {
					tempwo->weight+=5;
					}
				else  {
					CLAddWordToWordList(STM,wordobj);
					}

//				CLAddRefToSentenceNx(STM,

					struct lexicalobject *templo=GetLexicalObjectAt(words[a]); // now add all molecules to STM
					
					for(int b=0;b<templo->moleculecount;b++) {
#if 0
						molobj=GetMoleculeObjectAt(templo->molecules[b]);
						if(tempmo=STMFindMoleculeObject(STM,molobj)) {


							}
						else {
							STMAddMolecule(STM,tempmo);
							STMAddMoleculeAttributes(STM,GetMoleculeObjectAt(templo->molecules[b]));
							}
#endif
						}

	#if 0
					for(int b=0;b<templo->idiomcount;b++) {
						if(RZIdiomFilter(sentence,templo->idioms[b])){
							STMAddIdiom(STM,GetLexicalObjectAt(templo->idioms[b]));
							};
						}
	#endif
					}



				}
	return(1);		
		};

int AddWordsToSTMSMMx(){

return(1);
	}

int AddMoleculesToSTM(){

return(1);
	}




